import random, math, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageChops
from lib import *
from objects import *
from objects5 import partition
from objects2 import *

X0, X1 = 48, 3152
IX0, IX1 = 78, 3122
TS0, TS1 = 180, 212
FB = 626
HALL = (IX0, 1500); P1 = (1500, 1524)
SRV = (1524, 2200); P2 = (2200, 2224)
LNG = (2224, IX1)
SCL = 286          # server room sealed ceiling
LCL = 292          # lounge slat ceiling

c = Canvas()


def hatch(x0, y0, x1, y1, col=hx('#3a3f44'), step=9):
    def f(od, ox, oy):
        for k in range(int(-(y1 - y0)), int(x1 - x0), step):
            od.line([(P(x0 + k) + ox, P(y1) + oy), (P(x0 + k + (y1 - y0)) + ox, P(y0) + oy)], fill=wa(col, 70), width=P(0.8))
    tdraw(c, (x0, y0, x1, y1), f)


def layer(fn, dark=0.5, tint=hx('#0c1a1c'), tint_a=0.45):
    c.apply_shade_now()
    base = c.img
    c.img = Image.new('RGBA', base.size, (0, 0, 0, 0)); c.d = ImageDraw.Draw(c.img)
    fn()
    c.apply_shade_now()
    arr = np.asarray(c.img, np.float32)
    rgb = arr[:, :, :3] * (1 - dark)
    rgb = rgb * (1 - tint_a) + np.array(tint[:3], np.float32) * tint_a
    arr[:, :, :3] = np.where(arr[:, :, 3:4] > 0, rgb, arr[:, :, :3])
    base.alpha_composite(Image.fromarray(np.rint(arr).clip(0, 255).astype(np.uint8), 'RGBA'))
    c.img = base; c.d = ImageDraw.Draw(c.img)


# ------------------------------------------------------------------ shell
def shell():
    c.vgrad(IX0, TS1, IX1, 300, hx('#111416'), hx('#181c1e'))
    # hall: coffered ceiling + velvet walls
    for x in np.arange(HALL[0], HALL[1], 120):
        c.box(x, TS1, x + 10, 244, hx('#1a2a2c'), outline=OUT, hl=.1)
        c.vgrad(x + 10, TS1, x + 120, 238, hx('#0d1516'), hx('#142224'))
        c.hline(x + 10, x + 120, 238, GOLD, 0.8)
    c.box(HALL[0], 244, HALL[1], 252, hx('#1a2a2c'), outline=OUT, hl=.1)
    velvet_wall(c, HALL[0], 288, HALL[1], FY)
    c.vgrad(HALL[0], 252, HALL[1], 288, hx('#121c1e'), dk(VELVET, .2))
    # server room: sealed white ceiling + sterile wall
    c.vgrad(SRV[0], TS1, SRV[1], SCL, hx('#121518'), hx('#1a1e21'))
    sterile_wall(c, SRV[0], SCL, SRV[1], FY)
    c.box(SRV[0], SCL - 6, SRV[1], SCL, hx('#6a7277'), outline=OUT, hl=.1)
    # lounge: warm greige wall, wood wainscot
    c.vgrad(LNG[0], LCL, LNG[1], FY, hx('#3a3631'), hx('#4a453e'))
    for x in np.arange(LNG[0] + 3, LNG[1], 9):
        c.vgrad(x, 470, x + 7, FY - 9, hx('#4a3a2c'), hx('#3a2e24'))
    c.box(LNG[0], 466, LNG[1], 470, hx('#5a4636'), outline=OUT, hl=.25)
    c.box(LNG[0], FY - 9, LNG[1], FY, hx('#241e19'), outline=None)
    c.box(HALL[0], FY - 9, HALL[1], FY, hx('#0e1617'), outline=None)
    # floor finishes (base fill first so partition footings leave no gaps)
    c.rect(IX0, FY, IX1, FY + 8, hx('#1d2124'))
    c.rect(HALL[0], FY, HALL[1], FY + 5, hx('#122024'))
    for x in np.arange(HALL[0], HALL[1], 50):
        c.vline(x, FY, FY + 5, hx('#0f1b1e'), 0.8)
    c.hline(HALL[0], HALL[1], FY, GOLD, 0.8)
    c.rect(P1[0] - 6, FY, SRV[1] + 6, FY + 4, hx('#5a6266'))               # white anti-static tiles
    c.hline(P1[0] - 6, SRV[1] + 6, FY, hx('#8a9296'), 0.8)
    c.rect(SRV[0], FY + 4, SRV[1], FY + 32, hx('#0f1113'))                  # raised-floor plenum
    for x in np.arange(SRV[0] + 20, SRV[1], 60):
        c.box(x, FY + 6, x + 4, FY + 32, hx('#3b4146'), outline=None)
        c.rect(x - 4, FY + 30, x + 8, FY + 32, hx('#3b4146'))
    rng = random.Random(4)
    for k in range(7):
        x0 = SRV[0] + rng.uniform(0, 600)
        col = rng.choice([hx('#2e4c6c'), hx('#7a6a36'), hx('#4a5258')])
        c.rrect(x0, FY + 24 - rng.uniform(0, 5), x0 + rng.uniform(30, 80), FY + 31, 3, dk(col, .25), OUT, 0.6)
    for x in np.arange(SRV[0] + 40, SRV[1] - 40, 120):                     # perforated tile edges
        for k in range(6):
            c.rect(x + k * 5, FY + 1.2, x + k * 5 + 2, FY + 2.6, hx('#2a2f33'))
    c.hline(SRV[0], SRV[1], FY + 32, hx('#2a2f33'), 1)
    c.rect(LNG[0], FY, LNG[1], FY + 5, hx('#3a2e24'))
    for x in np.arange(LNG[0], LNG[1], 64):
        c.vline(x, FY, FY + 5, hx('#2a2018'), 0.8)
    c.hline(LNG[0], LNG[1], FY, hx('#6a5644'), 0.8)
    # slab + shell sections
    c.vgrad(X0, FY + 5, X1, FB, hx('#23272a'), hx('#191b1e'))
    c.rect(SRV[0], FY + 4, SRV[1], FY + 32, hx('#0f1113'))
    for x in (P1[0] - 18, P2[0] - 18):
        c.vgrad(x, FB - 2, x + 60, FB + 14, hx('#1f2225'), hx('#16181a'))
        c.rect(x, FB - 2, x + 60, FB + 14, None, OUT, 1)
    c.vgrad(X0, TS0, X1, TS1, hx('#272b30'), hx('#1b1e22'))
    c.vgrad(X0, TS0, IX0, FB, hx('#262a2e'), hx('#1b1e21'))
    c.vgrad(IX1, TS0, X1, FB, hx('#262a2e'), hx('#1b1e21'))
    for a in ((X0, TS0, X1, TS1), (X0, FY + 32, X1, FB), (X0, FY + 5, SRV[0], FY + 32), (SRV[1], FY + 5, X1, FY + 32),
              (X0, TS0, IX0, FB), (IX1, TS0, X1, FB)):
        hatch(*a)
    c.hline(X0, X1, TS0, hx('#4b5258'), 1)
    c.hline(IX0, IX1, TS1, hx('#0d0f11'), 1)
    c.vline(IX0 - 1, TS1, FY, hx('#2c3237'), 1)
    c.vline(IX1, TS1, FY, hx('#0e1012'), 1)
    c.hline(X0, X1, FB - 1, hx('#2b2f33'), 1)


# ------------------------------------------------------------------ event hall
def grand_piano(c, x0, floor_y):
    """grand piano in profile on the stage, keyboard end on the right, lid propped"""
    top = floor_y - 74
    body = hx('#0f1011')
    pts = [(x0, top + 8), (x0 + 30, top), (x0 + 170, top), (x0 + 176, top + 4), (x0 + 176, top + 26), (x0 + 6, top + 26)]
    c.poly(pts, body, OUT)
    c.hline(x0 + 8, x0 + 170, top + 1, hx('#2a2c2e'), 0.8)
    # propped lid
    c.poly([(x0 + 8, top - 2), (x0 + 150, top - 2), (x0 + 60, top - 64), (x0 + 30, top - 56)], hx('#141516'), OUT)
    c.line([(x0 + 110, top - 2), (x0 + 96, top - 40)], hx('#5a5e61'), 1)
    c.line([(x0 + 40, top - 52), (x0 + 120, top - 8)], hx('#3a3c3e'), 0.6)            # lid reflection
    # keyboard + music desk
    c.box(x0 + 170, top + 8, x0 + 192, top + 18, hx('#1b1c1d'), outline=OUT)
    c.rect(x0 + 172, top + 9, x0 + 190, top + 11, hx('#8a8c86'))
    c.poly([(x0 + 156, top), (x0 + 166, top), (x0 + 176, top - 22), (x0 + 168, top - 22)], hx('#1b1c1d'), OUT)
    c.rect(x0 + 167, top - 21, x0 + 174, top - 12, hx('#7d807c'))                     # sheet music
    # legs, lyre, pedals
    for lx in (x0 + 18, x0 + 168):
        c.poly([(lx, top + 26), (lx + 8, top + 26), (lx + 6, floor_y - 4), (lx + 2, floor_y - 4)], body, OUT)
        c.ell(lx, floor_y - 5, lx + 8, floor_y, hx('#4a3a2c'), OUT, 0.4)
    c.box(x0 + 140, top + 26, x0 + 148, floor_y - 6, body, outline=OUT)
    c.rect(x0 + 136, floor_y - 7, x0 + 152, floor_y - 5, GOLD)
    # bench
    c.box(x0 + 196, top + 22, x0 + 230, top + 28, hx('#141516'), outline=OUT, hl=.2)
    for lx in (x0 + 198, x0 + 224):
        c.box(lx, top + 28, lx + 4, floor_y, hx('#141516'), outline=None)


def hall():
    stage_top = stage(c, 96, 600, 56)
    # curtains and screen
    stage_curtain(c, 100, 152, 262, stage_top)
    stage_curtain(c, 548, 600, 262, stage_top)
    c.occlude(186, 268, 556, 474, 100, blur=5); c.apply_shade_now()
    c.box(184, 266, 556, 472, hx('#0b0c0d'), outline=OUT)
    speaker_grid_screen(c, 190, 272, 550, 466, cols=26, rows=12, seed=3)
    projector_ceiling(c, 650, 246, facing=-1)
    # stage: piano, lectern, mic stand, wedge
    grand_piano(c, 170, stage_top)
    lectern(c, 470, stage_top)
    c.line([(540, stage_top), (544, stage_top - 96)], hx('#4a4e51'), 1)
    c.line([(544, stage_top - 96), (552, stage_top - 102)], hx('#4a4e51'), 1)
    c.ell(551, stage_top - 106, 557, stage_top - 100, hx('#1b1d1f'), OUT, 0.4)
    for dx in (-10, 10):
        c.line([(540, stage_top - 18), (540 + dx, stage_top)], hx('#4a4e51'), 0.9)
    stage_wedge(c, 580, stage_top, facing=-1)
    c.bezier((440, stage_top - 1), (500, stage_top - 3), (580, stage_top - 1), hx('#121416'), 0.8)
    pa_speaker(c, 666, True, FY - 156)
    # side wall displays (off) + sconces
    for sx in (760, 1060):
        c.occlude(sx + 2, 334, sx + 142, 412, 90, blur=4); c.apply_shade_now()
        c.rrect(sx, 330, sx + 140, 408, 1.2, hx('#0e1012'), OUT, 1)
        screen_content(c, sx + 2.5, 332.5, sx + 137.5, 405.5, 'off', seed=sx)
    for x in (720, 1000, 1300):
        wall_sconce(c, x, 360)
    # audience: a hazed second line of seats, then the front line, every seat with an armrest mic
    def back_seats():
        for k, x in enumerate(np.arange(736, 1250, 72)):
            audience_chair(c, x, facing=-1, item='mic')
    layer(back_seats)
    items = ['mic', 'leaflet', 'mic', 'jacket', None, 'mic', 'leaflet', 'mic']
    for k, x in enumerate(np.arange(700, 1240, 72)):
        if k == 5:
            fallen_banquet_chair(c, x - 6)
            continue
        audience_chair(c, x, facing=-1, item=items[k % len(items)], askew=(4 if k == 2 else 0))
    receiver_cart(c, 1262)
    chair_dolly(c, 1330, n=10)
    foh_desk(c, 1398, 1494)


# ------------------------------------------------------------------ server room
def server_room():
    # overhead: fibre runner, ladder tray, cold LED strip
    fiber_runner(c, SRV[0] + 6, SRV[1] - 6, 300)
    c.rect(SRV[0] + 6, 316, 1930, 318, hx('#4f575d'))
    c.rect(SRV[0] + 6, 324, 1930, 325.5, hx('#3b4247'))
    for x in np.arange(SRV[0] + 6, 1930, 12):
        c.vline(x, 316, 325.5, hx('#454c52'), 0.6)
    for x in np.arange(SRV[0] + 40, SRV[1], 220):
        c.vline(x, SCL, 316, hx('#3a3e41'), 0.6)
    # wall-mounted environment panel + suppression release
    env_panel(c, 2116, 344)
    c.box(2122, 392, 2142, 418, hx('#7a2f29'), outline=OUT, hl=.15)
    c.rect(2126, 398, 2138, 408, hx('#9a4a40'))
    # racks: one lit row of servers, the NAS, three emptied racks (migrated to B2), a network rack
    rack(c, 1540, 58, 186, 'servers', seed=11, door_glass=True)
    rack(c, 1602, 58, 186, 'servers', seed=12)
    nas_disk_out(c, 1650, FY - 120)
    empty_rack(c, 1664, door_open=True, leftovers=2, seed=1)
    empty_rack(c, 1740, door_open=False, leftovers=4, seed=2)
    rack(c, 1802, 58, 186, 'patch', seed=13)
    empty_rack(c, 1864, door_open=True, leftovers=1, seed=3)
    containment_roof(c, 1536, 1926, FY - 186)
    rng = random.Random(9)
    for k in range(14):
        x = 1546 + rng.uniform(0, 370)
        col = rng.choice([hx('#3e6aa0'), hx('#b39a4a'), hx('#7a8a92'), hx('#15181b')])
        c.bezier((x, FY - 204), (x + rng.uniform(-8, 8), 336), (x + rng.uniform(-20, 20), 321), dk(col, .25), 0.8)
    server_cart(c, 1712)
    crac_unit(c, 1950)
    gas_cylinders(c, 2058)
    # cold blue-white emergency light from the sealed ceiling
    for x in (1620, 1860, 2080):
        c.rect(x - 40, SCL, x + 40, SCL + 2, hx('#cfe2ea'))
        c.glow_rect(x - 40, SCL - 1, x + 40, SCL + 4, hx('#9fd0e6'), 0.6, blur=5)
        c.cone(x, SCL + 2, FY, 80, 170, hx('#6fa6c0'), intensity=0.16, blur=18)


# ------------------------------------------------------------------ lounge
def tall_plant(c, x):
    c.occlude(x - 18, FY - 6, x + 18, FY + 1, 100, blur=3)
    c.box(x - 14, FY - 40, x + 14, FY, hx('#3e3a34'), outline=OUT, hl=.1)
    rng = random.Random(int(x))
    for k in range(14):
        a = -math.pi / 2 + rng.uniform(-1.0, 1.0)
        L = rng.uniform(40, 110)
        ex = x + math.cos(a) * L * 0.5; ey = FY - 40 + math.sin(a) * L
        c.line([(x, FY - 40), (ex, ey)], hx('#26301f'), 1)
        c.poly([(ex, ey), (ex + 10, ey + 4), (ex + 2, ey + 12), (ex - 8, ey + 6)], hx('#2c3a2a') if k % 3 else hx('#4a4a32'), OUT)


def lounge():
    wood_slat_ceiling(c, LNG[0], LNG[1], LCL - 6)
    # window full of street-tree canopy
    wx0, wy0, wx1, wy1 = 2476, 318, 2856, 528
    tree_window(c, wx0, wy0, wx1, wy1, seed=6)
    tdraw(c, (wx0, wy0, wx1, wy1), lambda od, ox, oy: od.rectangle([P(wx0) + ox, P(wy0) + oy, P(wx1) + ox, P(wy1) + oy], fill=(30, 40, 46, 40)))
    for m in np.arange(wx0, wx1 + 1, 126.67):
        reflection(c, m, wy0, min(m + 126, wx1), wy1, 10, 0.3, 0.12)
    for m in np.arange(wx0 + 126.67, wx1 - 1, 126.67):
        c.box(m - 3, wy0, m + 3, wy1, hx('#2a2622'), outline=None, hl=.15)
    c.rect(wx0 - 4, wy0 - 4, wx1 + 4, wy0, hx('#2a2622'))
    c.rect(wx0 - 4, wy0 - 4, wx0, wy1, hx('#2a2622')); c.rect(wx1, wy0 - 4, wx1 + 4, wy1, hx('#2a2622'))
    c.box(wx0 - 8, wy1, wx1 + 8, wy1 + 6, hx('#5a4a3a'), outline=OUT, hl=.2)
    sheer_curtain(c, wx0 - 26, wx0 + 24, wy0 - 10, FY - 12)
    sheer_curtain(c, wx1 - 30, wx1 + 26, wy0 - 10, FY - 12)
    c.box(wx0 - 30, wy0 - 14, wx1 + 30, wy0 - 10, hx('#3a3e41'), outline=OUT)          # curtain track
    for x in (2560, 2680, 2950):
        pendant_lamp(c, x, 330, LCL + 2)
    # vending machines (off)
    vending(c, 2242, 92, 'drink', seed=1)
    vending(c, 2340, 92, 'snack', seed=2)
    c.box(2438, FY - 40, 2466, FY, hx('#2c3a3e'), outline=OUT, hl=.1)                 # recycling bin for cans
    for k in range(3):
        c.rect(2442 + k * 8, FY - 44, 2446 + k * 8, FY - 40, hx('#3e6e64'))
    # sofa in front of the window, coffee table, armchair, floor lamp, poster, plant
    sofa(c, 2500, 2752)
    coffee_table(c, 2570, 2700)
    concert_poster(c, 2896, 334, 72, 96)
    armchair(c, 2884, 2984)
    floor_lamp(c, 3012)
    c.box(3030, FY - 52, 3062, FY - 48, hx('#4a3a2c'), outline=OUT, hl=.2)            # side table
    c.box(3044, FY - 48, 3048, FY, hx('#2a241e'), outline=None)
    mug(c, 3040, FY - 52, hx('#6f5048'))
    tall_plant(c, 3092)
    # exit pictogram at the lounge end
    ex = 3058
    c.box(ex, 300, ex + 44, 316, hx('#1a2a1f'), outline=OUT)
    c.rect(ex + 2, 302, ex + 42, 314, hx('#2f6a45'))
    c.ell(ex + 27, 303.5, ex + 30, 306.5, hx('#cfe8d6'))
    c.line([(ex + 28, 307), (ex + 25, 311), (ex + 21, 313)], hx('#cfe8d6'), 0.9)
    c.line([(ex + 27, 308), (ex + 32, 310)], hx('#cfe8d6'), 0.8)
    c.line([(ex + 16, 308), (ex + 6, 308), (ex + 10, 305)], hx('#cfe8d6'), 0.8)
    c.glow_rect(ex, 300, ex + 44, 316, hx('#4fb57a'), 0.5, blur=14)


# ------------------------------------------------------------------ partitions & ceilings
def partitions_and_rigging():
    partition(c, P1[0], P1[1], TS1, door_h=210, style='steel', door_side='R')
    # card reader + exit sign on the hall side of the server-room door
    c.box(1480, 466, 1492, 490, hx('#24292d'), outline=OUT)
    c.rect(1482, 471, 1490, 479, hx('#15191c'))
    led(c, 1486, 485, RED, 0.8, 0.9)
    # solid fire-rated wall between server room and lounge
    x0, x1 = P2
    c.vgrad(x0, TS1, x1, FY, hx('#2a2e32'), hx('#1f2326'))
    def f(od, ox, oy):
        for k in range(int(-(FY - TS1)), int(x1 - x0) + 2, 6):
            od.line([(P(x0 + k) + ox, P(FY) + oy), (P(x0 + k + (FY - TS1)) + ox, P(TS1) + oy)], fill=(70, 76, 82, 80), width=P(0.7))
    tdraw(c, (x0, TS1, x1, FY), f)
    c.rect(x0, TS1, x1, FY, None, OUT, 1)
    # hall rigging: lighting truss + par cans, line array, hanging audience mics
    truss(c, 110, 640, 254, 14)
    for x, a in ((170, 1), (260, 1), (350, 1), (440, 1), (540, -1)):
        par_can(c, x, 268, a)
    line_array(c, 690, 258, 4)
    for k, x in enumerate(np.arange(780, 1260, 96)):
        hanging_mic(c, x, 352 + (k % 2) * 18)
    # cctv domes
    for x, y in ((1460, 252), (2180, SCL)):
        c.vline(x, TS1, y, hx('#3a4045'), 0.8)
        c.box(x - 9, y, x + 9, y + 3, hx('#4a5258'), outline=OUT)
        c.ell(x - 7, y - 2, x + 7, y + 11, hx('#1c2024'), OUT, 0.8)
        led(c, x + 2, y + 6, RED, 0.6, 0.6)


# ------------------------------------------------------------------ finalize
def finalize():
    arr = np.asarray(c.img, np.float32)
    h, w = arr.shape[:2]
    ys = np.linspace(0, 1, h)[:, None]
    xs = np.linspace(0, 1, w)[None, :]
    yy = (ys * H - TS1) / (FY - TS1)
    v = 1.0 - 0.28 * np.clip(1 - yy * 1.5, 0, 1) ** 1.5
    v *= 1.0 - 0.10 * np.clip((yy - 0.75) * 4, 0, 1)
    edge = np.minimum(xs, 1 - xs) * W
    v = v * (0.74 + 0.26 * np.clip(edge / 420.0, 0, 1))
    arr[:, :, :3] *= v[:, :, None]
    sh = np.asarray(c.shade, np.float32)[:, :, None] / 255.0
    arr[:, :, :3] *= (1 - sh * 0.85)
    L = np.asarray(c.light, np.float32) / 255.0
    base = arr[:, :, :3] / 255.0
    out = 1 - (1 - base) * (1 - L)
    lum = (out * np.array([0.299, 0.587, 0.114])).sum(axis=2, keepdims=True)
    out = out * 0.80 + lum * 0.20
    out = out * np.array([0.985, 1.0, 1.02])
    out = np.clip(out, 0, 1) ** 0.92
    out = np.clip((out - 0.5) * 1.10 + 0.5, 0, 1)
    arr[:, :, :3] = out * 255
    img = Image.fromarray(np.rint(arr).clip(0, 255).astype(np.uint8), 'RGBA').resize((W, H), Image.LANCZOS)
    a = np.asarray(img, np.float32)
    rng = np.random.default_rng(2)
    g = (rng.random((H, W)) - 0.5) * 7
    low = Image.fromarray((rng.random((H // 6, W // 6)) * 255).astype(np.uint8), 'L').resize((W, H), Image.BICUBIC)
    low = (np.asarray(low, np.float32) / 255 - 0.5) * 0.07
    a[:, :, :3] = a[:, :, :3] * (1 + low[:, :, None]) + g[:, :, None]
    alpha = np.where(a[:, :, 3] > 127, 255, 0)
    a[:, :, 3] = alpha
    a[:, :, :3] *= (alpha[:, :, None] > 0)
    img = Image.fromarray(np.rint(a).clip(0, 255).astype(np.uint8), 'RGBA')
    m = img.getchannel('A')
    inner = m.filter(ImageFilter.MinFilter(5))
    img.paste(Image.new('RGBA', img.size, (9, 10, 12, 255)), (0, 0), ImageChops.subtract(m, inner))
    inner2 = m.filter(ImageFilter.MinFilter(9))
    img.paste(Image.new('RGBA', img.size, (78, 88, 98, 255)), (0, 0), ImageChops.subtract(inner, inner2).point(lambda v: 150 if v else 0))
    bb = img.getchannel('A').getbbox()
    M = 48
    img = img.crop((bb[0] - M, bb[1] - M, bb[2] + M, bb[3] + M))
    print('bbox', bb, 'floor line y in output =', FY - (bb[1] - M), 'size', img.size)
    return img


def build():
    shell()
    c.noise_tex(HALL[0], 288, HALL[1], FY, 0.06, 26, seed=1, streaks=True)
    c.noise_tex(SRV[0], SCL, SRV[1], FY, 0.04, 30, seed=2)
    c.noise_tex(LNG[0], LCL, LNG[1], FY, 0.06, 26, seed=3, streaks=True)
    c.noise_tex(X0, TS0, X1, TS1, 0.08, 16, seed=4)
    c.noise_tex(X0, FY, X1, FB, 0.08, 16, seed=5)
    for i, (x, y, w_, h_) in enumerate([(780, 470, 140, 80), (1200, 300, 120, 80), (2600, 470, 140, 80), (3000, 320, 90, 120)]):
        c.stain(x, y, w_, h_, hx('#14171a'), alpha=40, blur=10, seed=i + 40)
    c.occlude(IX0, TS1, IX1, TS1 + 10, 150, blur=10)
    c.occlude(IX0, FY - 6, IX1, FY, 120, blur=6)
    c.occlude(IX0, TS1, IX0 + 10, FY, 140, blur=14)
    c.occlude(IX1 - 10, TS1, IX1, FY, 140, blur=14)
    for (x0, x1) in (P1, P2):
        c.occlude(x0 - 14, TS1, x0, FY, 110, blur=10)
        c.occlude(x1, TS1, x1 + 14, FY, 110, blur=10)
    c.apply_shade_now()
    hall()
    server_room()
    lounge()
    partitions_and_rigging()
    return finalize()


if __name__ == '__main__':
    img = build()
    out = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/f2/floor02.png'
    img.save(out)
    print('saved', out)
