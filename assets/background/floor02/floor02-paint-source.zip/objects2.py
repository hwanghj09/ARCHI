import random, math
import numpy as np
from PIL import Image, ImageDraw
from lib import *
from objects import *

TEAL = hx('#1d3436')
TEAL_L = hx('#2e4a4c')
GOLD = hx('#8a7246')
GOLD_L = hx('#b09a62')
VELVET = hx('#20383a')


# ============================================================ EVENT HALL
def velvet_wall(c, x0, y0, x1, y1, step=118):
    c.vgrad(x0, y0, x1, y1, dk(VELVET, .2), VELVET)
    for x in np.arange(x0 + 10, x1, step):
        # tufted acoustic panel with soft vertical folds
        for k in range(6):
            fx = x + 6 + k * (step - 16) / 6
            c.vline(fx, y0 + 4, y1 - 4, dk(VELVET, .25), 1.2)
            c.vline(fx + 2, y0 + 4, y1 - 4, lit(VELVET, .06), 0.6)
        c.box(x - 3, y0, x + 3, y1, GOLD, outline=OUT, hl=.25, sh=.4)       # gold pilaster trim
    c.box(x0, y0, x1, y0 + 6, GOLD, outline=OUT, hl=.3, sh=.4)
    c.box(x0, 476, x1, 482, dk(GOLD, .15), outline=OUT, hl=.3, sh=.4)        # chair-rail molding
    c.vgrad(x0, 482, x1, y1, dk(VELVET, .35), dk(VELVET, .45))


def stage(c, x0, x1, h=56):
    top = FY - h
    c.occlude(x0, top, x1, FY, 100, blur=4); c.apply_shade_now()
    c.box(x0, top + 6, x1, FY, hx('#141516'), outline=OUT, hl=.05)                  # black fascia
    for x in np.arange(x0 + 40, x1, 80):
        c.vline(x, top + 10, FY - 2, hx('#1d1f20'), 0.8)
    c.box(x0 - 2, top, x1 + 2, top + 6, hx('#4a3a2c'), outline=OUT, hl=.25)         # wood stage nosing
    c.hline(x0, x1, top + 6, GOLD, 0.8)
    # steps at the right end
    for k in range(3):
        sx = x1 + k * 14
        sy = top + 6 + k * (h - 6) / 3
        c.box(sx, sy, x1 + 44, FY, hx('#1b1c1d'), outline=OUT, hl=.1)
        c.hline(sx, x1 + 44, sy, hx('#4a3a2c'), 1.2)
    return top


def stage_curtain(c, x0, x1, top, bottom, gathered=True):
    c.box(x0 - 4, top - 6, x1 + 4, top, GOLD, outline=OUT, hl=.3)
    xx = x0; k = 0
    while xx < x1:
        w = 7 + (k % 3) * 2
        col = VELVET if k % 2 else lit(VELVET, .08)
        c.vgrad(xx, top, min(xx + w, x1), bottom, dk(col, .1), dk(col, .35))
        xx += w; k += 1
    c.rect(x0, top, x1, bottom, None, OUT, 0.8)
    c.box(x0 + 2, (top + bottom) / 2, x1 - 2, (top + bottom) / 2 + 5, GOLD, outline=OUT, hl=.3)   # tie-back


def speaker_grid_screen(c, x0, y0, x1, y1, cols=26, rows=12, seed=0):
    """projection: 312 small voice-sample waveforms, the last one framed"""
    rng = random.Random(seed)
    c.vgrad(x0, y0, x1, y1, hx('#1a2830'), hx('#121c22'))
    cw = (x1 - x0 - 8) / cols; ch = (y1 - y0 - 8) / rows
    for r in range(rows):
        for k in range(cols):
            cx0 = x0 + 4 + k * cw; cy0 = y0 + 4 + r * ch
            last = (r == rows - 1 and k == cols - 1)
            col = hx('#7fb0c0') if not last else hx('#d98a7a')
            mid = cy0 + ch / 2
            for b in range(5):
                bx = cx0 + 2 + b * (cw - 4) / 5
                bh = (ch - 5) * (0.2 + 0.8 * abs(math.sin(b * 1.3 + r * 0.7 + k * 0.37 + rng.random())))
                c.rect(bx, mid - bh / 2, bx + 1.1, mid + bh / 2, wa(dk(col, .25 if not last else 0), 255))
            if last:
                c.rect(cx0 - 1, cy0 - 1, cx0 + cw + 0.5, cy0 + ch + 0.5, None, hx('#e09a8a'), 0.9)
    c.glow_rect(x0, y0, x1, y1, hx('#6f9ab0'), 0.42, blur=26)
    c.glow_rect(x1 - cw - 6, y1 - ch - 6, x1, y1, hx('#c96a5a'), 0.35, blur=8)


def projector_ceiling(c, x, y, facing=-1):
    c.vline(x, 212, y, hx('#3a3e41'), 1.2)
    c.box(x - 18, y, x + 18, y + 14, hx('#4c5155'), outline=OUT, hl=.15)
    lx = x - 18 if facing < 0 else x + 18
    c.ell(lx - 4, y + 3, lx + 4, y + 11, hx('#cfdde4'), OUT, 0.5)
    c.glow_ell(lx, y + 7, 14, 10, hx('#a9c2d0'), 0.6, blur=6)
    for k in range(4):
        c.vline(x + 2 + k * 3 * -facing, y + 2, y + 6, hx('#2a2d30'), 0.6)
    led(c, x + 10 * -facing, y + 10, AMBER, 0.5, 0.4)


def lectern(c, x, top_y):
    """lectern on the stage facing right (toward the audience)"""
    c.poly([(x, top_y), (x + 34, top_y), (x + 34, top_y - 94), (x + 4, top_y - 102)], hx('#3b2e24'), OUT)
    c.vgrad(x + 3, top_y - 92, x + 31, top_y - 4, hx('#4a3a2c'), hx('#2e241c'))
    c.box(x + 8, top_y - 60, x + 28, top_y - 54, GOLD, outline=None, hl=.3)
    c.poly([(x - 2, top_y - 104), (x + 38, top_y - 96), (x + 38, top_y - 92), (x - 2, top_y - 99)], hx('#4a3a2c'), OUT)
    c.line([(x + 30, top_y - 96), (x + 36, top_y - 112), (x + 44, top_y - 116)], hx('#2a2d30'), 1.1)   # gooseneck mic
    c.ell(x + 42, top_y - 119, x + 48, top_y - 113, hx('#1b1d1f'), OUT, 0.4)
    c.box(x + 6, top_y - 106, x + 26, top_y - 100, hx('#22262a'), outline=OUT)   # laptop closed on top


def panel_table(c, x0, x1, top_y):
    t = top_y - 66
    c.box(x0, t, x1, t + 5, hx('#2b2f31'), outline=OUT, hl=.2)
    c.vgrad(x0, t + 5, x1, top_y - 2, TEAL_L, dk(TEAL_L, .3))                 # table skirt
    for x in np.arange(x0 + 8, x1, 10):
        c.vline(x, t + 6, top_y - 3, dk(TEAL_L, .2), 0.6)
    c.hline(x0, x1, t + 5, GOLD, 0.8)
    rng = random.Random(3)
    for k, x in enumerate(np.linspace(x0 + 30, x1 - 30, 3)):
        c.poly([(x - 9, t), (x + 9, t), (x + 6, t - 10), (x - 6, t - 10)], hx('#7d807c'), OUT)   # blank name tent
        bottle_small(c, x + 18, t)
        c.line([(x - 18, t), (x - 22, t - 14), (x - 26, t - 18)], hx('#2a2d30'), 0.9)            # table mic
    return t


def bottle_small(c, x, y):
    tpoly(c, [(x - 2, y), (x + 2, y), (x + 2, y - 11), (x + 1, y - 13), (x - 1, y - 13), (x - 2, y - 11)], hx('#8aa0ae'), 70)
    c.rect(x - 1.1, y - 15, x + 1.1, y - 13, hx('#2f4766'))


def stage_chair(c, x, floor_y, facing=1, col=None):
    """simple upholstered chair in profile; facing = direction the sitter looks"""
    col = col or hx('#2a3e40')
    f = facing
    seat = floor_y - 43
    back_x = x - 14 * f
    c.box(x - 16, seat - 5, x + 16, seat, col, outline=OUT, hl=.15)
    c.poly([(back_x - 3, seat - 4), (back_x + 3, seat - 4), (back_x + 3 - 4 * f, seat - 44), (back_x - 3 - 4 * f, seat - 44)], col, OUT)
    for lx in (x - 13, x + 11):
        c.box(lx, seat, lx + 2.5, floor_y, hx('#3a3e41'), outline=None)
    c.hline(x - 14, x + 13, floor_y - 12, hx('#3a3e41'), 0.8)


def audience_chair(c, x, facing=-1, col=None, askew=0, item=None):
    """stackable banquet chair in profile, teal fabric, chrome frame"""
    col = col or hx('#2b4446')
    f = facing
    seat = FY - 43
    c.occlude(x - 18, FY - 3, x + 18, FY + 1, 90, blur=2, ellipse=True)
    bx = x - 15 * f
    # legs (chrome)
    for lx0, lx1 in ((x - 13, x - 15), (x + 12, x + 14)):
        c.line([(lx0, seat + 2), (lx1, FY)], hx('#6a6f72'), 1.3)
    c.line([(bx, seat - 46 + askew), (bx + 2 * f, seat)], hx('#6a6f72'), 1.3)
    # seat
    c.rrect(x - 17, seat - 5, x + 16, seat + 2, 2, col, OUT, 0.8)
    # backrest
    c.poly([(bx - 3, seat - 4), (bx + 4, seat - 4), (bx + 4 + 3 * -f, seat - 46 + askew), (bx - 3 + 3 * -f, seat - 48 + askew)], col, OUT)
    c.vline(bx, seat - 44 + askew, seat - 6, lit(col, .12), 0.6)
    if item == 'leaflet':
        c.poly([(x - 6, seat - 5), (x + 8, seat - 6), (x + 9, seat - 4.5), (x - 5, seat - 3.5)], hx('#8a8c86'), OUT)
    elif item == 'jacket':
        c.poly([(bx - 5, seat - 46), (bx + 6, seat - 47), (bx + 7, seat - 10), (bx + 1, seat - 4), (bx - 6, seat - 14)], hx('#2c2a28'), OUT)
    elif item == 'mic':                                                                 # armrest mini mic
        c.line([(x + 14 * f, seat - 2), (x + 16 * f, seat - 14)], hx('#2a2d30'), 0.9)
        c.ell(x + 16 * f - 2, seat - 17, x + 16 * f + 2, seat - 13, hx('#1b1d1f'))
        led(c, x + 16 * f, seat - 15, RED, 0.35, 0.4)


def fallen_banquet_chair(c, x, col=None):
    col = col or hx('#2b4446')
    c.occlude(x - 30, FY - 5, x + 30, FY + 1, 110, blur=2, ellipse=True)
    c.rrect(x - 28, FY - 9, x + 18, FY - 2, 2, col, OUT, 0.8)                         # backrest on the floor
    c.rrect(x + 14, FY - 40, x + 21, FY - 6, 2, col, OUT, 0.8)                        # seat vertical
    for ly in (FY - 36, FY - 12):
        c.line([(x + 21, ly), (x + 44, ly - 4)], hx('#6a6f72'), 1.3)


def chair_dolly(c, x, n=9, col=None):
    col = col or hx('#2b4446')
    c.occlude(x - 4, FY - 6, x + 56, FY + 1, 100, blur=2)
    c.box(x - 4, FY - 8, x + 56, FY - 4, hx('#3a3e41'), outline=OUT)
    for wx in (x, x + 44):
        c.ell(wx, FY - 6, wx + 7, FY, hx('#121416'), OUT, 0.4)
    for k in range(n):
        yy = FY - 10 - k * 9
        c.rrect(x + k * 0.6, yy - 6, x + 36 + k * 0.6, yy, 2, col, OUT, 0.6)
        c.line([(x + 34 + k * 0.6, yy - 4), (x + 40 + k * 0.6, yy - 42)], hx('#6a6f72'), 1)
    c.poly([(x + 36 + n * 0.6, FY - 10 - n * 9 - 6), (x + 44 + n * 0.6, FY - 10 - n * 9 - 6), (x + 50, FY - 10 - n * 9 - 52), (x + 42, FY - 10 - n * 9 - 54)], col, OUT)


def pa_speaker(c, x, on_stand=True, top=None):
    if on_stand:
        top = top or FY - 150
        c.line([(x, top + 40), (x, FY - 30)], hx('#4a4e51'), 1.6)
        for dx in (-20, 20):
            c.line([(x, FY - 30), (x + dx, FY)], hx('#4a4e51'), 1.2)
    c.box(x - 18, top, x + 18, top + 44, hx('#141516'), outline=OUT, hl=.08)
    c.rect(x - 15, top + 3, x + 15, top + 41, hx('#1b1c1e'))
    for yy in np.arange(top + 5, top + 40, 2.5):
        c.hline(x - 14, x + 14, yy, hx('#232527'), 0.6)


def stage_wedge(c, x, top_y, facing=-1):
    f = facing
    pts = [(x - 20, top_y), (x + 20, top_y), (x + 20 * -f, top_y - 22), (x + 6 * -f, top_y - 24)]
    c.poly([(x - 22, top_y), (x + 22, top_y), (x + 22 * -f, top_y - 22), (x + 4 * -f, top_y - 24)], hx('#151617'), OUT)


def line_array(c, x, y, n=4):
    c.vline(x - 10, 212, y, hx('#3a3e41'), 0.8); c.vline(x + 10, 212, y, hx('#3a3e41'), 0.8)
    for k in range(n):
        yy = y + k * 14
        c.poly([(x - 20 + k * 1.5, yy), (x + 20 + k * 1.5, yy), (x + 20 + (k + 1) * 1.5, yy + 13), (x - 20 + (k + 1) * 1.5, yy + 13)], hx('#151617'), OUT)
        c.rect(x - 16 + k * 1.5, yy + 3, x + 16 + k * 1.5, yy + 10, hx('#1d1f20'))


def truss(c, x0, x1, y, h=14):
    c.hline(x0, x1, y, hx('#5a5e61'), 1.4)
    c.hline(x0, x1, y + h, hx('#5a5e61'), 1.4)
    k = 0
    for x in np.arange(x0, x1, h):
        a = (x, y) if k % 2 == 0 else (x, y + h)
        b = (x + h, y + h) if k % 2 == 0 else (x + h, y)
        c.line([a, b], hx('#4a4e51'), 0.8)
        k += 1
    for x in (x0 + 20, x1 - 20):
        c.vline(x, 212, y, hx('#3a3e41'), 0.8)


def par_can(c, x, y, aim=1):
    c.rect(x - 1, y, x + 1, y + 6, hx('#4a4e51'))
    c.poly([(x - 6, y + 6), (x + 6, y + 6), (x + 6 + 5 * aim, y + 24), (x - 6 + 5 * aim, y + 24)], hx('#1b1c1e'), OUT)


def hanging_mic(c, x, y):
    c.vline(x, 212, y, hx('#5a5e61'), 0.4)
    c.rrect(x - 2, y, x + 2, y + 9, 1, hx('#1b1d1f'), OUT, 0.4)
    led(c, x, y + 11, RED, 0.35, 0.35)


def foh_desk(c, x0, x1):
    top = FY - 76
    c.occlude(x0 - 3, top, x1 + 3, FY, 100, blur=4); c.apply_shade_now()
    c.box(x0, top, x1, top + 5, hx('#2a2c2e'), outline=OUT, hl=.15)
    c.vgrad(x0 + 2, top + 5, x1 - 2, FY, hx('#141516'), hx('#101112'))                # black drape
    for x in np.arange(x0 + 6, x1, 7):
        c.vline(x, top + 6, FY - 1, hx('#1c1d1f'), 0.6)
    c.poly([(x0 + 6, top), (x0 + 84, top), (x0 + 80, top - 12), (x0 + 10, top - 10)], hx('#24272a'), OUT)   # mixer
    for k in range(11):
        fx = x0 + 14 + k * 6
        c.vline(fx, top - 10, top - 2, hx('#111214'), 0.8)
        c.rect(fx - 1.5, top - 8 + (k * 3 % 5), fx + 1.5, top - 6.6 + (k * 3 % 5), hx('#8a8f92'))
    laptop(c, x1 - 26, top, 28, 'off', seed=5)


def receiver_cart(c, x):
    c.occlude(x - 3, FY - 92, x + 54, FY, 90, blur=3)
    for lx in (x, x + 48):
        c.box(lx, FY - 90, lx + 3, FY - 4, hx('#4f575d'), outline=OUT)
    for yy in (FY - 88, FY - 50, FY - 14):
        c.box(x, yy, x + 51, yy + 3, hx('#59616a'), outline=OUT)
    for k in range(3):                                                                   # receivers
        yy = FY - 88 - 7 - k * 7
        c.box(x + 4, yy, x + 47, yy + 7, hx('#1d2023'), outline=OUT, hl=.1)
        for j in range(5):
            led(c, x + 9 + j * 6, yy + 3.5, RED if j == k else GREEN, 0.4, 0.35)
        c.line([(x + 44, yy), (x + 46, yy - 8)], hx('#2a2d30'), 0.6)
    c.box(x + 6, FY - 50 - 22, x + 44, FY - 50, hx('#2a2d30'), outline=OUT)            # recorder
    c.rect(x + 10, FY - 66, x + 26, FY - 60, hx('#0f1a1f'))
    for wx in (x + 1, x + 44):
        c.ell(wx, FY - 5, wx + 6, FY, hx('#15181b'), OUT, 0.4)
    for r in range(3):
        c.ell(x + 8 - r, FY - 40 + r, x + 40 + r, FY - 18 + r, None, hx('#16191c'), 1)


def wall_sconce(c, x, y):
    c.box(x - 4, y, x + 4, y + 18, GOLD, outline=OUT, hl=.3)
    c.poly([(x - 9, y - 6), (x + 9, y - 6), (x + 6, y + 6), (x - 6, y + 6)], hx('#4a463c'), OUT)


# ============================================================ SERVER ROOM
def sterile_wall(c, x0, y0, x1, y1):
    base = hx('#59616a')
    c.vgrad(x0, y0, x1, y1, lit(base, .04), dk(base, .1))
    for x in np.arange(x0 + 60, x1, 118):
        c.vline(x, y0, y1, dk(base, .22), 0.8)
        c.vline(x + 0.8, y0, y1, lit(base, .1), 0.4)
    c.box(x0, y1 - 10, x1, y1, dk(base, .35), outline=None)


def crac_unit(c, x, w=96, h=186):
    top = FY - h
    c.occlude(x - 3, top, x + w + 3, FY, 110, blur=5); c.apply_shade_now()
    col = hx('#6a7277')
    c.box(x, top, x + w, FY, col, outline=OUT, hl=.08, sh=.3)
    for k in range(3):
        px = x + 4 + k * (w - 8) / 3
        c.rect(px, top + 4, px + (w - 8) / 3 - 2, FY - 6, None, dk(col, .3), 0.6)
    for yy in np.arange(top + 10, top + 70, 3):
        c.hline(x + 8, x + w - 8, yy, dk(col, .3), 0.7)
    c.rect(x + w / 2 - 14, top + 82, x + w / 2 + 14, top + 98, hx('#0f1a20'))
    c.rect(x + w / 2 - 12, top + 84, x + w / 2 + 2, top + 89, hx('#5fa0c0'))
    c.glow_rect(x + w / 2 - 14, top + 82, x + w / 2 + 14, top + 98, hx('#5fa0c0'), 0.4, blur=5)
    led(c, x + w / 2 + 8, top + 92, AMBER, 0.6, 0.5)


def gas_cylinders(c, x):
    c.occlude(x - 3, FY - 150, x + 46, FY, 100, blur=4)
    for k in range(2):
        cx = x + 10 + k * 22
        c.rrect(cx - 9, FY - 134, cx + 9, FY - 2, 8, hx('#6e2a26'), OUT, 1)
        c.vline(cx - 5, FY - 126, FY - 10, hx('#8e3a34'), 1.2)
        c.box(cx - 4, FY - 146, cx + 4, FY - 132, hx('#5a5e61'), outline=OUT)
        c.ell(cx - 5, FY - 150, cx + 5, FY - 144, hx('#3a3e41'), OUT, 0.5)
        c.rect(cx - 7, FY - 90, cx + 7, FY - 70, hx('#8a8c86'))
    c.box(x - 2, FY - 108, x + 46, FY - 104, hx('#4a4e51'), outline=OUT)   # restraint strap
    c.bezier((x + 10, FY - 150), (x + 20, FY - 180), (x + 40, FY - 200), hx('#5a5e61'), 1.2)


def server_cart(c, x, w=70):
    c.occlude(x - 2, FY - 76, x + w + 2, FY, 100, blur=3)
    for lx in (x, x + w - 3):
        c.box(lx, FY - 74, lx + 3, FY - 5, hx('#59616a'), outline=OUT)
    c.box(x - 6, FY - 78, x + 4, FY - 74, hx('#59616a'), outline=OUT)
    for yy in (FY - 44, FY - 10):
        c.box(x, yy, x + w, yy + 3, hx('#6a7277'), outline=OUT)
    for k in range(4):                                                   # pulled servers (migrated)
        server_1u_c(c, x + 3, FY - 44 - k * 8, w - 6)
    for k in range(2):
        server_1u_c(c, x + 3, FY - 10 - k * 8, w - 6)
    for wx in (x + 2, x + w - 8):
        c.ell(wx, FY - 6, wx + 6, FY, hx('#15181b'), OUT, 0.4)
    # migration worksheet clipped to the handle
    c.box(x - 16, FY - 92, x - 2, FY - 72, hx('#5e5242'), outline=OUT)
    c.rect(x - 14, FY - 90, x - 4, FY - 74, hx('#808380'))
    for k in range(4):
        c.hline(x - 13, x - 5, FY - 87 + k * 3.5, hx('#4f5458'), 0.5)
        c.line([(x - 13, FY - 87 + k * 3.5 - 1), (x - 11, FY - 87 + k * 3.5 + 0.6)], hx('#3f7f74'), 0.5)   # ticked
    c.hline(x - 13, x - 5, FY - 77, hx('#8a3a33'), 0.6)                       # last line unticked, red


def server_1u_c(c, x, y_bottom, w):
    c.box(x, y_bottom - 7, x + w, y_bottom, hx('#3a4248'), outline=OUT, hl=.1)
    c.rect(x + 3, y_bottom - 5, x + 16, y_bottom - 2, hx('#1c2024'))
    c.rect(x + w - 18, y_bottom - 5.5, x + w - 4, y_bottom - 1.5, hx('#7f827d'))


def empty_rack(c, x, w=58, h=186, door_open=True, leftovers=0, seed=0):
    rng = random.Random(seed)
    top = FY - h
    c.occlude(x - 3, top, x + w + 3, FY, 110, blur=5)
    c.box(x, top, x + w, FY - 3, hx('#15181b'), outline=OUT, hl=.05)
    c.rect(x + 5, top + 7, x + w - 5, FY - 10, hx('#202529'))
    for rx in (x + 5, x + w - 7):
        c.rect(rx, top + 7, rx + 2, FY - 10, hx('#3a4146'))
        for yy in range(int(top + 9), int(FY - 12), 4):
            c.rect(rx + 0.5, yy, rx + 1.5, yy + 1, hx('#121518'))
    # leftover blanking panels + dangling cables where servers were pulled
    for k in range(leftovers):
        yy = top + 20 + rng.uniform(0, h - 60)
        c.box(x + 6, yy, x + w - 6, yy + 4, hx('#1a1d20'), outline=None)
    for k in range(6):
        cx = x + 10 + rng.uniform(0, w - 20)
        col = rng.choice([hx('#3e6aa0'), hx('#b39a4a'), hx('#7a8a92'), hx('#15181b')])
        c.bezier((cx, top + 8), (cx + rng.uniform(-10, 10), top + 60 + rng.uniform(0, 40)), (cx + rng.uniform(-6, 6), top + 30 + rng.uniform(0, 90)), dk(col, .2), 0.8)
    c.rect(x + 2, FY - 3, x + 8, FY, OUT); c.rect(x + w - 8, FY - 3, x + w - 2, FY, OUT)
    if door_open:
        c.poly([(x + w, top + 2), (x + w + 14, top + 8), (x + w + 14, FY - 9), (x + w, FY - 4)], hx('#1a2026'), OUT)
        tpoly(c, [(x + w + 2, top + 8), (x + w + 12, top + 12), (x + w + 12, FY - 12), (x + w + 2, FY - 8)], hx('#6e8796'), 30)


def nas_disk_out(c, x, y):
    """one drive caddy half pulled out of the NAS"""
    c.box(x, y, x + 12, y + 5, hx('#3a4248'), outline=OUT, hl=.2)
    c.rect(x + 1, y + 1.5, x + 4, y + 3.5, hx('#8a3a33'))
    c.glow_rect(x - 2, y - 2, x + 14, y + 7, hx('#c0574a'), 0.25, blur=4)


def containment_roof(c, x0, x1, y):
    c.box(x0, y - 4, x1, y, hx('#4a5258'), outline=OUT, hl=.2)
    tdraw(c, (x0, y - 18, x1, y - 4), lambda od, ox, oy: od.rectangle([P(x0) + ox, P(y - 18) + oy, P(x1) + ox, P(y - 4) + oy], fill=(150, 185, 200, 40)))
    for x in np.arange(x0, x1 + 1, 62):
        c.vline(x, y - 18, y, hx('#5a6266'), 1)
    c.hline(x0, x1, y - 18, hx('#6a7276'), 0.8)


def env_panel(c, x, y):
    c.box(x, y, x + 34, y + 26, hx('#7a8085'), outline=OUT, hl=.08)
    c.rect(x + 4, y + 4, x + 30, y + 14, hx('#0f1a20'))
    c.rect(x + 6, y + 6, x + 18, y + 8, hx('#6fb0d0')); c.rect(x + 6, y + 10, x + 14, y + 12, hx('#d98a5a'))
    c.glow_rect(x + 4, y + 4, x + 30, y + 14, hx('#6fb0d0'), 0.35, blur=4)
    led(c, x + 27, y + 20, GREEN, 0.5, 0.4)


def fiber_runner(c, x0, x1, y):
    c.box(x0, y, x1, y + 7, hx('#a08a3c'), outline=OUT, hl=.2, sh=.4)
    for x in np.arange(x0 + 40, x1, 160):
        c.vline(x, 212, y, hx('#3a3e41'), 0.6)


# ============================================================ LOUNGE
def tree_window(c, x0, y0, x1, y1, seed=0):
    """2nd-floor window filled with street-tree canopy and a sodium lamp head"""
    rng = random.Random(seed)
    c.vgrad(x0, y0, x1, y1, hx('#10151b'), hx('#1d1a17'))
    lamp = (x0 + (x1 - x0) * 0.62, y0 + (y1 - y0) * 0.40)
    paint_glow(c, (x0, y0, x1, y1), ('ell', lamp[0], lamp[1], 80, 64), hx('#a88866'), 0.45, blur=30)
    # a sliver of the facade across the street on the left
    c.rect(x0, y0, x0 + 70, y1, hx('#1b1f24'))
    for yy in np.arange(y0 + 14, y1, 30):
        for xx in np.arange(x0 + 8, x0 + 64, 22):
            c.rect(xx, yy, xx + 12, yy + 16, dk(hx('#c4ab7c'), .55) if rng.random() < .2 else hx('#15181b'))
    # lamp pole + head
    c.box(lamp[0] + 40, lamp[1] - 6, lamp[0] + 44, y1, hx('#151617'), outline=None)
    c.box(lamp[0] - 4, lamp[1] - 10, lamp[0] + 44, lamp[1] - 6, hx('#151617'), outline=None)
    c.poly([(lamp[0] - 14, lamp[1] - 8), (lamp[0] + 10, lamp[1] - 8), (lamp[0] + 6, lamp[1] + 2), (lamp[0] - 10, lamp[1] + 2)], hx('#1b1b1c'))
    c.rect(lamp[0] - 9, lamp[1] + 1, lamp[0] + 5, lamp[1] + 3, hx('#e2c08a'))
    paint_glow(c, (x0, y0, x1, y1), ('ell', lamp[0] - 2, lamp[1] + 4, 18, 9), hx('#e0b880'), 0.7, blur=7)
    # branches (curved, tapering, behind most of the foliage)
    for k in range(4):
        bx = x0 + 60 + k * (x1 - x0 - 120) / 3 + rng.uniform(-30, 30)
        p0 = (bx, y1 + 4); p1 = (bx + rng.uniform(-60, 60), y1 - rng.uniform(80, 130)); p2 = (bx + rng.uniform(-120, 120), y0 + rng.uniform(0, 60))
        c.bezier(p0, p1, p2, hx('#0b0d0b'), 3.2 - k * 0.3)
        mid = ((p0[0] + p2[0]) / 2, (p0[1] + p2[1]) / 2)
        c.bezier(mid, (mid[0] + rng.uniform(-40, 40), mid[1] - 30), (mid[0] + rng.uniform(-90, 90), mid[1] - rng.uniform(40, 80)), hx('#0b0d0b'), 1.4)
    # canopy: clusters of small leaves, warmed only where the lamp reaches
    clusters = []
    for k in range(34):
        cx = rng.uniform(x0 - 10, x1 + 10); cy = rng.uniform(y0 - 10, y1 + 10)
        if math.hypot(cx - lamp[0], (cy - lamp[1]) * 1.4) < 52:
            continue
        clusters.append((cx, cy, rng.uniform(18, 34)))
    for cx, cy, spread in clusters:
        for j in range(46):
            lx = cx + rng.gauss(0, spread * 0.55); ly = cy + rng.gauss(0, spread * 0.4)
            if not (x0 <= lx <= x1 and y0 <= ly <= y1):
                continue
            d = math.hypot(lx - lamp[0], (ly - lamp[1]) * 1.3)
            warm = max(0.0, 1 - d / 150) ** 1.6
            col = mix(mix(hx('#0a0e0b'), hx('#141a13'), rng.random()), hx('#5a5236'), warm * 0.85)
            rx = rng.uniform(2.5, 5.5); ry = rng.uniform(1.6, 3.6)
            c.ell(max(x0, lx - rx), max(y0, ly - ry), min(x1, lx + rx), min(y1, ly + ry), col)


def sheer_curtain(c, x0, x1, y0, y1, alpha=150):
    k = 0
    xx = x0
    while xx < x1:
        w = 6 + (k % 2) * 3
        col = hx('#6a6862') if k % 2 else hx('#5a5852')
        tdraw(c, (xx, y0, min(xx + w, x1), y1), lambda od, ox, oy, xx=xx, w=w, col=col: od.rectangle(
            [P(xx) + ox, P(y0) + oy, P(min(xx + w, x1)) + ox, P(y1) + oy], fill=wa(col, alpha)))
        xx += w; k += 1


def vending(c, x, w=92, kind='drink', seed=0):
    rng = random.Random(seed)
    h = 176
    top = FY - h
    c.occlude(x - 3, top, x + w + 3, FY, 115, blur=5); c.apply_shade_now()
    body = hx('#2f3a44') if kind == 'drink' else hx('#3a3530')
    c.box(x, top, x + w, FY - 2, body, outline=OUT, hl=.08, sh=.3)
    gx0, gx1 = x + 6, x + w - (26 if kind == 'drink' else 30)
    c.rect(gx0, top + 8, gx1, FY - 46, hx('#0e1214'))
    rows = 5 if kind == 'drink' else 6
    rh = (FY - 46 - top - 12) / rows
    for r in range(rows):
        ry = top + 10 + r * rh
        c.hline(gx0 + 1, gx1 - 1, ry + rh - 2, hx('#3a4146'), 0.8)
        xx = gx0 + 3
        while xx < gx1 - 8:
            if kind == 'drink':
                col = rng.choice([hx('#5a3a36'), hx('#3a5a4a'), hx('#4a4a5a'), hx('#6a5a3a'), hx('#3a4a5a')])
                bh = rh * rng.uniform(.55, .78)
                c.rrect(xx, ry + rh - 2 - bh, xx + 6, ry + rh - 2, 1.5, dk(col, .2), OUT, 0.4)
                xx += 8
            else:
                for t in range(3):                                         # spiral coil
                    c.ell(xx, ry + rh - 8 - t * 0.5, xx + 7, ry + rh - 3, None, hx('#5a5e61'), 0.5)
                if rng.random() < 0.75:
                    col = rng.choice([hx('#6a4a3a'), hx('#5a5a3a'), hx('#3a4a5a'), hx('#6a3a3a')])
                    c.box(xx, ry + 3, xx + 8, ry + rh - 6, dk(col, .2), outline=OUT, hl=.1)
                xx += 11
    tdraw(c, (gx0, top + 8, gx1, FY - 46), lambda od, ox, oy: od.rectangle([P(gx0) + ox, P(top + 8) + oy, P(gx1) + ox, P(FY - 46) + oy], fill=(12, 16, 18, 120)))
    reflection(c, gx0, top + 8, gx1, FY - 46, 22, 0.2, 0.25)
    # control column
    cx0 = gx1 + 4
    c.rect(cx0, top + 20, x + w - 5, top + 32, hx('#121618'))
    c.rect(cx0 + 2, top + 40, x + w - 7, top + 66, hx('#2a2f33'))
    for r in range(4):
        for k in range(2):
            c.rect(cx0 + 4 + k * 8, top + 44 + r * 5, cx0 + 8 + k * 8, top + 47 + r * 5, hx('#4a5055'))
    c.rect(cx0 + 4, top + 74, x + w - 9, top + 78, hx('#0b0c0d'))           # coin slot
    c.box(x + 10, FY - 38, gx1 - 6, FY - 14, hx('#1b1e21'), outline=OUT)     # pickup bay
    led(c, x + w - 12, top + 26, RED, 0.5, 0.4)


def sofa(c, x0, x1, col=hx('#3a3f42')):
    c.occlude(x0 - 2, FY - 6, x1 + 2, FY + 1, 120, blur=3)
    c.rrect(x0, FY - 80, x1, FY - 40, 6, dk(col, .1), OUT, 1)                # backrest
    c.rrect(x0 - 6, FY - 56, x0 + 18, FY - 12, 5, col, OUT, 1)               # arms
    c.rrect(x1 - 18, FY - 56, x1 + 6, FY - 12, 5, col, OUT, 1)
    c.rrect(x0 + 14, FY - 44, x1 - 14, FY - 26, 4, lit(col, .05), OUT, 1)    # seat cushions
    c.vline((x0 + x1) / 2, FY - 44, FY - 26, OUT, 0.8)
    c.box(x0 - 4, FY - 26, x1 + 4, FY - 10, dk(col, .25), outline=OUT)
    for lx in (x0 + 6, x1 - 12):
        c.rect(lx, FY - 10, lx + 6, FY, hx('#2a241e'))
    # throw cushion + folded blanket
    c.rrect(x0 + 24, FY - 66, x0 + 52, FY - 42, 6, hx('#4a5a5a'), OUT, 0.8)
    c.poly([(x1 - 70, FY - 44), (x1 - 24, FY - 46), (x1 - 20, FY - 30), (x1 - 34, FY - 22), (x1 - 66, FY - 32)], hx('#5a4a3e'), OUT)


def coffee_table(c, x0, x1):
    top = FY - 40
    c.occlude(x0, FY - 4, x1, FY + 1, 100, blur=3)
    c.box(x0, top, x1, top + 5, hx('#4a3a2c'), outline=OUT, hl=.25)
    for lx in (x0 + 8, x1 - 14):
        c.box(lx, top + 5, lx + 6, FY, hx('#2a241e'), outline=OUT)
    c.box(x0 + 10, FY - 14, x1 - 10, FY - 11, hx('#3a2e24'), outline=OUT)
    mug(c, x0 + 30, top, hx('#5e6870'))
    c.box(x0 + 50, top - 3, x0 + 84, top, hx('#5a6a72'), outline=OUT)       # magazines
    c.box(x0 + 54, top - 5, x0 + 86, top - 3, hx('#6a5a4a'), outline=OUT)
    c.rrect(x1 - 40, top - 2, x1 - 26, top, 1, hx('#121518'), OUT, 0.4)     # phone face-down
    c.glow_rect(x1 - 41, top - 0.5, x1 - 25, top + 1.5, hx('#8ab0c8'), 0.25, blur=2)


def armchair(c, x0, x1, col=hx('#40453f')):
    c.occlude(x0 - 2, FY - 6, x1 + 2, FY + 1, 110, blur=3)
    c.rrect(x0 + 6, FY - 78, x1 - 6, FY - 38, 8, dk(col, .1), OUT, 1)
    c.rrect(x0 - 4, FY - 54, x0 + 16, FY - 14, 5, col, OUT, 1)
    c.rrect(x1 - 16, FY - 54, x1 + 4, FY - 14, 5, col, OUT, 1)
    c.rrect(x0 + 12, FY - 42, x1 - 12, FY - 26, 4, lit(col, .05), OUT, 1)
    c.box(x0, FY - 26, x1, FY - 12, dk(col, .25), outline=OUT)
    for lx in (x0 + 4, x1 - 10):
        c.rect(lx, FY - 12, lx + 6, FY, hx('#2a241e'))


def floor_lamp(c, x):
    c.box(x - 10, FY - 4, x + 10, FY, hx('#2a2d30'), outline=OUT)
    c.vline(x, FY - 150, FY - 4, hx('#4a4e51'), 1.2)
    c.poly([(x - 16, FY - 150), (x + 16, FY - 150), (x + 11, FY - 172), (x - 11, FY - 172)], hx('#5a554a'), OUT)


def concert_poster(c, x, y, w=72, h=96):
    """abstract recital poster: piano keys and a waveform, no lettering"""
    c.occlude(x + 1, y + 2, x + w + 2, y + h + 3, 80, blur=3); c.apply_shade_now()
    c.box(x - 3, y - 3, x + w + 3, y + h + 3, GOLD, outline=OUT, hl=.3)
    c.vgrad(x, y, x + w, y + h, hx('#1d3436'), hx('#122224'))
    ky = y + h - 30
    c.rect(x + 6, ky, x + w - 6, ky + 20, hx('#8a8c86'))
    for k in range(10):
        kx = x + 6 + k * (w - 12) / 10
        c.vline(kx, ky, ky + 20, hx('#3a3c3a'), 0.6)
        if k % 7 not in (2, 6):
            c.rect(kx + 3, ky, kx + 7, ky + 12, hx('#151617'))
    pts = [(x + 8 + i * (w - 16) / 30, y + 34 + math.sin(i * 0.8) * (4 + i * 0.4)) for i in range(31)]
    c.line(pts, GOLD_L, 0.9)
    c.ell(x + w / 2 - 8, y + 10, x + w / 2 + 8, y + 22, None, GOLD_L, 0.8)
    # someone's pen note in the margin
    c.line([(x + 8, y + h - 6), (x + 18, y + h - 8), (x + 26, y + h - 5)], hx('#2f4766'), 0.6)


def wood_slat_ceiling(c, x0, x1, y):
    c.rect(x0, y - 4, x1, y + 8, hx('#1a1612'))
    for x in np.arange(x0 + 2, x1 - 4, 9):
        c.box(x, y - 2, x + 6, y + 8, hx('#5a4636'), outline=None, hl=.2, sh=.3)
    c.hline(x0, x1, y + 8, OUT, 0.6)


def pendant_lamp(c, x, y, top):
    c.vline(x, top, y, hx('#3a3e41'), 0.5)
    c.poly([(x - 3, y), (x + 3, y), (x + 13, y + 14), (x - 13, y + 14)], hx('#2c2a26'), OUT)
    c.hline(x - 12, x + 12, y + 14, hx('#4a463e'), 0.8)
