import random, math, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageChops
from lib import *
from objects import *
from objects5 import partition
from objects10 import *

X0, X1 = 48, 3152
IX0, IX1 = 78, 3122
TS0, TS1 = 180, 212
FB = 626
MG = (IX0, 1280); P1 = (1280, 1300)
MR = (1300, 2280); P2 = (2280, 2304)
EX = (2304, IX1)
CLG, CLM, CLE = 296, 300, 300

c = Canvas()
exec(open('reuse.py').read().split('\n', 4)[4], globals())


def hatch(x0, y0, x1, y1, col=hx('#3a4440'), step=9):
    def f(od, ox, oy):
        for k in range(int(-(y1 - y0)), int(x1 - x0), step):
            od.line([(P(x0 + k) + ox, P(y1) + oy), (P(x0 + k + (y1 - y0)) + ox, P(y0) + oy)], fill=wa(col, 70), width=P(0.8))
    tdraw(c, (x0, y0, x1, y1), f)


# ------------------------------------------------------------------ shell
def shell():
    c.vgrad(IX0, TS1, IX1, 300, hx('#0e1412'), hx('#151c1a'))
    jade_wall(c, MG[0], CLG, MG[1], FY, wains=440)
    jade_wall(c, MR[0], CLM, MR[1], FY, wains=440)
    jade_wall(c, EX[0], CLE, EX[1], FY, wains=440)
    c.vgrad(P1[0], CLG, P1[1], FY, hx('#141c19'), hx('#1a2320'))
    # floors: jade carpet tiles, darker board-room carpet, dark wood in the executive office
    c.rect(IX0, FY, IX1, FY + 8, hx('#141c19'))
    c.rect(MG[0], FY, P1[1], FY + 6, hx('#17201d'))
    for x in np.arange(MG[0], P1[1], 160):
        c.vline(x, FY, FY + 6, hx('#26302c'), 0.8)
    c.rect(MR[0], FY, MR[1], FY + 6, hx('#121a17'))
    c.rect(P2[0] - 6, FY, EX[1], FY + 6, hx('#2e2018'))
    for x in np.arange(P2[0], EX[1], 58):
        c.vline(x, FY, FY + 6, hx('#1e140e'), 0.7)
    c.hline(IX0, P2[0] - 6, FY, hx('#b3a784'), 0.8)
    c.hline(P2[0] - 6, EX[1], FY, hx('#6a4a36'), 0.8)
    # slab + cuts
    c.vgrad(X0, FY + 6, X1, FB, hx('#212624'), hx('#171b19'))
    for x in (P1[0] - 20, P2[0] - 18):
        c.vgrad(x, FB - 2, x + 60, FB + 14, hx('#1d2220'), hx('#141816'))
        c.rect(x, FB - 2, x + 60, FB + 14, None, OUT, 1)
    c.vgrad(X0, TS0, X1, TS1, hx('#282d2b'), hx('#1c201e'))
    c.vgrad(X0, TS0, IX0, FB, hx('#272c2a'), hx('#1c201e'))
    c.vgrad(IX1, TS0, X1, FB, hx('#272c2a'), hx('#1c201e'))
    for a in ((X0, TS0, X1, TS1), (X0, FY + 6, X1, FB), (X0, TS0, IX0, FB), (IX1, TS0, X1, FB)):
        hatch(*a)
    c.hline(X0, X1, TS0, hx('#4e5652'), 1)
    c.hline(IX0, IX1, TS1, hx('#0b0e0d'), 1)
    c.vline(IX0 - 1, TS1, FY, hx('#2c3330'), 1)
    c.vline(IX1, TS1, FY, hx('#0c0f0e'), 1)
    c.hline(X0, X1, FB - 1, hx('#2b302e'), 1)


def ceilings():
    c.box(IX0, 220, IX1, 238, hx('#323836'), outline=OUT, hl=.12, sh=.35)
    for x in range(int(IX0) + 80, int(IX1), 120):
        c.box(x, 219, x + 3, 239, hx('#3e4542'), outline=None, hl=.1)
    c.box(IX0, 244, IX1, 247.5, hx('#5a3a36'), outline=OUT, hl=.15)
    # flat plaster ceilings, each with cream crown already on the wall
    for (a0, a1), cl in ((MG, CLG), (MR, CLM), (EX, CLE)):
        c.box(a0, cl - 8, a1, cl, hx('#3a403d'), outline=OUT, hl=.08)
    for x in np.arange(MG[0] + 40, MG[1] - 120, 220):
        c.rect(x, CLG - 1, x + 140, CLG + 1, hx('#1a1e1c'))
    # board room: a recessed rectangle over the table, downlights in it, one ceiling microphone
    c.rect(1360, CLM - 2, 2100, CLM, hx('#0e1210'))
    c.hline(1360, 2100, CLM, dk(BRASS, .3), 0.8)
    for x in np.arange(1420, 2080, 110):
        c.rect(x - 6, CLM - 1, x + 6, CLM + 1.2, hx('#1a1e1c'))
        c.rect(x - 4, CLM + 1.2, x + 4, CLM + 2, hx('#55605a'))
    c.vline(1740, CLM, CLM + 14, hx('#3a4040'), 0.5)
    c.ell(1730, CLM + 14, 1750, CLM + 19, hx('#2a2e2c'), OUT, 0.6)
    for x in (2440, 2700, 2980):
        c.rect(x - 6, CLE - 1, x + 6, CLE + 1.2, hx('#1a1e1c'))
        c.rect(x - 4, CLE + 1.2, x + 4, CLE + 2, hx('#55605a'))
    for x in range(int(IX0) + 110, int(IX1), 240):
        c.rect(x - 0.8, 247.5, x + 0.8, 300 + 3, hx('#5a3a36'))
        c.rect(x - 3, 303, x + 3, 304.5, hx('#8b8f91'))


# ------------------------------------------------------------------ management office
def steel_files(x, w=72, h=142):
    top = FY - h
    c.occlude(x - 3, top, x + w + 3, FY, 110, blur=4); c.apply_shade_now()
    col = hx('#3a423e')
    c.box(x, top, x + w, FY - 2, col, outline=OUT, hl=.08, sh=.3)
    for k in range(4):
        yy = top + 4 + k * (h - 8) / 4
        c.rect(x + 4, yy, x + w - 4, yy + (h - 8) / 4 - 3, None, dk(col, .35), 0.6)
        c.box(x + w / 2 - 10, yy + 8, x + w / 2 + 10, yy + 11, hx('#7a807c'), outline=None)
        c.rect(x + 8, yy + 6, x + 22, yy + 12, dk(PAPER, .15))
    return top


def management():
    TOP = FY - 69
    for wx in (480, 680, 880):
        punched_window(c, wx, 316, wx + 80, 430, city_fn=city, seed=wx, blind_drop=[0.35, 0.6, 0.2][(wx - 480) // 200])
    settlement_board(c, 1000, 322, 1262, 428)
    c.ell(1110, 300, 1134, 318, hx('#2a2e2c'), OUT, 0.8)                      # wall clock above the board
    c.ell(1112, 302, 1132, 316, hx('#7b7f78'))
    c.line([(1122, 309), (1127, 309.5)], hx('#1b1e1c'), 1); c.line([(1122, 309), (1122, 304)], hx('#1b1e1c'), 0.7)
    for k, x in enumerate((96, 172, 248)):
        t = steel_files(x)
        if k == 1:
            binders(c, x + 6, t, 7, seed=4, h=28, lean_last=True)
    display_cabinet10(c, 330, 100, 170)
    rng = random.Random(10)
    for x0, x1, seed in ((456, 800, 1), (820, 1150, 2)):
        desk(c, x0, x1, TOP, peds=('L', 'R'), seed=seed, col=hx('#4a3a2e'))
        cxs = [x0 + (x1 - x0) * 0.3, x0 + (x1 - x0) * 0.72]
        for i, cx in enumerate(cxs):
            monitor(c, cx, TOP, 50, 30, 'off', seed=seed * 10 + i, notes=rng.choice([0, 1]))
            keyboard(c, cx, TOP, 34); mouse(c, cx + 26, TOP)
            if seed == 1 and i == 1:
                adding_machine(c, cx + 34, TOP)
            elif seed == 2 and i == 0:
                power_bill(c, cx - 96, TOP)
            else:
                ledger_stack(c, cx - 70, TOP, rng.randint(2, 4), seed=seed + i)
            if i == 0:
                stamp_rack(c, cx + 34, TOP)
            for k in range(2):
                c.box(cx - 74, TOP - 5 - k * 5 - (14 if seed == 2 and i == 0 else 0), cx - 44, TOP - k * 5 - (14 if seed == 2 and i == 0 else 0), hx('#2e3432'), outline=OUT) if (seed == 1 and i == 0) else None
            chair_back(c, cx + 2, col=hx('#1a201e'))
        cable_to_floor(c, x0 + 70, TOP + 4, dx=-10)
    finance_drawer_key(c, 1092, TOP + 12)                                      # team lead's drawer, ajar
    shredder(c, 1160)
    small_safe(c, 1210)


# ------------------------------------------------------------------ executive meeting room
def meeting_room():
    TOP = FY - 72
    blackout_window(c, 1330, 316, 1560, 430, city_fn=city, seed=31)
    media_wall(c, 1600, CLM, 1980, FY, (1650, 336, 1930, 436))
    # side credenza with a glass tray and the conference audio hub
    c.occlude(2010, FY - 74, 2252, FY, 100, blur=4); c.apply_shade_now()
    c.box(2010, FY - 72, 2250, FY - 4, DWOOD, outline=OUT, hl=.08)
    for k in range(4):
        dx = 2014 + k * 59
        c.rect(dx, FY - 66, dx + 55, FY - 10, None, dk(DWOOD, .45), 0.6)
        c.box(dx + 24, FY - 58, dx + 32, FY - 56, BRASS, outline=None)
    c.box(2006, FY - 75, 2254, FY - 72, DWOOD_L, outline=OUT, hl=.25)
    c.box(2030, FY - 80, 2090, FY - 75, hx('#2a2c2a'), outline=OUT)
    for k in range(5):
        glass_water(c, 2040 + k * 10, FY - 80)
    c.box(2160, FY - 84, 2220, FY - 75, hx('#1d1f1e'), outline=OUT, hl=.12)        # audio hub
    for k in range(6):
        led(c, 2168 + k * 8, FY - 79, GREEN if k < 2 else hx('#2a2c2a'), 0.35, 0.3 if k < 2 else 0)
    # long board table, identical high-back chairs, the head chair in profile at the end
    board_table(c, 1340, 2120, TOP)
    seats = [1420, 1530, 1640, 1750, 1860, 1970]
    for x in seats:
        delegate_mic(c, x + 26, TOP)
        name_plate(c, x - 20, TOP)
        glass_water(c, x + 8, TOP)
        c.box(x - 34, TOP - 2, x - 6, TOP, hx('#2a3a34'), outline=OUT)        # aligned folder at every seat
    delegate_mic(c, 2090, TOP, live=True)
    carafe(c, 1585, TOP); carafe(c, 1805, TOP)
    for x in seats:
        high_back_chair(c, x)
    head_chair(c, 2180, facing=-1)


# ------------------------------------------------------------------ executive office
def executive():
    TOP = FY - 76
    secretary_desk(c, 2320, 2450)
    double_lock_cabinet(c, 2462, 84, 110)
    # draped window behind the executive desk
    wx0, wy0, wx1, wy1 = 2600, 316, 2860, 500
    city(wx0, wy0, wx1, wy1, seed=71)
    tdraw(c, (wx0, wy0, wx1, wy1), lambda od, ox, oy: od.rectangle([P(wx0) + ox, P(wy0) + oy, P(wx1) + ox, P(wy1) + oy], fill=(36, 50, 46, 50)))
    c.rect(wx0 - 8, wy0 - 8, wx1 + 8, wy0, CREAM); c.rect(wx0 - 8, wy1, wx1 + 8, wy1 + 6, CREAM)
    c.rect(wx0 - 8, wy0, wx0, wy1, CREAM); c.rect(wx1, wy0, wx1 + 8, wy1, CREAM)
    c.vline((wx0 + wx1) / 2 - 1.5, wy0, wy1, hx('#22282a'), 3)
    sheer(c, wx0 + 30, wx1 - 30, wy0 - 6, wy1 + 2)
    c.glow_rect(wx0, wy0, wx1, wy1, hx('#5a7080'), 0.16, blur=24)
    c.box(2556, 304, 2904, 309, hx('#3a3e3c'), outline=OUT, hl=.2)                 # curtain pole
    drapes(c, 2564, 2626, 309, FY - 10)
    drapes(c, 2834, 2896, 309, FY - 10)
    exec_chair_front(c, 2730, TOP)
    top = exec_desk(c, 2612, 2848)
    bankers_lamp(c, 2640, top)
    pending_folder(c, 2690, top)
    name_plate(c, 2760, top)
    pen_stand(c, 2786, top)
    desk_phone_led(c, 2830, top)
    guest_chair_back(c, 2668)
    guest_chair_back(c, 2794)
    coat_stand(c, 2558)
    glass_bookcase(c, 2906, 210, 200, seed=5)


def partitions_and_signs():
    # glass partition with dark wood frame between the office and the board room
    x0, x1 = P1
    c.box(x0 - 4, TS1, x1 + 4, CLG, DWOOD, outline=OUT, hl=.08)
    tdraw(c, (x0, CLG, x1, FY), lambda od, ox, oy: od.rectangle([P(x0) + ox, P(CLG) + oy, P(x1) + ox, P(FY) + oy], fill=(150, 170, 165, 44)))
    c.box(x0 - 2, CLG, x0 + 2, FY, DWOOD_L, outline=None, hl=.2)
    c.box(x1 - 2, CLG, x1 + 2, FY, DWOOD_L, outline=None, hl=.2)
    reflection(c, x0, CLG, x1, FY, 40, 0.1, 0.6)
    c.box(x0 - 5, FY - 5, x1 + 5, FY, DWOOD_L, outline=OUT)
    c.box(x0 - 9, FY - 212, x0 - 4, FY - 4, hx('#8a9a96'), outline=OUT)           # glass door open, edge-on
    c.box(x0 - 12, FY - 120, x0 - 9, FY - 84, BRASS, outline=OUT)
    # solid lacquered partition to the executive office
    partition(c, P2[0], P2[1], TS1, door_h=210, style='wood', door_side='R')
    ex = P1[0] - 56
    c.box(ex, 300, ex + 44, 316, hx('#1a2a1f'), outline=OUT)
    c.rect(ex + 2, 302, ex + 42, 314, hx('#2f6a45'))
    c.ell(ex + 27, 303.5, ex + 30, 306.5, hx('#cfe8d6'))
    c.line([(ex + 28, 307), (ex + 25, 311), (ex + 21, 313)], hx('#cfe8d6'), 0.9)
    c.line([(ex + 27, 308), (ex + 32, 310)], hx('#cfe8d6'), 0.8)
    c.line([(ex + 16, 308), (ex + 6, 308), (ex + 10, 305)], hx('#cfe8d6'), 0.8)
    c.glow_rect(ex, 300, ex + 44, 316, hx('#4fb57a'), 0.5, blur=14)
    for x, y in ((1260, CLG), (2260, CLM), (3100, CLE)):
        c.box(x - 9, y, x + 9, y + 3, hx('#4a4e4c'), outline=OUT)
        c.ell(x - 7, y - 2, x + 7, y + 11, hx('#1c201e'), OUT, 0.8)
        led(c, x + 2, y + 6, RED, 0.6, 0.6)


def finalize():
    arr = np.asarray(c.img, np.float32)
    h, w = arr.shape[:2]
    ys = np.linspace(0, 1, h)[:, None]
    xs = np.linspace(0, 1, w)[None, :]
    yy = (ys * H - TS1) / (FY - TS1)
    v = 1.0 - 0.28 * np.clip(1 - yy * 1.5, 0, 1) ** 1.5
    v *= 1.0 - 0.10 * np.clip((yy - 0.75) * 4, 0, 1)
    edge = np.minimum(xs, 1 - xs) * W
    v = v * (0.74 + 0.26 * np.clip(edge / 420.0, 0, 1))
    arr[:, :, :3] *= v[:, :, None]
    sh = np.asarray(c.shade, np.float32)[:, :, None] / 255.0
    arr[:, :, :3] *= (1 - sh * 0.85)
    L = np.asarray(c.light, np.float32) / 255.0
    base = arr[:, :, :3] / 255.0
    out = 1 - (1 - base) * (1 - L)
    lum = (out * np.array([0.299, 0.587, 0.114])).sum(axis=2, keepdims=True)
    out = out * 0.80 + lum * 0.20
    out = out * np.array([0.98, 1.0, 0.99])
    out = np.clip(out, 0, 1) ** 0.92
    out = np.clip((out - 0.5) * 1.10 + 0.5, 0, 1)
    arr[:, :, :3] = out * 255
    img = Image.fromarray(np.rint(arr).clip(0, 255).astype(np.uint8), 'RGBA').resize((W, H), Image.LANCZOS)
    a = np.asarray(img, np.float32)
    rng = np.random.default_rng(10)
    g = (rng.random((H, W)) - 0.5) * 7
    low = Image.fromarray((rng.random((H // 6, W // 6)) * 255).astype(np.uint8), 'L').resize((W, H), Image.BICUBIC)
    low = (np.asarray(low, np.float32) / 255 - 0.5) * 0.07
    a[:, :, :3] = a[:, :, :3] * (1 + low[:, :, None]) + g[:, :, None]
    alpha = np.where(a[:, :, 3] > 127, 255, 0)
    a[:, :, 3] = alpha
    a[:, :, :3] *= (alpha[:, :, None] > 0)
    img = Image.fromarray(np.rint(a).clip(0, 255).astype(np.uint8), 'RGBA')
    m = img.getchannel('A')
    inner = m.filter(ImageFilter.MinFilter(5))
    img.paste(Image.new('RGBA', img.size, (8, 10, 9, 255)), (0, 0), ImageChops.subtract(m, inner))
    inner2 = m.filter(ImageFilter.MinFilter(9))
    img.paste(Image.new('RGBA', img.size, (84, 96, 90, 255)), (0, 0), ImageChops.subtract(inner, inner2).point(lambda v: 150 if v else 0))
    bb = img.getchannel('A').getbbox()
    M = 48
    img = img.crop((bb[0] - M, bb[1] - M, bb[2] + M, bb[3] + M))
    print('bbox', bb, 'floor line y in output =', FY - (bb[1] - M), 'size', img.size)
    return img


def build():
    shell()
    c.noise_tex(MG[0], CLG, EX[1], FY, 0.05, 30, seed=1, streaks=True)
    c.noise_tex(X0, TS0, X1, TS1, 0.08, 16, seed=4)
    c.noise_tex(X0, FY, X1, FB, 0.08, 16, seed=5)
    c.noise_tex(IX0, TS1, IX1, 300, 0.08, 20, seed=6)
    for i, (x, y, w_, h_) in enumerate([(700, 450, 140, 80), (1450, 450, 120, 90), (2500, 330, 80, 100)]):
        c.stain(x, y, w_, h_, hx('#0e1311'), alpha=34, blur=10, seed=i + 100)
    ceilings()
    c.occlude(IX0, TS1, IX1, TS1 + 10, 150, blur=10)
    c.occlude(IX0, FY - 6, IX1, FY, 120, blur=6)
    c.occlude(IX0, TS1, IX0 + 10, FY, 140, blur=14)
    c.occlude(IX1 - 10, TS1, IX1, FY, 140, blur=14)
    for (x0, x1) in (P1, P2):
        c.occlude(x0 - 14, TS1, x0, FY, 110, blur=10)
        c.occlude(x1, TS1, x1 + 14, FY, 110, blur=10)
    c.apply_shade_now()
    management()
    meeting_room()
    executive()
    partitions_and_signs()
    return finalize()


if __name__ == '__main__':
    img = build()
    out = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/f10/floor10.png'
    img.save(out)
    print('saved', out)
