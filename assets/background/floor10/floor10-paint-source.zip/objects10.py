import random, math
import numpy as np
from PIL import Image, ImageDraw
from lib import *
from objects import *

JADE = hx('#22302b')
JADE_L = hx('#33463f')
CREAM = hx('#8f876a')        # cream moulding, as it reads in the dark
CREAM_L = hx('#b3a784')
BRASS = hx('#a48d5a')
DWOOD = hx('#2e2018')        # dark wood
DWOOD_L = hx('#4a3426')


# ============================================================ walls
def jade_wall(c, x0, y0, x1, y1, wains=440, panels=True):
    c.vgrad(x0, y0, x1, y1, dk(JADE, .18), JADE)
    if panels:
        # cream panel mouldings on the wainscot
        c.vgrad(x0, wains, x1, y1, dk(JADE, .1), dk(JADE, .25))
        for x in np.arange(x0 + 10, x1 - 60, 104):
            c.rect(x + 6, wains + 12, min(x + 98, x1 - 8), y1 - 18, None, dk(CREAM, .35), 1)
            c.rect(x + 7, wains + 13, min(x + 97, x1 - 9), y1 - 19, None, dk(JADE, .4), 0.5)
        c.box(x0, wains - 4, x1, wains, CREAM, outline=OUT, hl=.25, sh=.4)       # chair rail
    c.box(x0, y0, x1, y0 + 5, CREAM, outline=OUT, hl=.25, sh=.4)               # crown moulding
    c.box(x0, y1 - 9, x1, y1, dk(CREAM, .45), outline=None)
    c.hline(x0, x1, y1 - 9, CREAM, 0.6)


def wood_panel_wall(c, x0, y0, x1, y1, step=46):
    c.vgrad(x0, y0, x1, y1, DWOOD_L, DWOOD)
    for x in np.arange(x0, x1, step):
        c.vline(x, y0, y1, dk(DWOOD, .45), 1)
        c.vline(x + 1, y0, y1, lit(DWOOD_L, .08), 0.4)
    c.box(x0, y0, x1, y0 + 4, CREAM, outline=OUT, hl=.25)
    c.box(x0, y1 - 9, x1, y1, dk(DWOOD, .4), outline=None)


def punched_window(c, x0, y0, x1, y1, city_fn, seed=0, blind_drop=0.4):
    city_fn(x0, y0, x1, y1, seed=seed)
    tdraw(c, (x0, y0, x1, y1), lambda od, ox, oy: od.rectangle([P(x0) + ox, P(y0) + oy, P(x1) + ox, P(y1) + oy], fill=(36, 50, 46, 50)))
    reflection(c, x0, y0, x1, y1, 12, 0.3, 0.18)
    # deep reveal + cream architrave
    c.rect(x0 - 8, y0 - 8, x1 + 8, y0, CREAM); c.rect(x0 - 8, y1, x1 + 8, y1 + 6, CREAM)
    c.rect(x0 - 8, y0, x0, y1, CREAM); c.rect(x1, y0, x1 + 8, y1, CREAM)
    c.rect(x0 - 8, y0 - 8, x1 + 8, y1 + 6, None, OUT, 0.8)
    c.vline((x0 + x1) / 2 - 1.5, y0, y1, hx('#22282a'), 3)
    c.rect(x0, y0 + (y1 - y0) * 0.3, x1, y0 + (y1 - y0) * 0.3 + 3, hx('#22282a'))
    if blind_drop > 0:
        by = y0 + (y1 - y0) * blind_drop
        tdraw(c, (x0, y0, x1, by), lambda od, ox, oy: od.rectangle([P(x0) + ox, P(y0) + oy, P(x1) + ox, P(by) + oy], fill=(92, 88, 74, 215)))
        c.box(x0, by - 3, x1, by, hx('#4a4638'), outline=OUT)
        c.box(x0 - 2, y0, x1 + 2, y0 + 5, hx('#4a4638'), outline=OUT)
    c.glow_rect(x0, y0, x1, y1, hx('#4a6060'), 0.14, blur=18)


# ============================================================ management office
def settlement_board(c, x0, y0, x1, y1):
    c.occlude(x0 + 2, y0 + 3, x1 + 3, y1 + 5, 90, blur=4); c.apply_shade_now()
    c.rect(x0, y0, x1, y1, hx('#4f5650'))
    c.vgrad(x0 + 3, y0 + 3, x1 - 3, y1 - 3, hx('#6c726a'), hx('#5c625a'))
    ink = hx('#2b3034'); red = hx('#7b3a33'); blue = hx('#2f4766')
    for k in range(7):
        y = y0 + 14 + k * 12
        c.rect(x0 + 10, y - 4, x0 + 17, y + 3, None, ink, 0.7)                  # check box
        if k in (0, 1, 4):
            c.line([(x0 + 11, y), (x0 + 13, y + 2), (x0 + 17, y - 4)], hx('#3f6a5a'), 0.9)
        c.hline(x0 + 22, x0 + 22 + [110, 84, 130, 96, 70, 116, 90][k], y, ink, 0.8)
    # the power-cost item: three tally marks, circled
    y = y0 + 14 + 2 * 12
    for k in range(3):
        c.vline(x0 + 160 + k * 5, y - 5, y + 4, red, 0.9)
    c.ell(x0 + 18, y - 8, x0 + 180, y + 8, None, red, 0.9)
    # a separate column ruled off for one project's costs
    c.vline(x1 - 60, y0 + 8, y1 - 8, blue, 0.8)
    for k in range(5):
        c.hline(x1 - 52, x1 - 14, y0 + 16 + k * 12, blue, 0.7)
    c.rect(x0, y0, x1, y1, None, CREAM, 1); c.rect(x0, y0, x1, y1, None, OUT, 0.5)
    c.box(x0 + 6, y1, x1 - 6, y1 + 4, hx('#5e6458'), outline=OUT)


def display_cabinet10(c, x, w=100, h=170):
    """glass cabinet: plaques and one framed launch photo of a doorway with a small green sign"""
    top = FY - h
    c.occlude(x - 3, top, x + w + 3, FY, 115, blur=5); c.apply_shade_now()
    c.box(x, top, x + w, FY - 2, DWOOD, outline=OUT, hl=.1)
    c.rect(x + 5, top + 5, x + w - 5, FY - 36, hx('#0f1412'))
    rng = random.Random(6)
    for k in range(3):
        sy = top + 5 + (k + 1) * (h - 46) / 3
        c.rect(x + 5, sy - 2, x + w - 5, sy, hx('#5a6266'))
        xx = x + 9
        while xx < x + w - 24:
            pw = rng.uniform(16, 22); ph = (h - 46) / 3 * rng.uniform(.6, .8)
            if k == 1 and xx < x + 40:
                # framed photo: a dark corridor and a small green-lit sign above a door
                c.box(xx, sy - ph - 4, xx + 30, sy - 2, hx('#2a2a24'), outline=OUT)
                c.rect(xx + 3, sy - ph - 1, xx + 27, sy - 5, hx('#3a403c'))
                c.rect(xx + 10, sy - ph * 0.6, xx + 20, sy - 5, hx('#1a1c1a'))
                c.rect(xx + 11, sy - ph * 0.6 - 4, xx + 19, sy - ph * 0.6 - 1, hx('#4f8a68'))
                xx += 34
                continue
            c.poly([(xx, sy - 2), (xx + pw, sy - 2), (xx + pw + 3, sy - ph), (xx + 3, sy - ph)], rng.choice([DWOOD_L, hx('#3a2a22')]), OUT)
            c.rect(xx + 4, sy - ph + 5, xx + pw - 1, sy - ph * 0.45, dk(BRASS, .15))
            xx += pw + 3
    tdraw(c, (x + 5, top + 5, x + w - 5, FY - 36), lambda od, ox, oy: od.rectangle([P(x + 5) + ox, P(top + 5) + oy, P(x + w - 5) + ox, P(FY - 36) + oy], fill=(80, 96, 90, 34)))
    reflection(c, x + 5, top + 5, x + w - 5, FY - 36, 22, 0.15, 0.25)
    c.rect(x + 5, FY - 32, x + w - 5, FY - 6, None, dk(DWOOD, .4), 0.6)


def adding_machine(c, x, desk_y):
    """printing calculator with a long paper tape curling off the desk"""
    c.poly([(x, desk_y), (x + 26, desk_y), (x + 24, desk_y - 7), (x + 3, desk_y - 6)], hx('#3a3c3a'), OUT)
    for k in range(4):
        c.rect(x + 5 + k * 5, desk_y - 4, x + 8 + k * 5, desk_y - 2.5, hx('#5a5e5a'))
    c.rect(x + 8, desk_y - 12, x + 20, desk_y - 6, hx('#8a8c86'))                  # tape roll
    c.bezier((x + 14, desk_y - 12), (x + 32, desk_y - 22), (x + 34, desk_y + 2), hx('#8a8c86'), 1.6)
    c.bezier((x + 34, desk_y + 2), (x + 36, desk_y + 24), (x + 30, desk_y + 40), hx('#8a8c86'), 1.6)


def shredder(c, x):
    c.occlude(x - 2, FY - 56, x + 38, FY, 90, blur=3)
    c.box(x, FY - 46, x + 36, FY - 2, hx('#2a2c2a'), outline=OUT, hl=.1)
    c.box(x - 2, FY - 54, x + 38, FY - 46, hx('#3a3c3a'), outline=OUT, hl=.15)
    c.rect(x + 6, FY - 52, x + 30, FY - 50, hx('#0d0e0d'))
    tdraw(c, (x + 4, FY - 42, x + 32, FY - 6), lambda od, ox, oy: od.rectangle([P(x + 4) + ox, P(FY - 42) + oy, P(x + 32) + ox, P(FY - 6) + oy], fill=(110, 116, 110, 60)))
    rng = random.Random(4)
    for k in range(40):                                                           # shredded strips inside
        sx = x + 6 + rng.uniform(0, 24); sy = FY - 8 - rng.uniform(0, 26)
        c.vline(sx, sy - 4, sy, hx('#8a8c86'), 0.5)
    c.poly([(x + 12, FY - 54), (x + 22, FY - 54), (x + 24, FY - 62), (x + 14, FY - 64)], hx('#8a8c86'), OUT)   # half-fed sheet


def small_safe(c, x):
    c.occlude(x - 2, FY - 50, x + 46, FY, 100, blur=3)
    c.box(x, FY - 48, x + 44, FY - 2, hx('#2a2e2c'), outline=OUT, hl=.12)
    c.rect(x + 4, FY - 44, x + 40, FY - 6, None, hx('#1a1c1b'), 0.8)
    c.ell(x + 12, FY - 32, x + 24, FY - 20, hx('#5a5e5a'), OUT, 0.6)
    c.box(x + 30, FY - 32, x + 34, FY - 20, BRASS, outline=None)


def power_bill(c, x, desk_y):
    """electricity bill spread open: usage bars, the night block run over with yellow highlighter"""
    c.poly([(x, desk_y), (x + 40, desk_y - 1), (x + 41, desk_y + 0.4), (x + 1, desk_y + 1)], hx('#868a84'), OUT)
    c.poly([(x + 42, desk_y - 1), (x + 82, desk_y), (x + 81, desk_y + 1), (x + 41, desk_y + 0.4)], hx('#7f837d'), OUT)
    c.rect(x + 50, desk_y - 1.6, x + 64, desk_y - 0.4, hx('#c8b84a'))
    c.glow_rect(x + 50, desk_y - 2, x + 64, desk_y, hx('#c8b84a'), 0.15, blur=3)


def stamp_rack(c, x, desk_y):
    c.box(x, desk_y - 4, x + 26, desk_y, DWOOD_L, outline=OUT)
    for k in range(4):
        c.box(x + 3 + k * 6, desk_y - 14, x + 7 + k * 6, desk_y - 4, hx('#4a3a2c'), outline=OUT)
    c.box(x + 28, desk_y - 3, x + 40, desk_y, hx('#2a1e20'), outline=OUT)
    c.rect(x + 29, desk_y - 3.6, x + 39, desk_y - 2.8, hx('#8a2a26'))


def ledger_stack(c, x, desk_y, n=4, seed=0):
    rng = random.Random(seed)
    y = desk_y
    for k in range(n):
        th = rng.uniform(3, 5)
        w = rng.uniform(26, 34)
        col = rng.choice([hx('#2a3a34'), hx('#3a2a26'), hx('#2a2e3a')])
        c.box(x + rng.uniform(-2, 2), y - th, x + w, y, col, outline=OUT)
        c.rect(x + w - 6, y - th + 1, x + w - 1, y - 1, dk(CREAM, .1))
        y -= th
    return y


def finance_drawer_key(c, x, y):
    """desk drawer pulled out a little, an envelope with a key tag inside"""
    c.box(x, y, x + 50, y + 12, hx('#4d545a'), outline=OUT, hl=.15)
    c.rect(x + 4, y - 3, x + 30, y + 2, hx('#8a8c86'))
    c.rect(x + 26, y - 6, x + 32, y - 2, CREAM_L)
    c.line([(x + 29, y - 6), (x + 31, y - 10)], BRASS, 0.8)


# ============================================================ executive meeting room
def blackout_window(c, x0, y0, x1, y1, city_fn, seed=0):
    city_fn(x0, y0, x1, y1, seed=seed)
    c.box(x0 - 2, y0, x1 + 2, y0 + 8, hx('#2a2c2a'), outline=OUT, hl=.15)
    c.vgrad(x0, y0 + 8, x1, y1 - 2, hx('#1b201e'), hx('#151917'))
    for x in np.arange(x0 + 4, x1, 8):
        c.vline(x, y0 + 8, y1 - 2, hx('#181c1a'), 0.5)
    c.box(x0, y1 - 6, x1, y1 - 2, hx('#2a2c2a'), outline=OUT)
    # light leaking around the shade edges
    for gx in (x0 + 1, x1 - 2):
        c.rect(gx, y0 + 8, gx + 1.2, y1 - 6, hx('#a8bcc8'))
        c.glow_rect(gx - 1, y0 + 8, gx + 2, y1 - 6, hx('#8fa8b8'), 0.5, blur=6)
    c.rect(x0 + 2, y1 - 6, x1 - 2, y1 - 5, hx('#a8bcc8'))
    c.glow_rect(x0, y1 - 7, x1, y1 - 3, hx('#8fa8b8'), 0.35, blur=5)
    c.rect(x0 - 8, y0 - 8, x1 + 8, y0, CREAM); c.rect(x0 - 8, y1, x1 + 8, y1 + 6, CREAM)
    c.rect(x0 - 8, y0, x0, y1, CREAM); c.rect(x1, y0, x1 + 8, y1, CREAM)
    c.rect(x0 - 8, y0 - 8, x1 + 8, y1 + 6, None, OUT, 0.8)


def media_wall(c, x0, y0, x1, y1, scr):
    """dark wood media wall with a recessed display and a hidden speaker strip"""
    c.occlude(x0 + 2, y0 + 2, x1 + 3, y1 + 4, 100, blur=5); c.apply_shade_now()
    wood_panel_wall(c, x0, y0, x1, y1, step=40)
    sx0, sy0, sx1, sy1 = scr
    c.rect(sx0 - 6, sy0 - 6, sx1 + 6, sy1 + 6, hx('#120d0a'))
    c.rrect(sx0, sy0, sx1, sy1, 1, hx('#0b0c0c'), OUT, 1)
    screen_content(c, sx0 + 2, sy0 + 2, sx1 - 2, sy1 - 2, 'off', seed=4)
    reflection(c, sx0 + 2, sy0 + 2, sx1 - 2, sy1 - 2, 14, 0.6, 0.12)
    led(c, sx1 - 4, sy1 + 3, RED, 0.45, 0.4)
    c.rect(sx0, sy1 + 10, sx1, sy1 + 14, hx('#141110'))
    for x in np.arange(sx0 + 4, sx1 - 2, 4):
        c.vline(x, sy1 + 10, sy1 + 14, hx('#221b16'), 0.6)


def board_table(c, x0, x1, top_y):
    th = 7
    c.occlude(x0 + 8, top_y + th, x1 - 8, FY, 110, blur=6); c.apply_shade_now()
    for bx in (x0 + 80, x1 - 160):
        c.box(bx, top_y + th, bx + 80, FY - 3, DWOOD, outline=OUT, hl=.06, sh=.3)
        c.rect(bx + 6, top_y + th + 6, bx + 74, FY - 9, None, dk(DWOOD, .4), 0.6)
        c.rect(bx - 4, FY - 4, bx + 84, FY, hx('#150f0c'))
    c.box(x0, top_y, x1, top_y + th, DWOOD_L, outline=OUT, hl=.2, sh=.4)
    c.hline(x0 + 1, x1 - 1, top_y + 0.4, lit(DWOOD_L, .2), 0.6)
    c.hline(x0, x1, top_y + th - 1, dk(BRASS, .3), 0.6)


def delegate_mic(c, x, desk_y, live=False):
    c.box(x - 8, desk_y - 4, x + 8, desk_y, hx('#1d1f1e'), outline=OUT, hl=.15)
    c.line([(x + 4, desk_y - 4), (x + 6, desk_y - 22), (x + 2, desk_y - 30)], hx('#2a2c2a'), 0.9)
    c.ell(x - 1, desk_y - 33, x + 5, desk_y - 28, hx('#1b1d1c'), OUT, 0.4)
    led(c, x - 4, desk_y - 2, RED if live else hx('#3a2220'), 0.5, 0.6 if live else 0)
    if live:
        c.ell(x - 2, desk_y - 34, x + 6, desk_y - 27, None, wa(RED, 255), 0.5)


def name_plate(c, x, desk_y):
    c.poly([(x - 10, desk_y), (x + 10, desk_y), (x + 7, desk_y - 8), (x - 7, desk_y - 8)], hx('#2a2420'), OUT)
    c.rect(x - 6, desk_y - 6, x + 6, desk_y - 3, dk(BRASS, .1))


def glass_water(c, x, desk_y):
    tpoly(c, [(x - 3, desk_y), (x + 3, desk_y), (x + 3.5, desk_y - 10), (x - 3.5, desk_y - 10)], hx('#9aaab0'), 60)
    c.rect(x - 3.5, desk_y - 10.5, x + 3.5, desk_y - 9.8, hx('#9aaab0'))


def carafe(c, x, desk_y):
    tpoly(c, [(x - 6, desk_y), (x + 6, desk_y), (x + 7, desk_y - 12), (x + 3, desk_y - 20), (x - 3, desk_y - 20), (x - 7, desk_y - 12)], hx('#9aaab0'), 70)
    c.rect(x - 3, desk_y - 22, x + 3, desk_y - 20, hx('#5a5e5a'))


def high_back_chair(c, cx, col=hx('#1c1614')):
    """board-room chair from behind: taller back, padded"""
    seat_y = FY - 44
    c.occlude(cx - 26, FY - 4, cx + 26, FY + 1, 120, blur=3, ellipse=True)
    c.poly([(cx - 24, FY - 7), (cx + 24, FY - 7), (cx + 20, FY - 4), (cx - 20, FY - 4)], hx('#24201e'), OUT)
    for dx in (-22, 0, 22):
        c.ell(cx + dx - 3, FY - 6, cx + dx + 3, FY, hx('#121010'), OUT, 0.5)
    c.box(cx - 2, seat_y + 6, cx + 2, FY - 7, hx('#4a4440'), outline=OUT)
    c.rrect(cx - 25, seat_y - 3, cx + 25, seat_y + 5, 2, dk(col, .1), OUT, 1)
    c.rrect(cx - 22, seat_y - 80, cx + 22, seat_y - 2, 8, col, OUT, 1)
    for k in range(4):
        c.hline(cx - 18, cx + 18, seat_y - 66 + k * 16, dk(col, .35), 0.6)        # quilted bands
    c.hline(cx - 18, cx + 18, seat_y - 78, lit(col, .15), 0.8)


def head_chair(c, cx, facing=-1, col=hx('#1c1614')):
    """the chair at the head of the table, in profile, a size taller"""
    f = facing
    seat_y = FY - 46
    c.occlude(cx - 28, FY - 4, cx + 28, FY + 1, 110, blur=3, ellipse=True)
    c.poly([(cx - 26, FY - 7), (cx + 26, FY - 7), (cx + 22, FY - 4), (cx - 22, FY - 4)], hx('#24201e'), OUT)
    for dx in (-22, -7, 7, 22):
        c.ell(cx + dx - 3, FY - 6, cx + dx + 3, FY, hx('#121010'), OUT, 0.5)
    c.box(cx - 2, seat_y + 5, cx + 2, FY - 7, hx('#4a4440'), outline=OUT)
    c.rrect(cx - 24, seat_y - 6, cx + 24, seat_y + 4, 4, col, OUT, 1)
    bx = cx - f * 22
    c.rrect(min(bx - f * 2, bx + f * 12), seat_y - 96, max(bx - f * 2, bx + f * 12), seat_y - 4, 6, col, OUT, 1)
    c.rrect(cx - 12, seat_y - 24, cx + 12, seat_y - 18, 2, dk(col, .2), OUT, 0.6)


# ============================================================ executive office
def secretary_desk(c, x0, x1):
    top = FY - 76
    c.occlude(x0 - 3, top - 26, x1 + 3, FY, 110, blur=4); c.apply_shade_now()
    c.box(x0, top - 24, x1, FY - 2, DWOOD, outline=OUT, hl=.08, sh=.3)           # high reception front
    c.box(x0 - 4, top - 28, x1 + 4, top - 24, DWOOD_L, outline=OUT, hl=.25)
    c.hline(x0, x1, top - 10, dk(BRASS, .2), 0.8)
    for x in np.arange(x0 + 20, x1 - 10, 30):
        c.vline(x, top - 20, FY - 6, dk(DWOOD, .4), 0.6)
    # monitor and phone visible over the counter
    monitor(c, x0 + 52, top - 24, 44, 26, 'off', seed=9, stand='base')
    desk_phone_led(c, x1 - 22, top - 28)
    # GPU purchase copy with an empty approval box row
    approval_doc(c, x0 + 6, top - 28)


def approval_doc(c, x, y):
    c.poly([(x, y), (x + 30, y - 1), (x + 31, y + 0.6), (x + 1, y + 1)], hx('#868a84'), OUT)
    for k in range(4):                                                             # 결재란: four empty boxes
        c.rect(x + 12 + k * 4.5, y - 4, x + 15.5 + k * 4.5, y - 1, None, hx('#4f5458'), 0.4)
    c.rect(x + 12 + 3 * 4.5, y - 4, x + 15.5 + 3 * 4.5, y - 1, hx('#3a4a6a'))      # only the last one stamped (auto)


def desk_phone_led(c, x, desk_y):
    c.poly([(x - 13, desk_y), (x + 13, desk_y), (x + 9, desk_y - 9), (x - 11, desk_y - 7)], hx('#1f1d1c'), OUT)
    c.rrect(x - 13, desk_y - 12, x + 5, desk_y - 8, 2, hx('#252220'), OUT, 0.6)
    led(c, x + 8, desk_y - 6, RED, 0.6, 0.6)


def double_lock_cabinet(c, x, w=84, h=110):
    top = FY - h
    c.occlude(x - 3, top, x + w + 3, FY, 110, blur=4); c.apply_shade_now()
    c.box(x, top, x + w, FY - 2, hx('#2c302e'), outline=OUT, hl=.1, sh=.3)
    for k in range(3):
        yy = top + 4 + k * (h - 8) / 3
        c.rect(x + 4, yy, x + w - 4, yy + (h - 8) / 3 - 3, None, hx('#1a1c1b'), 0.6)
        c.box(x + w / 2 - 12, yy + 10, x + w / 2 + 12, yy + 13, hx('#5a5e5a'), outline=None)
    # two key cylinders side by side on the top drawer, both brass-ringed
    for kx in (x + 14, x + w - 22):
        c.ell(kx, top + 8, kx + 8, top + 16, BRASS, OUT, 0.5)
        c.rect(kx + 3.3, top + 9.5, kx + 4.7, top + 14.5, hx('#1a1612'))
        c.glow_ell(kx + 4, top + 12, 6, 6, BRASS, 0.12, blur=3)
    c.box(x - 2, top - 3, x + w + 2, top, DWOOD_L, outline=OUT, hl=.2)


def exec_desk(c, x0, x1):
    top = FY - 76
    c.occlude(x0 - 4, top, x1 + 4, FY, 120, blur=6); c.apply_shade_now()
    c.box(x0 + 4, top + 7, x1 - 4, FY - 3, DWOOD, outline=OUT, hl=.06, sh=.3)      # full modesty panel
    for x in np.arange(x0 + 24, x1 - 20, 54):
        c.rect(x, top + 16, x + 44, FY - 12, None, dk(DWOOD, .45), 0.8)
    c.box(x0, top, x1, top + 7, DWOOD_L, outline=OUT, hl=.25, sh=.45)
    c.hline(x0, x1, top + 6, dk(BRASS, .25), 0.7)
    c.rect(x0 + 4, FY - 3, x1 - 4, FY, hx('#150f0c'))
    return top


def exec_chair_front(c, cx, top_y):
    """executive's high-back chair behind the desk, seen from the front, rising above the desk top"""
    c.rrect(cx - 30, top_y - 112, cx + 30, top_y - 2, 10, hx('#1a1412'), OUT, 1.2)
    c.rrect(cx - 24, top_y - 104, cx + 24, top_y - 30, 8, hx('#221a17'), OUT, 0.6)
    for k in range(3):
        c.hline(cx - 20, cx + 20, top_y - 90 + k * 18, hx('#140f0d'), 0.7)
    c.rrect(cx - 38, top_y - 34, cx - 28, top_y - 2, 3, hx('#1a1412'), OUT, 0.8)
    c.rrect(cx + 28, top_y - 34, cx + 38, top_y - 2, 3, hx('#1a1412'), OUT, 0.8)


def bankers_lamp(c, x, desk_y):
    c.box(x - 8, desk_y - 3, x + 8, desk_y, BRASS, outline=OUT, hl=.2)
    c.vline(x - 0.8, desk_y - 22, desk_y - 3, BRASS, 1.6)
    c.poly([(x - 14, desk_y - 22), (x + 14, desk_y - 22), (x + 10, desk_y - 30), (x - 10, desk_y - 30)], hx('#24443a'), OUT)
    c.hline(x - 12, x + 12, desk_y - 29, hx('#3a5a4e'), 0.6)


def pending_folder(c, x, desk_y):
    c.box(x, desk_y - 4, x + 38, desk_y, hx('#2a2622'), outline=OUT, hl=.15)
    c.rect(x + 2, desk_y - 4.8, x + 36, desk_y - 4, hx('#868a84'))
    c.rect(x + 30, desk_y - 9, x + 35, desk_y - 4, hx('#8a3a33'))                  # red tab
    c.line([(x + 8, desk_y - 5), (x + 14, desk_y - 7)], BRASS, 1)                  # key on top
    c.ell(x + 13, desk_y - 9, x + 18, desk_y - 5, None, BRASS, 0.7)


def pen_stand(c, x, desk_y):
    c.box(x, desk_y - 3, x + 20, desk_y, hx('#1a1612'), outline=OUT, hl=.2)
    c.line([(x + 6, desk_y - 3), (x + 2, desk_y - 14)], hx('#2a2a2a'), 0.9)
    c.line([(x + 14, desk_y - 3), (x + 18, desk_y - 14)], hx('#2a2a2a'), 0.9)


def guest_chair_back(c, cx):
    """formal armchair in front of the executive desk, seen from behind"""
    c.occlude(cx - 26, FY - 5, cx + 26, FY + 1, 110, blur=3, ellipse=True)
    for lx in (cx - 22, cx + 18):
        c.box(lx, FY - 40, lx + 4, FY, hx('#1a1412'), outline=None)
    c.rrect(cx - 26, FY - 50, cx + 26, FY - 38, 3, hx('#2a201c'), OUT, 0.8)
    c.rrect(cx - 22, FY - 96, cx + 22, FY - 44, 6, hx('#241c18'), OUT, 1)
    for k in range(4):
        c.ell(cx - 14 + k * 9, FY - 80, cx - 12 + k * 9, FY - 78, hx('#3a2e26'))      # button tufting
    c.rrect(cx - 28, FY - 66, cx - 20, FY - 40, 3, hx('#2a201c'), OUT, 0.6)
    c.rrect(cx + 20, FY - 66, cx + 28, FY - 40, 3, hx('#2a201c'), OUT, 0.6)


def glass_bookcase(c, x, w=240, h=200, seed=0):
    rng = random.Random(seed)
    top = FY - h
    c.occlude(x - 3, top, x + w + 3, FY, 120, blur=6); c.apply_shade_now()
    c.box(x, top, x + w, FY - 2, DWOOD, outline=OUT, hl=.08, sh=.3)
    upper_bottom = FY - 70
    c.rect(x + 6, top + 6, x + w - 6, upper_bottom, hx('#100c0a'))
    rows = 3
    rh = (upper_bottom - top - 12) / rows
    spines = [hx('#2a3a34'), hx('#3a2a26'), hx('#2a2e3a'), hx('#4a4030'), hx('#33302a')]
    for r in range(rows):
        sy = top + 6 + (r + 1) * rh
        c.rect(x + 6, sy - 3, x + w - 6, sy, DWOOD_L)
        xx = x + 10
        while xx < x + w - 12:
            if rng.random() < 0.12:
                # a few formal box files and a small ornament, leaving space
                c.box(xx, sy - rh * 0.7, xx + 18, sy - 3, hx('#3a3a30'), outline=OUT)
                xx += 24; continue
            bw = rng.uniform(4, 7); bh = rh * rng.uniform(.65, .9)
            col = rng.choice(spines)
            c.box(xx, sy - 3 - bh, xx + bw, sy - 3, col, outline=None, hl=.1, sh=.3)
            c.vline(xx + bw - 0.5, sy - 3 - bh, sy - 3, OUT, 0.5)
            if rng.random() < 0.3:
                c.hline(xx + .6, xx + bw - .6, sy - 3 - bh * 0.8, dk(BRASS, .1), 0.6)
            xx += bw
    tdraw(c, (x + 6, top + 6, x + w - 6, upper_bottom), lambda od, ox, oy: od.rectangle([P(x + 6) + ox, P(top + 6) + oy, P(x + w - 6) + ox, P(upper_bottom) + oy], fill=(80, 96, 90, 34)))
    for k in range(int(w / 60)):
        reflection(c, x + 6 + k * 60, top + 6, x + 6 + (k + 1) * 60, upper_bottom, 20, 0.2, 0.3)
        c.vline(x + 6 + (k + 1) * 60, top + 6, upper_bottom, dk(DWOOD, .2), 1.2)
    # closed cabinet doors below with brass knobs
    n = int(w / 60)
    for k in range(n):
        dx = x + 6 + k * (w - 12) / n
        c.rect(dx + 2, upper_bottom + 4, dx + (w - 12) / n - 2, FY - 8, None, dk(DWOOD, .4), 0.8)
        c.ell(dx + (w - 12) / n - 10, upper_bottom + 30, dx + (w - 12) / n - 6, upper_bottom + 34, BRASS)


def coat_stand(c, x):
    c.occlude(x - 16, FY - 3, x + 16, FY + 1, 90, blur=2, ellipse=True)
    c.box(x - 2, FY - 176, x + 2, FY - 4, DWOOD_L, outline=OUT, hl=.2)
    for dx in (-14, 14):
        c.line([(x, FY - 20), (x + dx, FY)], DWOOD_L, 1.6)
    for dx in (-10, 10):
        c.line([(x, FY - 170), (x + dx, FY - 178)], DWOOD_L, 1.4)
    c.poly([(x - 12, FY - 172), (x + 2, FY - 176), (x + 6, FY - 150), (x + 2, FY - 110), (x - 14, FY - 112), (x - 18, FY - 148)], hx('#22201e'), OUT)   # a suit jacket left hanging


def drapes(c, x0, x1, y0, y1, gathered=True):
    k = 0
    xx = x0
    while xx < x1:
        w = 7 + (k % 3) * 2
        col = JADE_L if k % 2 else lit(JADE_L, .08)
        c.vgrad(xx, y0, min(xx + w, x1), y1, dk(col, .15), dk(col, .4))
        xx += w; k += 1
    c.rect(x0, y0, x1, y1, None, OUT, 0.8)


def sheer(c, x0, x1, y0, y1):
    k = 0; xx = x0
    while xx < x1:
        w = 6 + (k % 2) * 3
        col = hx('#7a7a6e') if k % 2 else hx('#6a6a60')
        tdraw(c, (xx, y0, min(xx + w, x1), y1), lambda od, ox, oy, xx=xx, w=w, col=col: od.rectangle(
            [P(xx) + ox, P(y0) + oy, P(min(xx + w, x1)) + ox, P(y1) + oy], fill=wa(col, 120)))
        xx += w; k += 1


def round_side_table(c, x):
    c.occlude(x - 20, FY - 4, x + 20, FY + 1, 90, blur=2, ellipse=True)
    c.box(x - 22, FY - 56, x + 22, FY - 51, DWOOD_L, outline=OUT, hl=.25)
    c.box(x - 2, FY - 51, x + 2, FY - 4, DWOOD, outline=None)
    c.box(x - 14, FY - 4, x + 14, FY, DWOOD, outline=OUT)
