import random, math, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageChops
from lib import *
from objects import *
from objects5 import partition, conf_phone
from objects8 import *

X0, X1 = 48, 3152
IX0, IX1 = 78, 3122
TS0, TS1 = 180, 212
FB = 626
QA = (IX0, 1300); P1 = (1300, 1324)
PL = (1324, 2340); P2 = (2340, 2364)
MT = (2364, IX1)
PCL = 296          # planning ceiling
MCL = 306          # meeting ceiling

WALL_PL = hx('#45484a')

c = Canvas()
exec(open('reuse.py').read().split('\n', 4)[4], globals())


def hatch(x0, y0, x1, y1, col=hx('#3a3f44'), step=9):
    def f(od, ox, oy):
        for k in range(int(-(y1 - y0)), int(x1 - x0), step):
            od.line([(P(x0 + k) + ox, P(y1) + oy), (P(x0 + k + (y1 - y0)) + ox, P(y0) + oy)], fill=wa(col, 70), width=P(0.8))
    tdraw(c, (x0, y0, x1, y1), f)


def layer(fn, dark=0.5, tint=hx('#12161a'), tint_a=0.45):
    c.apply_shade_now()
    base = c.img
    c.img = Image.new('RGBA', base.size, (0, 0, 0, 0)); c.d = ImageDraw.Draw(c.img)
    fn()
    c.apply_shade_now()
    arr = np.asarray(c.img, np.float32)
    rgb = arr[:, :, :3] * (1 - dark)
    rgb = rgb * (1 - tint_a) + np.array(tint[:3], np.float32) * tint_a
    arr[:, :, :3] = np.where(arr[:, :, 3:4] > 0, rgb, arr[:, :, :3])
    base.alpha_composite(Image.fromarray(np.rint(arr).clip(0, 255).astype(np.uint8), 'RGBA'))
    c.img = base; c.d = ImageDraw.Draw(c.img)


# ------------------------------------------------------------------ shell
def shell():
    c.vgrad(IX0, TS1, IX1, 310, hx('#121416'), hx('#191c1e'))
    concrete_wall(c, QA[0], TS1, QA[1], FY, seed=2)
    safety_band(c, QA[0], QA[1], 480, 6)
    c.vgrad(PL[0], PCL, PL[1], FY, dk(WALL_PL, .2), WALL_PL)
    for x in np.arange(PL[0] + 150, PL[1], 200):
        c.vline(x, PCL, FY, dk(WALL_PL, .18), 0.8)
    c.box(PL[0], 476, PL[1], 480, hx('#5a5e60'), outline=OUT, hl=.2)
    c.vgrad(PL[0], 480, PL[1], FY, dk(WALL_PL, .3), dk(WALL_PL, .4))
    c.vgrad(MT[0], MCL, MT[1], FY, hx('#2c3033'), hx('#33373a'))
    # skirting
    for (a0, a1), col in ((QA, hx('#26292b')), (PL, dk(WALL_PL, .55)), (MT, hx('#1d2023'))):
        c.box(a0, FY - 9, a1, FY, col, outline=None)
        c.hline(a0, a1, FY - 9, lit(col, .15), 0.6)
    # floors: grey epoxy with yellow safety line (QA), carpet (planning, meeting)
    c.rect(IX0, FY, IX1, FY + 8, hx('#1d2022'))
    c.vgrad(QA[0], FY, P1[1], FY + 6, hx('#3a3e40'), hx('#25292b'))
    c.rect(QA[0], FY, P1[1], FY + 1.6, SAFETY)
    for x in np.arange(QA[0], P1[1], 240):
        c.vline(x, FY, FY + 6, hx('#25292b'), 0.8)
    c.rect(PL[0], FY, PL[1], FY + 6, hx('#262b30'))
    c.hline(PL[0], PL[1], FY, hx('#4a5258'), 0.8)
    c.rect(P2[0] - 6, FY, MT[1], FY + 6, hx('#22262a'))
    c.hline(P2[0] - 6, MT[1], FY, hx('#454c52'), 0.8)
    # slab + section cuts
    c.vgrad(X0, FY + 6, X1, FB, hx('#23272a'), hx('#191b1e'))
    for x in (P1[0] - 18, P2[0] - 18):
        c.vgrad(x, FB - 2, x + 60, FB + 14, hx('#1f2225'), hx('#16181a'))
        c.rect(x, FB - 2, x + 60, FB + 14, None, OUT, 1)
    c.vgrad(X0, TS0, X1, TS1, hx('#272b30'), hx('#1b1e22'))
    c.vgrad(X0, TS0, IX0, FB, hx('#262a2e'), hx('#1b1e21'))
    c.vgrad(IX1, TS0, X1, FB, hx('#262a2e'), hx('#1b1e21'))
    for a in ((X0, TS0, X1, TS1), (X0, FY + 6, X1, FB), (X0, TS0, IX0, FB), (IX1, TS0, X1, FB)):
        hatch(*a)
    c.hline(X0, X1, TS0, hx('#4b5258'), 1)
    c.hline(IX0, IX1, TS1, hx('#0d0f11'), 1)
    c.vline(IX0 - 1, TS1, FY, hx('#2c3237'), 1)
    c.vline(IX1, TS1, FY, hx('#0e1012'), 1)
    c.hline(X0, X1, FB - 1, hx('#2b2f33'), 1)


def ceilings():
    # sprinkler + duct over the whole floor
    c.box(IX0, 220, IX1, 238, hx('#35393c'), outline=OUT, hl=.12, sh=.35)
    for x in range(int(IX0) + 80, int(IX1), 120):
        c.box(x, 219, x + 3, 239, hx('#41464a'), outline=None, hl=.1)
    c.box(IX0, 244, IX1, 247.5, hx('#5a3a36'), outline=OUT, hl=.15)
    # QA: exposed concrete soffit, wire-mesh cable baskets, LED battens (off)
    wire_basket(c, QA[0] + 10, QA[1] - 10, 258)
    wire_basket(c, QA[0] + 10, QA[1] - 10, 276)
    rng = random.Random(5)
    for k in range(18):
        xx = rng.uniform(QA[0] + 20, QA[1] - 90)
        yb = rng.choice((264, 282))
        c.cable((xx, yb), (xx + rng.uniform(40, 90), yb), rng.uniform(2, 6), hx('#15181b') if k % 3 else hx('#3e6aa0'), 0.9)
    for x0 in (120, 420, 720, 1020):
        batten(c, x0, x0 + 170, 300)
    # planning: plaster ceiling with recessed linear slots
    c.box(PL[0], PCL - 8, PL[1], PCL, hx('#4a4e50'), outline=OUT, hl=.08)
    for x in np.arange(PL[0] + 40, PL[1] - 100, 260):
        c.rect(x, PCL - 1, x + 160, PCL + 1, hx('#1d2023'))
    # meeting: gypsum ceiling, ring pendant over the table
    c.box(MT[0], MCL - 8, MT[1], MCL, hx('#3d4144'), outline=OUT, hl=.08)
    # sprinkler heads below every ceiling
    for x in range(int(IX0) + 110, int(IX1), 240):
        cl = 300 if x < P1[0] else (PCL if x < P2[0] else MCL)
        c.rect(x - 0.8, 247.5, x + 0.8, cl + 3, hx('#5a3a36'))
        c.rect(x - 3, cl + 3, x + 3, cl + 4.5, hx('#8b8f91'))


# ------------------------------------------------------------------ QA testing room
def qa_room():
    TOP = FY - 69
    one_way_mirror(c, 100, 330, 360, 458, ghosts=[(160, 70, 60), (260, 90, 70)])
    observation_camera(c, 326, 302)
    defect_board(c, 382, 322, 624, 440, seed=3)
    repro_bench(c, 96, 336)
    release_gate(c, 356)
    back = [748 + k * 96 for k in range(6)]
    front = [700 + k * 96 for k in range(6)]

    def back_row():
        qa_bench(c, 650, 1290, TOP, back)
        for cx in back:
            chair_back(c, cx + 2)
    layer(back_row)
    qa_bench(c, 650, 1290, TOP, front)
    for cx in front:                                     # every chair pushed in exactly the same
        chair_back(c, cx + 2)
    for cx in front:
        cable_to_floor(c, cx - 22, TOP + 4, dx=-6)
    c.box(1250, FY - 26, 1290, FY, hx('#2c3033'), outline=OUT)            # spare-parts bin
    for k in range(3):
        c.rect(1256 + k * 11, FY - 30, 1262 + k * 11, FY - 26, SAFETY)


# ------------------------------------------------------------------ product planning workspace
def planning():
    TOP = FY - 69
    rain_window(c, 1350, 320, 1760, 520, seed=81, city_fn=city)
    roadmap_board(c, 1790, 322, 2092, 422)
    planning_wall(c, 2112, 322, 2322, 440, seed=4)
    rng = random.Random(9)
    for x0, x1, seed in ((1360, 1556, 1), (1576, 1756, 2)):
        desk(c, x0, x1, TOP, peds=('R',), seed=seed, col=hx('#6c7174'))
        cx = (x0 + x1) / 2 - 20
        laptop(c, cx, TOP, 30, 'off', seed=seed + 10, stand=True)
        keyboard(c, cx, TOP, 32)
        # stacked document trays, aligned binders, pen cup
        for k in range(3):
            c.box(x0 + 10, TOP - 6 - k * 6, x0 + 44, TOP - k * 6, hx('#3a3e41'), outline=OUT)
            c.rect(x0 + 12, TOP - 4.5 - k * 6, x0 + 42, TOP - 3 - k * 6, hx('#7f827d'))
        binders(c, cx + 34, TOP, 4, seed=seed + 20, h=26)
        c.box(x1 - 70, TOP - 9, x1 - 62, TOP, hx('#2f3a44'), outline=OUT)
        for k in range(3):
            c.line([(x1 - 68 + k * 2, TOP - 9), (x1 - 70 + k * 3, TOP - 15)], hx('#2f4766'), 0.6)
        desk_lamp(c, x1 - 20, TOP, on=False, facing=-1)
        chair_back(c, cx + 4, col=hx('#20252a'))
    requirements_doc(c, 1612, TOP)
    # standing discussion table with stools, easel, leaning foam boards
    top = high_table(c, 1822, 1962)
    bar_stool_simple(c, 1806)
    bar_stool_simple(c, 1978)
    mug(c, 1900, top, hx('#5e6870'))
    easel(c, 2016)
    foam_boards(c, 2196, n=4, seed=3)


# ------------------------------------------------------------------ shared product meeting room
def meeting():
    TOP = FY - 69
    felt_tiles(c, MT[0], MCL, MT[1], FY - 9)
    sliding_whiteboards(c, 2392, 2706, 334, 448)
    ring_pendant(c, 2700, 458, 140, MCL)
    # display + camera bar
    c.occlude(2734, 340, 2936, 440, 100, blur=4); c.apply_shade_now()
    c.rrect(2732, 336, 2932, 436, 1.5, hx('#0e1012'), OUT, 1)
    screen_content(c, 2735, 339, 2929, 433, 'off', seed=7)
    c.box(2802, 326, 2862, 334, hx('#1b1d1f'), outline=OUT)
    c.ell(2828, 327, 2836, 333, hx('#2a3238'), OUT, 0.4)
    led(c, 2852, 330, RED, 0.45, 0.5)
    # credenza
    c.occlude(3010, FY - 74, 3114, FY, 100, blur=4); c.apply_shade_now()
    c.box(3010, FY - 72, 3112, FY - 2, hx('#3a3e41'), outline=OUT, hl=.08)
    for k in range(3):
        c.rect(3014 + k * 32, FY - 66, 3042 + k * 32, FY - 8, None, hx('#2a2d30'), 0.6)
    binders(c, 3016, FY - 72, 8, seed=31, h=28, lean_last=True)
    # table
    desk(c, 2410, 2986, TOP, peds=(), seed=4, col=hx('#4a4e51'))
    c.box(2694, TOP + 4, 2706, FY, DESK_LEG, outline=OUT)
    c.box(2560, TOP + 4, 2840, TOP + 12, hx('#1d2023'), outline=OUT)
    for x, n in ((2470, 9), (2580, 6), (2780, 12), (2900, 7)):
        papers(c, x - 16, x + 16, TOP, n, seed=x)
    laptop(c, 2650, TOP, 30, 'code_dim', seed=41)                         # minutes, on battery
    laptop(c, 2840, TOP, 28, 'off', seed=42)
    conf_phone(c, 2720, TOP)
    # printed schedule with one ringed date
    c.box(2508, TOP - 2, 2548, TOP, hx('#7f827d'), outline=OUT)
    c.ell(2528, TOP - 2.6, 2536, TOP - 0.2, None, hx('#7b3a33'), 0.5)
    for x in (2520, 2760, 2950):
        mug(c, x, TOP, hx('#56606a'))
    for x in (2470, 2580, 2800):
        chair_back(c, x, col=hx('#22262a'))
    chair_side(c, 2910, facing=-1, col=hx('#22262a'))
    chair_side(c, 2690, facing=1, col=hx('#22262a'))


def partitions_and_signs():
    partition(c, P1[0], P1[1], TS1, door_h=210, style='steel', door_side='R')
    safety_band(c, P1[0] - 4, P1[1] + 4, FY - 210 - 10, 6)
    partition(c, P2[0], P2[1], TS1, door_h=210, style='solid', door_side='L')
    # exit pictogram on the planning side of the QA door
    ex = P1[1] + 10
    c.box(ex, 312, ex + 44, 328, hx('#1a2a1f'), outline=OUT)
    c.rect(ex + 2, 314, ex + 42, 326, hx('#2f6a45'))
    c.ell(ex + 27, 315.5, ex + 30, 318.5, hx('#cfe8d6'))
    c.line([(ex + 28, 319), (ex + 25, 323), (ex + 21, 325)], hx('#cfe8d6'), 0.9)
    c.line([(ex + 27, 320), (ex + 32, 322)], hx('#cfe8d6'), 0.8)
    c.line([(ex + 16, 320), (ex + 6, 320), (ex + 10, 317)], hx('#cfe8d6'), 0.8)
    c.glow_rect(ex, 312, ex + 44, 328, hx('#4fb57a'), 0.5, blur=14)
    for x, y in ((1280, 300), (2320, PCL)):
        c.vline(x, TS1, y, hx('#3a4045'), 0.8)
        c.box(x - 9, y, x + 9, y + 3, hx('#4a5258'), outline=OUT)
        c.ell(x - 7, y - 2, x + 7, y + 11, hx('#1c2024'), OUT, 0.8)
        led(c, x + 2, y + 6, RED, 0.6, 0.6)


# ------------------------------------------------------------------ finalize
def finalize():
    arr = np.asarray(c.img, np.float32)
    h, w = arr.shape[:2]
    ys = np.linspace(0, 1, h)[:, None]
    xs = np.linspace(0, 1, w)[None, :]
    yy = (ys * H - TS1) / (FY - TS1)
    v = 1.0 - 0.28 * np.clip(1 - yy * 1.5, 0, 1) ** 1.5
    v *= 1.0 - 0.10 * np.clip((yy - 0.75) * 4, 0, 1)
    edge = np.minimum(xs, 1 - xs) * W
    v = v * (0.74 + 0.26 * np.clip(edge / 420.0, 0, 1))
    arr[:, :, :3] *= v[:, :, None]
    sh = np.asarray(c.shade, np.float32)[:, :, None] / 255.0
    arr[:, :, :3] *= (1 - sh * 0.85)
    L = np.asarray(c.light, np.float32) / 255.0
    base = arr[:, :, :3] / 255.0
    out = 1 - (1 - base) * (1 - L)
    lum = (out * np.array([0.299, 0.587, 0.114])).sum(axis=2, keepdims=True)
    out = out * 0.80 + lum * 0.20
    out = out * np.array([0.98, 1.0, 1.02])
    out = np.clip(out, 0, 1) ** 0.92
    out = np.clip((out - 0.5) * 1.10 + 0.5, 0, 1)
    arr[:, :, :3] = out * 255
    img = Image.fromarray(np.rint(arr).clip(0, 255).astype(np.uint8), 'RGBA').resize((W, H), Image.LANCZOS)
    a = np.asarray(img, np.float32)
    rng = np.random.default_rng(8)
    g = (rng.random((H, W)) - 0.5) * 7
    low = Image.fromarray((rng.random((H // 6, W // 6)) * 255).astype(np.uint8), 'L').resize((W, H), Image.BICUBIC)
    low = (np.asarray(low, np.float32) / 255 - 0.5) * 0.07
    a[:, :, :3] = a[:, :, :3] * (1 + low[:, :, None]) + g[:, :, None]
    alpha = np.where(a[:, :, 3] > 127, 255, 0)
    a[:, :, 3] = alpha
    a[:, :, :3] *= (alpha[:, :, None] > 0)
    img = Image.fromarray(np.rint(a).clip(0, 255).astype(np.uint8), 'RGBA')
    m = img.getchannel('A')
    inner = m.filter(ImageFilter.MinFilter(5))
    img.paste(Image.new('RGBA', img.size, (9, 10, 12, 255)), (0, 0), ImageChops.subtract(m, inner))
    inner2 = m.filter(ImageFilter.MinFilter(9))
    img.paste(Image.new('RGBA', img.size, (78, 88, 98, 255)), (0, 0), ImageChops.subtract(inner, inner2).point(lambda v: 150 if v else 0))
    bb = img.getchannel('A').getbbox()
    M = 48
    img = img.crop((bb[0] - M, bb[1] - M, bb[2] + M, bb[3] + M))
    print('bbox', bb, 'floor line y in output =', FY - (bb[1] - M), 'size', img.size)
    return img


def build():
    shell()
    c.noise_tex(QA[0], TS1, QA[1], FY, 0.06, 26, seed=1, streaks=True)
    c.noise_tex(PL[0], PCL, PL[1], FY, 0.06, 28, seed=2, streaks=True)
    c.noise_tex(X0, TS0, X1, TS1, 0.08, 16, seed=4)
    c.noise_tex(X0, FY, X1, FB, 0.08, 16, seed=5)
    c.noise_tex(PL[0], TS1, IX1, 310, 0.08, 20, seed=6)
    for i, (x, y, w_, h_) in enumerate([(1500, 480, 140, 80), (2000, 330, 100, 120), (2500, 470, 140, 80)]):
        c.stain(x, y, w_, h_, hx('#14171a'), alpha=36, blur=10, seed=i + 80)
    ceilings()
    c.occlude(IX0, TS1, IX1, TS1 + 10, 150, blur=10)
    c.occlude(IX0, FY - 6, IX1, FY, 120, blur=6)
    c.occlude(IX0, TS1, IX0 + 10, FY, 140, blur=14)
    c.occlude(IX1 - 10, TS1, IX1, FY, 140, blur=14)
    for (x0, x1) in (P1, P2):
        c.occlude(x0 - 14, TS1, x0, FY, 110, blur=10)
        c.occlude(x1, TS1, x1 + 14, FY, 110, blur=10)
    c.apply_shade_now()
    qa_room()
    planning()
    meeting()
    partitions_and_signs()
    return finalize()


if __name__ == '__main__':
    img = build()
    out = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/f8/floor08.png'
    img.save(out)
    print('saved', out)
