import random, math
import numpy as np
from PIL import Image, ImageDraw
from lib import *
from objects import *

CONC = hx('#3e4244')
SAFETY = hx('#b59a3a')
SAFETY_D = hx('#6a5a26')


# ============================================================ QA
def concrete_wall(c, x0, y0, x1, y1, seed=0):
    rng = random.Random(seed)
    c.vgrad(x0, y0, x1, y1, dk(CONC, .2), CONC)
    pw, ph = 120, 60
    for x in np.arange(x0, x1, pw):
        c.vline(x, y0, y1, dk(CONC, .22), 0.8)
        c.vline(x + 0.8, y0, y1, lit(CONC, .05), 0.4)
    for y in np.arange(y0 + ph, y1, ph):
        c.hline(x0, x1, y, dk(CONC, .16), 0.6)
    for x in np.arange(x0 + 30, x1, pw / 2):                    # formwork tie holes
        for y in np.arange(y0 + 30, y1 - 10, ph):
            c.ell(x - 1.6, y - 1.6, x + 1.6, y + 1.6, dk(CONC, .45))
            c.ell(x - 0.6, y - 1.2, x + 1.2, y + 0.4, lit(CONC, .06))
    for k in range(8):
        sx = rng.uniform(x0, x1 - 40)
        c.stain(sx, y0 + rng.uniform(0, 60), rng.uniform(20, 50), rng.uniform(60, 140), hx('#2a2d2f'), alpha=40, blur=6, seed=k + seed)


def safety_band(c, x0, x1, y, h=6):
    c.rect(x0, y, x1, y + h, SAFETY_D)
    for x in np.arange(x0 - h, x1, h * 2):
        c.poly([(max(x0, x), y + h), (max(x0, min(x1, x + h)), y), (max(x0, min(x1, x + h * 2)), y), (max(x0, min(x1, x + h)), y + h)], hx('#1a1a16'))
    c.rect(x0, y, x1, y + h, None, OUT, 0.5)


def wire_basket(c, x0, x1, y):
    c.rect(x0, y + 6, x1, y + 7, hx('#6a6e70'))
    for x in np.arange(x0, x1, 8):
        c.vline(x, y, y + 7, hx('#5a5e60'), 0.5)
    c.hline(x0, x1, y, hx('#5a5e60'), 0.5)
    c.hline(x0, x1, y + 3.5, hx('#4a4e50'), 0.4)
    for x in np.arange(x0 + 60, x1, 300):
        c.vline(x, 212, y, hx('#2a2d30'), 0.6)


def batten(c, x0, x1, y):
    c.vline(x0 + 10, 212, y, hx('#3a3e41'), 0.5); c.vline(x1 - 10, 212, y, hx('#3a3e41'), 0.5)
    c.box(x0, y, x1, y + 5, hx('#2e3134'), outline=OUT, hl=.1)
    c.rect(x0 + 2, y + 4, x1 - 2, y + 5.5, hx('#55595c'))


def one_way_mirror(c, x0, y0, x1, y1, ghosts=()):
    """observation glass: a black mirror from this side, faint reflections of the room"""
    c.vgrad(x0, y0, x1, y1, hx('#15181a'), hx('#0c0e0f'))
    for gx, gw, gh in ghosts:
        tdraw(c, (x0, y0, x1, y1), lambda od, ox, oy, gx=gx, gw=gw, gh=gh: od.rectangle(
            [P(gx - gw / 2) + ox, P(y1 - gh) + oy, P(gx + gw / 2) + ox, P(y1) + oy], fill=(70, 80, 84, 26)))
    for k, px in enumerate(np.arange(x0, x1, 86)):
        reflection(c, px, y0, min(px + 86, x1), y1, 18, 0.3, 0.2)
    c.box(x0 - 5, y0 - 5, x1 + 5, y0, hx('#2a2e31'), outline=OUT, hl=.2)
    c.box(x0 - 5, y1, x1 + 5, y1 + 6, hx('#2a2e31'), outline=OUT, hl=.2)
    c.rect(x0 - 5, y0, x0, y1, hx('#2a2e31')); c.rect(x1, y0, x1 + 5, y1, hx('#2a2e31'))
    for m in np.arange(x0 + 86, x1 - 4, 86):
        c.vline(m, y0, y1, hx('#22262a'), 1.4)
    c.rect((x0 + x1) / 2 - 18, y1 + 10, (x0 + x1) / 2 + 18, y1 + 18, hx('#4a4e50'))   # blank plate
    c.rect((x0 + x1) / 2 - 18, y1 + 10, (x0 + x1) / 2 + 18, y1 + 18, None, OUT, 0.5)


def observation_camera(c, x, y):
    c.box(x - 6, y, x + 6, y + 4, hx('#4a4e50'), outline=OUT)
    c.vline(x, y + 4, y + 10, hx('#4a4e50'), 1.2)
    c.box(x - 18, y + 10, x + 12, y + 22, hx('#5a5e61'), outline=OUT, hl=.12)
    c.rrect(x + 10, y + 9, x + 22, y + 23, 2, hx('#24272a'), OUT, 0.6)          # lens cap
    c.rect(x + 9, y + 13, x + 23, y + 17, SAFETY)                                # yellow tape around it
    led(c, x - 12, y + 14, RED, 0.5, 0.35)


def release_gate(c, x):
    """stack light on a floor stand, all lamps dark"""
    c.occlude(x - 12, FY - 4, x + 12, FY + 1, 90, blur=2, ellipse=True)
    c.box(x - 12, FY - 5, x + 12, FY, hx('#2a2d30'), outline=OUT)
    c.box(x - 1.5, FY - 120, x + 1.5, FY - 5, hx('#5a5e61'), outline=None)
    c.box(x - 7, FY - 128, x + 7, FY - 122, hx('#2a2d30'), outline=OUT)
    for k, col in enumerate((hx('#4a2220'), hx('#4a4020'), hx('#203a28'))):
        yy = FY - 182 + k * 18
        c.box(x - 7, yy, x + 7, yy + 16, col, outline=OUT, hl=.15, sh=.25)
        c.hline(x - 6, x + 6, yy + 1, lit(col, .2), 0.5)
    c.box(x - 6, FY - 188, x + 6, FY - 182, hx('#2a2d30'), outline=OUT)


def defect_board(c, x0, y0, x1, y1, seed=0):
    """kanban: three empty columns, every card piled into the last one"""
    rng = random.Random(seed)
    c.occlude(x0 + 2, y0 + 3, x1 + 3, y1 + 5, 90, blur=4); c.apply_shade_now()
    c.box(x0, y0, x1, y1, hx('#2a2d30'), outline=OUT, hl=.08)
    c.rect(x0 + 3, y0 + 3, x1 - 3, y1 - 3, hx('#4c5053'))
    cols = 4
    cw = (x1 - x0 - 6) / cols
    for k in range(1, cols):
        c.vline(x0 + 3 + k * cw, y0 + 4, y1 - 4, hx('#2a2d30'), 0.8)
    for k in range(cols):
        c.rect(x0 + 6 + k * cw, y0 + 6, x0 + k * cw + cw - 2, y0 + 12, hx('#3a3e41'))
    lx0 = x0 + 3 + 3 * cw + 3
    n = 0
    for r in range(12):
        for k in range(4):
            if n >= 47:
                break
            cx = lx0 + k * (cw - 6) / 4; cy = y0 + 16 + r * 8.2
            c.rect(cx, cy, cx + (cw - 6) / 4 - 1.2, cy + 7, hx('#7f827d') if n % 5 else hx('#868a84'))
            c.rect(cx + 1, cy + 1, cx + 4, cy + 2.4, hx('#5a5e60'))
            n += 1
    sticky(c, x0 + 8, y1 - 14, SAFETY)                                       # the QA note in the corner


def repro_bench(c, x0, x1):
    """battery-powered reproduction bench pulled off the network"""
    top = FY - 83
    c.occlude(x0, top, x1, FY, 110, blur=5); c.apply_shade_now()
    for lx in (x0 + 2, x1 - 9):
        c.box(lx, top + 5, lx + 7, FY, hx('#3a3e41'), outline=OUT)
    c.box(x0 + 4, FY - 32, x1 - 4, FY - 28, hx('#3a3e41'), outline=OUT)
    c.box(x0, top, x1, top + 5, hx('#4b5154'), outline=OUT)
    safety_band(c, x0, x1, top + 5, 4)
    # sealed reproduction box with a small lit status screen
    c.box(x0 + 14, top - 34, x0 + 96, top, hx('#1d2023'), outline=OUT, hl=.1)
    c.rect(x0 + 22, top - 28, x0 + 60, top - 12, hx('#0d1612'))
    for k in range(3):
        c.rect(x0 + 25 + k * 11, top - 25, x0 + 33 + k * 11, top - 15, hx('#5fae7a') if k < 2 else hx('#1d2a22'))
    c.glow_rect(x0 + 22, top - 28, x0 + 60, top - 12, hx('#5fae7a'), 0.5, blur=6)
    c.box(x0 + 70, top - 26, x0 + 88, top - 18, hx('#7a2f29'), outline=OUT)       # run button
    led(c, x0 + 90, top - 6, GREEN, 0.5, 0.5)
    # test terminal on battery: an analog clock on screen set to three o'clock
    tx = x0 + 136
    c.box(tx - 18, top - 2, tx + 18, top, hx('#4a5258'), outline=OUT)
    c.rrect(tx - 17, top - 26, tx + 17, top - 2, 1, hx('#2b3035'), OUT, 0.8)
    c.vgrad(tx - 15, top - 24, tx + 15, top - 4, hx('#16222a'), hx('#0f171c'))
    c.ell(tx - 8, top - 22, tx + 8, top - 6, None, hx('#9ac0d0'), 0.8)
    c.line([(tx, top - 14), (tx + 5, top - 14)], hx('#9ac0d0'), 0.9)
    c.line([(tx, top - 14), (tx, top - 20)], hx('#9ac0d0'), 0.7)
    c.glow_rect(tx - 15, top - 24, tx + 15, top - 4, hx('#6f9ab0'), 0.4, blur=6)
    # occupancy sensor control box clamped to the bench, toggled to empty
    sx = x0 + 176
    c.box(sx, top - 18, sx + 22, top, hx('#5a5f62'), outline=OUT, hl=.1)
    c.rect(sx + 8, top - 15, sx + 11, top - 8, hx('#1a1c1e'))
    c.rect(sx + 7, top - 17, sx + 12, top - 14, hx('#8a9196'))
    led(c, sx + 17, top - 12, GREEN, 0.5, 0.5)
    c.bezier((sx + 11, top), (sx - 20, top + 10), (x0 + 90, top - 2), hx('#121416'), 0.8)
    c.bezier((tx + 17, top - 8), (tx + 30, top + 8), (sx, top - 4), hx('#121416'), 0.7)
    # reproduction record printout curling over the edge
    c.poly([(x0 + 100, top), (x0 + 120, top), (x0 + 124, top + 30), (x0 + 112, top + 46), (x0 + 104, top + 30)], hx('#7f827d'), OUT)
    for k in range(4):
        c.hline(x0 + 106, x0 + 118, top + 6 + k * 6, hx('#4f5458'), 0.5)
    # battery packs under the bench
    for k in range(2):
        c.box(x0 + 20 + k * 40, FY - 28 - 22, x0 + 54 + k * 40, FY - 28, hx('#2a2d30'), outline=OUT)
        c.rect(x0 + 24 + k * 40, FY - 46, x0 + 34 + k * 40, FY - 42, hx('#5fae7a'))


def identical_station(c, cx, top_y, tag_seed=0):
    """one of many identical QA test stations"""
    monitor(c, cx, top_y, 48, 30, 'off', seed=500, stand='base')            # same seed = same reflection
    c.box(cx - 30, top_y - 6, cx - 14, top_y, hx('#22262a'), outline=OUT)   # mini PC
    led(c, cx - 17, top_y - 3, AMBER, 0.35, 0.4)                             # identical standby lights
    keyboard(c, cx + 2, top_y, 30)
    mouse(c, cx + 24, top_y)
    c.rect(cx + 18, top_y - 34, cx + 26, top_y - 30, SAFETY)                 # yellow asset tag (blank)
    # mini stack lamp above each station (dark)
    c.box(cx - 1, top_y - 56, cx + 1, top_y - 41, hx('#5a5e61'), outline=None)
    for k, col in enumerate((hx('#3a2220'), hx('#3a3420'), hx('#20302a'))):
        c.rect(cx - 3, top_y - 66 + k * 4, cx + 3, top_y - 62.5 + k * 4, col)


def qa_bench(c, x0, x1, top_y, cxs):
    desk(c, x0, x1, top_y, peds=(), col=hx('#5e6366'))
    safety_band(c, x0, x1, top_y + 4, 3)
    for cx in cxs:
        identical_station(c, cx, top_y)


# ============================================================ PLANNING
def rain_window(c, x0, y0, x1, y1, seed=0, city_fn=None):
    city_fn(x0, y0, x1, y1, seed=seed)
    tdraw(c, (x0, y0, x1, y1), lambda od, ox, oy: od.rectangle([P(x0) + ox, P(y0) + oy, P(x1) + ox, P(y1) + oy], fill=(46, 56, 64, 70)))
    rng = random.Random(seed)
    for k in range(140):                                                        # rain streaks + drops on glass
        x = rng.uniform(x0 + 2, x1 - 2); y = rng.uniform(y0, y1 - 20)
        L = rng.uniform(8, 40)
        pts = [(x, y)]
        for s in range(5):
            pts.append((x + rng.uniform(-0.8, 0.8), y + L * (s + 1) / 5))
        tline(c, pts, hx('#9aaab4'), 46, 0.6)
        c.ell(pts[-1][0] - 0.9, pts[-1][1] - 0.9, pts[-1][0] + 0.9, pts[-1][1] + 1.2, hx('#7f8e98'))
    for k in range(160):
        x = rng.uniform(x0 + 2, x1 - 2); y = rng.uniform(y0, y1)
        c.ell(x - 0.6, y - 0.6, x + 0.6, y + 0.6, hx('#6f7e88'))
    mulls = list(np.arange(x0, x1 + 1, 136.7))
    for i in range(len(mulls) - 1):
        reflection(c, mulls[i], y0, mulls[i + 1], y1, 8, 0.3 + 0.1 * i, 0.1)
    for m in mulls[1:-1]:
        c.box(m - 3, y0, m + 3, y1, hx('#2a2e31'), outline=None, hl=.15)
    c.rect(x0 - 4, y0 - 4, x1 + 4, y0, hx('#2a2e31'))
    c.rect(x0 - 4, y0 - 4, x0, y1, hx('#2a2e31')); c.rect(x1, y0 - 4, x1 + 4, y1, hx('#2a2e31'))
    c.box(x0 - 8, y1, x1 + 8, y1 + 6, hx('#4e5457'), outline=OUT, hl=.2)
    c.glow_rect(x0, y0, x1, y1, hx('#4a6070'), 0.18, blur=24)


def roadmap_board(c, x0, y0, x1, y1):
    """release roadmap: milestone moved twice (crossed out), then put on hold"""
    c.occlude(x0 + 2, y0 + 3, x1 + 3, y1 + 5, 90, blur=4); c.apply_shade_now()
    c.box(x0, y0, x1, y1, hx('#5c6062'), outline=OUT, hl=.05)
    c.rect(x0 + 3, y0 + 3, x1 - 3, y1 - 3, hx('#727678'))
    ty = (y0 + y1) / 2 + 6
    c.hline(x0 + 12, x1 - 12, ty, hx('#2b3034'), 1.2)
    for k in range(13):
        xx = x0 + 12 + (x1 - x0 - 24) * k / 12
        c.vline(xx, ty - 3, ty + 3, hx('#2b3034'), 0.6)
    # swim-lane bars above the line
    for r, (a, b, col) in enumerate(((0.05, 0.35, hx('#3f5a6a')), (0.20, 0.55, hx('#4a5a4a')), (0.30, 0.70, hx('#5a5040')))):
        bx0 = x0 + 12 + (x1 - x0 - 24) * a; bx1 = x0 + 12 + (x1 - x0 - 24) * b
        c.rect(bx0, y0 + 10 + r * 9, bx1, y0 + 16 + r * 9, col)
    red = hx('#8a3a33')
    for k, f in enumerate((3 / 12, 6 / 12)):                                   # March, June: crossed out
        mx = x0 + 12 + (x1 - x0 - 24) * f
        c.poly([(mx, ty - 8), (mx + 6, ty - 2), (mx, ty + 4), (mx - 6, ty - 2)], hx('#2f4766'), OUT)
        c.line([(mx - 8, ty - 10), (mx + 8, ty + 6)], red, 1.1)
        c.line([(mx + 8, ty - 10), (mx - 8, ty + 6)], red, 1.1)
        if k == 0:
            c.bezier((mx + 4, ty - 12), ((mx + x0 + 12 + (x1 - x0 - 24) * 0.5) / 2, ty - 24), (x0 + 12 + (x1 - x0 - 24) * 0.5 - 4, ty - 12), red, 0.7)
    hx0 = x0 + 12 + (x1 - x0 - 24) * 0.75
    c.rect(hx0, ty - 12, x1 - 14, ty + 8, None, red, 1)                         # hold block: hatched to the end
    for xx in np.arange(hx0 + 2, x1 - 16, 4):
        c.line([(xx, ty + 7), (xx + 4, ty - 11)], red, 0.5)
    c.bezier((x0 + 12 + (x1 - x0 - 24) * 0.5 + 4, ty - 12), ((x0 + x1) / 2 + 50, ty - 26), (hx0, ty - 12), red, 0.7)
    sticky(c, x1 - 30, y1 - 18, hx('#7a9aa0'))                                 # ARCHI's opinion note
    c.rect(x0, y0, x1, y1, None, OUT, 0.5)


def planning_wall(c, x0, y0, x1, y1, seed=0):
    """organised planning board: columns of sticky notes and flow sketches"""
    rng = random.Random(seed)
    c.occlude(x0 + 2, y0 + 3, x1 + 3, y1 + 5, 90, blur=4); c.apply_shade_now()
    c.box(x0, y0, x1, y1, hx('#4a3e31'), outline=OUT, hl=.03)
    cols = 5
    cw = (x1 - x0 - 8) / cols
    pal = [hx('#a69a58'), hx('#9b7177'), hx('#6f959a'), hx('#8a9a6a')]
    for k in range(cols):
        cx0 = x0 + 4 + k * cw
        c.rect(cx0 + 2, y0 + 5, cx0 + cw - 2, y0 + 12, hx('#7f827d'))
        n = rng.randint(3, 8)
        for j in range(n):
            sticky(c, cx0 + 4 + (j % 2) * 9, y0 + 16 + (j // 2) * 9, pal[k % 4])
    c.ell(x1 - 4, y0 - 2, x1 + 2, y0 + 4, SAFETY)


def high_table(c, x0, x1):
    top = FY - 100
    c.occlude(x0, top, x1, FY, 90, blur=4); c.apply_shade_now()
    c.box((x0 + x1) / 2 - 4, top + 5, (x0 + x1) / 2 + 4, FY - 4, hx('#4a4e51'), outline=OUT, hl=.2)
    c.box((x0 + x1) / 2 - 30, FY - 5, (x0 + x1) / 2 + 30, FY, hx('#2a2d30'), outline=OUT)
    c.box(x0, top, x1, top + 5, hx('#5a4a3c'), outline=OUT, hl=.25)
    for k in range(4):                                                         # printed slides spread out
        sx = x0 + 8 + k * 30
        c.poly([(sx, top), (sx + 24, top - 1), (sx + 25, top + 0.6), (sx + 1, top + 1)], hx('#868a84'), OUT)
    laptop(c, x1 - 26, top, 28, 'off', seed=8)
    return top


def bar_stool_simple(c, x):
    c.box(x - 12, FY - 72, x + 12, FY - 67, hx('#2a2d30'), outline=OUT, hl=.2)
    c.line([(x - 8, FY - 67), (x - 13, FY)], hx('#5a5e61'), 1.4)
    c.line([(x + 8, FY - 67), (x + 13, FY)], hx('#5a5e61'), 1.4)
    c.hline(x - 11, x + 11, FY - 22, hx('#5a5e61'), 1)


def foam_boards(c, x0, n=4, seed=0):
    """presentation foam boards leaning against the wall"""
    rng = random.Random(seed)
    for k in range(n):
        bx = x0 + k * 14
        h = rng.uniform(70, 96)
        w = rng.uniform(56, 72)
        pts = [(bx, FY), (bx + w, FY), (bx + w + 10, FY - h), (bx + 10, FY - h)]
        c.poly(pts, hx('#7a7e7a') if k % 2 else hx('#6e726e'), OUT)
        c.rect(bx + 16, FY - h + 8, bx + w - 4, FY - h + 14, dk(rng.choice([hx('#3f5a6a'), hx('#5a5040')]), .1))
        for j in range(3):
            c.rect(bx + 18 + j * 14, FY - 30 - j * 10, bx + 26 + j * 14, FY - 18, hx('#4a5a6a'))


def easel(c, x):
    c.line([(x + 22, FY - 168), (x + 2, FY)], hx('#4a4e51'), 1.4)
    c.line([(x + 22, FY - 168), (x + 42, FY)], hx('#4a4e51'), 1.4)
    c.box(x, FY - 166, x + 44, FY - 106, hx('#7d807c'), outline=OUT, hl=.03)
    for k in range(3):
        c.rect(x + 6, FY - 158 + k * 16, x + 6 + [30, 22, 26][k], FY - 152 + k * 16, hx('#3f5a6a'))
    c.box(x - 2, FY - 106, x + 46, FY - 102, hx('#4a4e51'), outline=OUT)


def requirements_doc(c, x, desk_y):
    """thick bound requirements document; a new tab sticks out of the top page"""
    c.box(x, desk_y - 8, x + 30, desk_y, hx('#7d807a'), outline=OUT)
    c.rect(x, desk_y - 8, x + 4, desk_y, hx('#2f4766'))                       # binding
    for k in range(3):
        c.hline(x + 6, x + 28, desk_y - 6 + k * 2, hx('#5a5e5a'), 0.4)
    c.rect(x + 22, desk_y - 12, x + 27, desk_y - 8, hx('#8a3a33'))            # red tab on the top item


# ============================================================ MEETING
def felt_tiles(c, x0, y0, x1, y1, s=36):
    cols = [hx('#363a3d'), hx('#323639'), hx('#3a3e42')]
    for i, y in enumerate(np.arange(y0, y1, s)):
        for j, x in enumerate(np.arange(x0, x1, s)):
            col = cols[(i * 3 + j * 2) % 3]
            c.box(x + 1, y + 1, min(x + s, x1) - 1, min(y + s, y1) - 1, col, outline=None, hl=.05, sh=.15)
    c.rect(x0, y0, x1, y1, None, OUT, 0.6)


def sliding_whiteboards(c, x0, x1, y0, y1):
    """two whiteboard panels on a top rail, the front one slid half across"""
    c.box(x0 - 6, y0 - 8, x1 + 6, y0 - 4, hx('#6a6e70'), outline=OUT, hl=.2)
    w = (x1 - x0) * 0.6
    for k, (a, shade) in enumerate(((x0, 0.0), (x1 - w, 0.06))):
        c.occlude(a + 2, y0 + 2, a + w + 3, y1 + 4, 70, blur=3); c.apply_shade_now()
        c.rect(a, y0 - 4, a + w, y1, hx('#5a5e60'))
        c.vgrad(a + 3, y0 - 1, a + w - 3, y1 - 3, dk(hx('#73787a'), shade), dk(hx('#5e6365'), shade))
        c.rect(a, y0 - 4, a + w, y1, None, OUT, 0.6)
        for r in (a + 10, a + w - 14):
            c.ell(r, y0 - 9, r + 5, y0 - 4, hx('#3a3e41'), OUT, 0.4)
    ink = hx('#2b3034'); red = hx('#7b3a33')
    # back board: priority list, the new top item boxed in red
    for k in range(6):
        c.hline(x0 + 12, x0 + 12 + [70, 54, 62, 48, 58, 40][k], y0 + 14 + k * 11, ink, 0.8)
    c.rect(x0 + 8, y0 + 7, x0 + 90, y0 + 19, None, red, 1)
    c.line([(x0 + 92, y0 + 13), (x0 + 108, y0 + 6)], red, 0.8)
    # front board: a calendar grid, one date ringed three days ahead of a marked date
    fx = x1 - w + 14
    for r in range(5):
        for k in range(7):
            c.rect(fx + k * 14, y0 + 10 + r * 12, fx + k * 14 + 12, y0 + 20 + r * 12, None, hx('#4f5458'), 0.5)
    c.ell(fx + 4 * 14 - 2, y0 + 10 + 2 * 12 - 2, fx + 4 * 14 + 14, y0 + 20 + 2 * 12 + 2, None, red, 1)
    c.rect(fx + 1 * 14 + 2, y0 + 12 + 2 * 12, fx + 1 * 14 + 10, y0 + 18 + 2 * 12, hx('#2f4766'))
    c.bezier((fx + 1 * 14 + 10, y0 + 28), (fx + 2.5 * 14, y0 + 18), (fx + 4 * 14 - 2, y0 + 26), hx('#2f4766'), 0.7)


def ring_pendant(c, cx, y, r=90, top=None):
    for dx in (-r * 0.7, r * 0.7):
        c.vline(cx + dx, top, y, hx('#4a4e51'), 0.4)
    c.ell(cx - r, y - 6, cx + r, y + 6, None, OUT, 4.2)
    c.ell(cx - r, y - 6, cx + r, y + 6, None, hx('#3a3e41'), 2.6)
    c.ell(cx - r + 2, y - 4.5, cx + r - 2, y + 4.5, None, hx('#6a6e70'), 0.6)
