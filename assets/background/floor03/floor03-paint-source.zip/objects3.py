import random, math
import numpy as np
from PIL import Image, ImageDraw
from lib import *
from objects import *

ORANGE = hx('#b8622e')
ORANGE_D = hx('#5a3a26')
FOAM = hx('#26282b')


# ============================================================ GYM
def clerestory(c, x0, y0, x1, y1, seed=0):
    """high ribbon window: night sky above, sodium street glow below"""
    rng = random.Random(seed)
    c.vgrad(x0, y0, x1, y1, hx('#121a26'), hx('#3a2e24'))
    for k in range(int((x1 - x0) / 260) + 1):
        paint_glow(c, (x0, y0, x1, y1), ('ell', x0 + 120 + k * 260 + rng.uniform(-40, 40), y1 + 30, 160, 40), hx('#b08a62'), 0.5, blur=20)
    # dark rooftops / tree tops at the very bottom
    xx = x0
    while xx < x1:
        w = rng.uniform(30, 90); h = rng.uniform(3, 12)
        c.rect(xx, y1 - h, min(xx + w, x1), y1, hx('#14110f'))
        xx += w
    tdraw(c, (x0, y0, x1, y1), lambda od, ox, oy: od.rectangle([P(x0) + ox, P(y0) + oy, P(x1) + ox, P(y1) + oy], fill=(40, 52, 60, 40)))
    for m in np.arange(x0, x1 + 1, 175):
        c.box(m - 3, y0, m + 3, y1, hx('#2a2e31'), outline=None, hl=.15)
    c.rect(x0 - 4, y0 - 4, x1 + 4, y0, hx('#2a2e31')); c.box(x0 - 6, y1, x1 + 6, y1 + 5, hx('#44494c'), outline=OUT)
    c.rect(x0 - 4, y0, x0, y1, hx('#2a2e31')); c.rect(x1, y0, x1 + 4, y1, hx('#2a2e31'))
    for m in np.arange(x0, x1, 175):
        reflection(c, m, y0, min(m + 175, x1), y1, 10, 0.4, 0.14)


def neon_strip(c, x0, x1, y):
    for x in np.arange(x0 + 20, x1, 120):
        c.rect(x - 2, y - 3, x + 2, y + 5, hx('#3a3836'))
    c.box(x0, y, x1, y + 4, ORANGE_D, outline=OUT, hl=.25)
    c.hline(x0 + 2, x1 - 2, y + 1, mix(ORANGE_D, ORANGE, .25), 0.6)


def mirror_wall(c, x0, y0, x1, y1, panel=132, crack_panel=2, ghosts=()):
    """GX mirror panels. ghosts: list of (cx, w, h) dim reflected silhouettes"""
    c.vgrad(x0, y0, x1, y1, hx('#2e3436'), hx('#1e2224'))
    for gx, gw, gh in ghosts:                       # soft reflected silhouettes of the machines
        c.occlude(gx - gw / 2 + 10, y1 - gh + 10, gx + gw / 2 - 10, y1, 90, blur=9)
    c.apply_shade_now()
    # sodium light from the clerestory caught at the top of the mirror
    paint_glow(c, (x0, y0, x1, y1), ('rect', x0, y0 - 20, x1, y0 + 6), hx('#9a7a58'), 0.35, blur=14)
    for k, px in enumerate(np.arange(x0, x1, panel)):
        px1 = min(px + panel, x1)
        reflection(c, px, y0, px1, y1, 16, 0.25 + 0.1 * (k % 3), 0.16)
        reflection(c, px, y0, px1, y1, 9, 0.7, 0.06)
        c.vline(px, y0, y1, hx('#15181a'), 1)
        c.vline(px + 1, y0, y1, hx('#5a6366'), 0.5)
        if k == crack_panel:
            cx_, cy_ = px + panel * 0.55, y0 + (y1 - y0) * 0.42
            rng = random.Random(7)
            for j in range(9):
                a = j / 9 * 2 * math.pi + rng.uniform(-.2, .2)
                L = rng.uniform(26, 70)
                pts = [(cx_, cy_)]
                for s in range(1, 4):
                    pts.append((cx_ + math.cos(a) * L * s / 3 + rng.uniform(-3, 3), cy_ + math.sin(a) * L * s / 3 + rng.uniform(-3, 3)))
                pts = [(min(max(x, px + 2), px1 - 2), min(max(y, y0 + 2), y1 - 2)) for x, y in pts]
                c.line(pts, hx('#8a9496'), 0.6)
                tline(c, [(p[0] + 0.7, p[1] + 0.7) for p in pts], hx('#0d0f10'), 120, 0.6)
            c.ell(cx_ - 5, cy_ - 5, cx_ + 5, cy_ + 5, None, hx('#9aa4a6'), 0.7)
    c.box(x0 - 3, y0 - 4, x1 + 3, y0, hx('#4e5457'), outline=OUT)
    c.box(x0 - 3, y1, x1 + 3, y1 + 5, hx('#4e5457'), outline=OUT)


def treadmill(c, x, length=188, facing=1, seed=0, marks=True, key_dangling=False):
    """running machine in side profile; facing=1 console on the right"""
    rng = random.Random(seed)
    x0, x1 = x, x + length
    front = x1 if facing > 0 else x0
    c.occlude(x0 - 4, FY - 8, x1 + 4, FY + 1, 120, blur=3)
    # deck + side rail
    c.box(x0, FY - 26, x1, FY - 10, hx('#2a2d30'), outline=OUT, hl=.15)
    c.rect(x0 + 6, FY - 10, x0 + 16, FY, hx('#1c1e20'))
    c.rect(x1 - 16, FY - 10, x1 - 6, FY, hx('#1c1e20'))
    # belt top with tread marks
    c.rect(x0 + 4, FY - 28, x1 - 4, FY - 26, hx('#16181a'))
    if marks:
        for xx in np.arange(x0 + 10, x1 - 40, 7):
            c.rect(xx, FY - 28, xx + 3, FY - 27, hx('#3c4043'))
    c.ell(x0 - 3, FY - 30, x0 + 9, FY - 18, hx('#3a3e41'), OUT, 0.6)        # rear roller
    # motor hood at the front
    hx0 = x1 - 44 if facing > 0 else x0
    c.box(hx0, FY - 36, hx0 + 44, FY - 10, hx('#33373a'), outline=OUT, hl=.15)
    c.rect(hx0 + 6, FY - 33, hx0 + 38, FY - 31, hx('#4a4e51'))
    # uprights
    ux = x1 - 30 if facing > 0 else x0 + 30
    c.poly([(ux - 4, FY - 34), (ux + 4, FY - 34), (ux + 4 + 8 * facing, FY - 128), (ux - 4 + 8 * facing, FY - 128)], hx('#45494c'), OUT)
    # handrail back toward the middle
    c.box(min(ux, ux - 70 * facing), FY - 102, max(ux, ux - 70 * facing), FY - 97, hx('#3a3e41'), outline=OUT, hl=.2)
    c.box(min(ux, ux - 70 * facing) - (2 if facing > 0 else -66), FY - 104, min(ux, ux - 70 * facing) + (8 if facing > 0 else 72), FY - 95, hx('#1c1e20'), outline=OUT)
    # console
    cx = ux + 8 * facing
    pts = [(cx - 22, FY - 142), (cx + 22, FY - 136), (cx + 20, FY - 120), (cx - 22, FY - 124)]
    if facing < 0:
        pts = [(2 * cx - p[0], p[1]) for p in pts]
    c.poly(pts, hx('#2b2f32'), OUT)
    c.poly([(pts[0][0] + 4 * facing, pts[0][1] + 3), (pts[1][0] - 4 * facing, pts[1][1] + 3), (pts[2][0] - 4 * facing, pts[2][1] - 3), (pts[3][0] + 4 * facing, pts[3][1] - 3)], hx('#121516'))
    led(c, cx + 14 * facing, FY - 130, RED, 0.5, 0.45)                     # standby light
    if key_dangling:
        c.line([(cx - 6, FY - 122), (cx - 8, FY - 104), (cx - 4, FY - 98)], hx('#7a3b33'), 0.8)
        c.ell(cx - 7, FY - 99, cx - 1, FY - 94, hx('#a04a40'), OUT, 0.4)


def power_rack(c, x0, x1, seed=0):
    top = FY - 204
    c.occlude(x0 - 4, FY - 6, x1 + 4, FY + 1, 110, blur=3)
    # rear posts (darker), front posts
    for px in (x0 + 10, x1 - 18):
        c.box(px + 4, top + 4, px + 12, FY - 2, hx('#26292b'), outline=OUT)
    for px in (x0, x1 - 8):
        c.box(px, top, px + 8, FY, hx('#3c4043'), outline=OUT, hl=.2)
        for yy in np.arange(top + 10, FY - 10, 9):
            c.rect(px + 3, yy, px + 5, yy + 2, hx('#15171a'))
    c.box(x0, top, x1, top + 7, hx('#3c4043'), outline=OUT, hl=.2)
    c.box(x0 - 6, FY - 6, x1 + 6, FY, hx('#2a2d30'), outline=OUT)
    # J-hooks + barbell with plates
    by = FY - 140
    for px in (x0 + 8, x1 - 8):
        c.rect(px - 2, by, px + 6, by + 5, hx('#55595c'))
    c.box(x0 - 30, by - 2, x1 + 30, by + 2, hx('#8a8f92'), outline=OUT, hl=.2)
    for side in (-1, 1):
        ex = x0 - 26 if side < 0 else x1 + 10
        for k, (pw, ph) in enumerate(((6, 46), (5, 40), (4, 30))):
            px = ex + (k * 6 if side < 0 else -k * 6 + 10)
            c.box(px, by - ph / 2, px + pw, by + ph / 2, hx('#1d1f21'), outline=OUT, hl=.15)
    # flat bench inside the rack, side-on
    c.box(x0 + 24, FY - 46, x1 - 24, FY - 38, hx('#2a1f1c'), outline=OUT, hl=.15)
    for lx in (x0 + 34, x1 - 40):
        c.box(lx, FY - 38, lx + 6, FY - 2, hx('#3c4043'), outline=OUT)
    c.box(x0 + 28, FY - 4, x1 - 28, FY, hx('#2a2d30'), outline=OUT)


def dumbbell_rack(c, x0, x1, seed=0):
    rng = random.Random(seed)
    c.occlude(x0 - 2, FY - 70, x1 + 2, FY, 100, blur=3)
    for lx in (x0, x1 - 6):
        c.box(lx, FY - 70, lx + 6, FY, hx('#2c2f32'), outline=OUT)
    for tier, ty in enumerate((FY - 66, FY - 32)):
        c.box(x0, ty + 18, x1, ty + 23, hx('#3a3e41'), outline=OUT, hl=.15)
        xx = x0 + 10
        k = 0
        while xx < x1 - 22:
            s = 10 + (k % 5) * 1.6 + tier * 2
            if rng.random() < 0.12:                          # missing pair
                xx += s * 2 + 6; k += 1; continue
            for d in (0, s + 2):
                cx_, cy_ = xx + d + s / 2, ty + 18 - s / 2
                pts = [(cx_ + math.cos(a) * s / 2, cy_ + math.sin(a) * s / 2) for a in np.linspace(0, 2 * math.pi, 7)[:-1] + math.pi / 6]
                c.poly(pts, hx('#1b1d1f'), OUT)
                c.ell(cx_ - 1.5, cy_ - 1.5, cx_ + 1.5, cy_ + 1.5, hx('#55595c'))
            xx += s * 2 + 6; k += 1
    # one dumbbell left on the floor
    cx_, cy_ = x1 + 8, FY - 7
    c.box(cx_ - 10, cy_ - 1.5, cx_ + 10, cy_ + 1.5, hx('#55595c'), outline=OUT)
    for d in (-10, 10):
        pts = [(cx_ + d + math.cos(a) * 7, cy_ + math.sin(a) * 7) for a in np.linspace(0, 2 * math.pi, 7)[:-1]]
        c.poly(pts, hx('#1b1d1f'), OUT)


def kettlebell(c, x, s=1.0):
    c.ell(x - 9 * s, FY - 18 * s, x + 9 * s, FY, hx('#1c1e20'), OUT, 0.6)
    c.ell(x - 6 * s, FY - 27 * s, x + 6 * s, FY - 14 * s, None, hx('#1c1e20'), 2.2 * s)
    c.hline(x - 6 * s, x - 1 * s, FY - 14 * s, hx('#4a4e51'), 0.6)


def exercise_ball(c, x):
    c.occlude(x - 30, FY - 6, x + 30, FY + 1, 110, blur=3, ellipse=True)
    c.ell(x - 30, FY - 60, x + 30, FY, hx('#3c4a52'), OUT, 1)
    c.ell(x - 22, FY - 54, x - 4, FY - 40, hx('#4c5a62'))
    c.line([(x - 28, FY - 30), (x + 28, FY - 30)], hx('#33414a'), 0.6)


def mat_bin(c, x):
    c.box(x, FY - 40, x + 44, FY, hx('#2c2f32'), outline=OUT, hl=.1)
    cols = [hx('#3f5a5a'), hx('#5a3f45'), hx('#4a4a3a'), hx('#3a4458')]
    for k in range(4):
        mx = x + 4 + k * 10
        c.rrect(mx, FY - 78 + (k % 2) * 6, mx + 9, FY - 38, 4, cols[k], OUT, 0.6)
        c.ell(mx, FY - 80 + (k % 2) * 6, mx + 9, FY - 74 + (k % 2) * 6, dk(cols[k], .25), OUT, 0.5)


def lockers(c, x0, cols=3, w=40, h=167, open_idx=1, seed=0):
    top = FY - h
    x1 = x0 + cols * w
    c.occlude(x0 - 3, top, x1 + 3, FY, 115, blur=5)
    c.apply_shade_now()
    col = hx('#3a4044')
    for k in range(cols):
        lx = x0 + k * w
        for r, (ry0, ry1) in enumerate(((top, top + h / 2), (top + h / 2, FY - 10))):
            if k == open_idx and r == 0:
                c.rect(lx + 1, ry0 + 1, lx + w - 1, ry1 - 1, hx('#121416'))
                c.box(lx + 4, ry0 + 6, lx + w - 4, ry0 + 9, hx('#2c3033'), outline=None)
                c.rrect(lx + 10, ry0 + 9, lx + 22, ry0 + 46, 3, hx('#3a3634'), OUT, 0.6)   # hanging jacket/towel
                c.box(lx + 24, ry1 - 22, lx + 36, ry1 - 4, hx('#2c3a3e'), outline=OUT)      # bag
                # door swung open, edge-on
                c.box(lx + w, ry0 + 2, lx + w + 5, ry1 - 2, hx('#4c5357'), outline=OUT, hl=.2)
                continue
            c.box(lx, ry0, lx + w, ry1, col, outline=OUT, hl=.08, sh=.3)
            for v in range(4):
                c.hline(lx + 8, lx + w - 8, ry0 + 8 + v * 3, dk(col, .35), 0.6)
            c.rect(lx + w - 10, ry0 + (ry1 - ry0) / 2 - 6, lx + w - 6, ry0 + (ry1 - ry0) / 2 + 6, hx('#8a9196'))
            c.rect(lx + 6, ry1 - 16, lx + 18, ry1 - 10, dk(PAPER, .15))     # blank number plate
    c.rect(x0, FY - 10, x1, FY, hx('#24282b'))
    # locker bench
    c.box(x0 - 4, FY - 44, x1 + 4, FY - 38, hx('#5a4a3a'), outline=OUT, hl=.2)
    for lx in (x0 + 6, x1 - 12):
        c.box(lx, FY - 38, lx + 6, FY, hx('#3a3e41'), outline=OUT)
    c.poly([(x0 + 30, FY - 44), (x0 + 70, FY - 44), (x0 + 74, FY - 30), (x0 + 64, FY - 26), (x0 + 34, FY - 34)], hx('#4a5258'), OUT)  # towel


def trainer_desk(c, x0, x1):
    top = FY - 97
    c.occlude(x0 - 3, top, x1 + 3, FY, 110, blur=4); c.apply_shade_now()
    c.box(x0, top + 4, x1, FY, hx('#2e2a27'), outline=OUT, hl=.08)
    c.box(x0 + 4, top + 12, x1 - 4, top + 16, ORANGE_D, outline=None)
    c.box(x0 - 4, top, x1 + 4, top + 4, hx('#5a5048'), outline=OUT, hl=.2)
    laptop(c, x0 + 26, top, 26, 'off', seed=3)
    # PT clipboard + speed chart printout
    c.box(x1 - 34, top - 3, x1 - 10, top, hx('#5e5242'), outline=OUT)
    c.rect(x1 - 32, top - 4, x1 - 12, top - 3, hx('#7f827d'))
    bottle(c, x1 - 4, top)


def speed_chart(c, x0, y0, w=54, h=44):
    """printout pinned on the wall: many short bars, one marked bar, three taller red bars"""
    c.occlude(x0 + 1, y0 + 2, x0 + w + 2, y0 + h + 3, 70, blur=2); c.apply_shade_now()
    c.box(x0, y0, x0 + w, y0 + h, hx('#808380'), outline=OUT, hl=.02)
    base = y0 + h - 5
    rng = random.Random(4)
    n = 16
    for k in range(n):
        bx = x0 + 4 + k * (w - 8) / n
        bh = rng.uniform(6, 18)
        col = hx('#4f5458')
        if k == 10:
            bh = 22; col = hx('#2f4766')
        if k in (13, 14, 15):
            bh = 26 + (k - 13) * 3; col = hx('#8a3a33')
        c.rect(bx, base - bh, bx + (w - 8) / n - 0.8, base, col)
    c.ell(x0 + 4 + 10 * (w - 8) / n - 3, base - 27, x0 + 4 + 11 * (w - 8) / n + 2, base - 18, None, hx('#2f4766'), 0.6)
    c.ell(x0 + w / 2 - 1.5, y0 - 1, x0 + w / 2 + 1.5, y0 + 2, ORANGE)


def door_button(c, x, y):
    """battery emergency-open button for the member-only automatic door"""
    c.box(x, y, x + 16, y + 22, hx('#5a5f62'), outline=OUT, hl=.1)
    c.ell(x + 3, y + 4, x + 13, y + 14, hx('#2f6a45'), OUT, 0.6)
    c.ell(x + 5, y + 6, x + 11, y + 12, hx('#7fd0a0'))
    c.glow_ell(x + 8, y + 9, 9, 9, hx('#4fb57a'), 0.7, blur=5)
    c.rect(x + 4, y + 16, x + 12, y + 19, hx('#8a7a3a'))


def bottle(c, x, desk_y):
    tpoly(c, [(x - 2.5, desk_y), (x + 2.5, desk_y), (x + 2.5, desk_y - 13), (x + 1.2, desk_y - 16), (x - 1.2, desk_y - 16), (x - 2.5, desk_y - 13)], hx('#8aa0ae'), 70)
    c.rect(x - 1.3, desk_y - 18, x + 1.3, desk_y - 16, hx('#2f4766'))


def cage_pendant(c, x, y):
    c.vline(x, 212, y, hx('#3a3e41'), 0.6)
    c.box(x - 4, y, x + 4, y + 5, hx('#2a2d30'), outline=OUT)
    c.poly([(x - 9, y + 5), (x + 9, y + 5), (x + 7, y + 20), (x - 7, y + 20)], None, OUT)
    for k in range(4):
        c.line([(x - 9 + k * 6, y + 5), (x - 7 + k * 4.7, y + 20)], hx('#2a2d30'), 0.6)
    c.ell(x - 5, y + 9, x + 5, y + 19, hx('#3d3a35'))


def spiral_duct(c, x0, x1, y0, y1):
    c.box(x0, y0, x1, y1, hx('#4a4f53'), outline=OUT, hl=.2, sh=.45)
    for x in np.arange(x0, x1, 10):
        c.line([(x, y0), (x + 6, y1)], hx('#3a3f43'), 0.5)
    for x in np.arange(x0 + 60, x1, 240):
        c.vline(x, 212, y0, hx('#2a2d30'), 0.8)
        c.rect(x - 4, y0 - 1, x + 4, y1 + 1, None, hx('#2a2d30'), 0.8)


# ============================================================ CUSTOMER SERVICE
def acoustic_cloud(c, x0, x1, y):
    c.vline(x0 + 12, 212, y, hx('#2a2f33'), 0.4); c.vline(x1 - 12, 212, y, hx('#2a2f33'), 0.4)
    c.box(x0, y, x1, y + 9, hx('#4a4e55'), outline=OUT, hl=.15, sh=.3)
    for x in np.arange(x0 + 40, x1 - 20, 60):
        c.rect(x - 6, y + 9, x + 6, y + 10.5, hx('#5c6066'))


def desk_phone(c, x, desk_y, msg=False):
    c.poly([(x - 14, desk_y), (x + 14, desk_y), (x + 10, desk_y - 9), (x - 12, desk_y - 7)], hx('#1f2226'), OUT)
    c.rect(x - 8, desk_y - 6, x + 2, desk_y - 3, hx('#2a3236'))
    c.rrect(x - 14, desk_y - 12, x + 6, desk_y - 8, 2, hx('#24282b'), OUT, 0.6)     # handset
    c.bezier((x - 14, desk_y - 10), (x - 24, desk_y + 4), (x - 18, desk_y - 1), hx('#121416'), 0.6)
    if msg:
        led(c, x + 9, desk_y - 6, RED, 0.7, 0.8)
    else:
        c.rect(x + 8, desk_y - 7, x + 10, desk_y - 5, hx('#3a2a28'))


def headset_on_hook(c, x, y):
    c.rect(x - 1, y, x + 3, y + 3, hx('#4a4e51'))
    c.ell(x - 7, y + 1, x + 9, y + 16, None, hx('#16191c'), 1.4)
    c.rrect(x - 9, y + 10, x - 4, y + 18, 2, hx('#16191c'))
    c.line([(x - 6, y + 17), (x - 2, y + 24)], hx('#16191c'), 0.8)
    c.bezier((x + 7, y + 14), (x + 4, y + 40), (x + 10, y + 52), hx('#121416'), 0.6)


def privacy_screen(c, x0, x1, top_y, h=34, col=hx('#3b4350')):
    c.box(x0, top_y - h, x1, top_y, col, outline=OUT, hl=.12, sh=.25)
    for xx in np.arange(x0 + 2, x1 - 1, 3):
        tline(c, [(xx, top_y - h + 2), (xx, top_y - 1)], dk(col, .25), 60, 0.4)
    c.hline(x0, x1, top_y - h, hx('#6a7078'), 0.8)


def side_screen(c, x, top_y, h=44):
    c.box(x - 2, top_y - h, x + 2, top_y, hx('#4a515c'), outline=OUT, hl=.2)


def lateral_files(c, x0, x1, h=122):
    top = FY - h
    c.occlude(x0 - 3, top, x1 + 3, FY, 110, blur=4); c.apply_shade_now()
    col = hx('#3b4046')
    c.box(x0, top, x1, FY - 2, col, outline=OUT, hl=.08, sh=.3)
    n = 4
    dh = (h - 6) / n
    for k in range(n):
        yy = top + 3 + k * dh
        c.rect(x0 + 3, yy, x1 - 3, yy + dh - 2, None, dk(col, .35), 0.6)
        c.box((x0 + x1) / 2 - 12, yy + 6, (x0 + x1) / 2 + 12, yy + 9, hx('#2a2f33'), outline=None)
        c.rect(x0 + 10, yy + 5, x0 + 22, yy + 11, dk(PAPER, .2))
    # one drawer pulled open with folders
    yy = top + 3 + 2 * dh
    c.box(x0 - 3, yy - 1, x1 + 3, yy + dh - 1, dk(col, .1), outline=OUT, hl=.2)
    for k in range(12):
        fx = x0 + 6 + k * (x1 - x0 - 12) / 12
        c.rect(fx, yy - 8 - (k % 3) * 2, fx + 4, yy, hx('#6a5d45') if k % 4 else hx('#3f5466'))


def key_cabinet(c, x, y, w=54, h=72):
    c.occlude(x + 1, y + 2, x + w + 2, y + h + 3, 90, blur=3); c.apply_shade_now()
    c.box(x, y, x + w, y + h, hx('#4c5358'), outline=OUT, hl=.08)
    c.rect(x + 3, y + 3, x + w - 3, y + h - 3, hx('#1a1d20'))
    for r in range(4):
        for k in range(5):
            hx0 = x + 8 + k * 9.5; hy = y + 10 + r * 15
            c.rect(hx0, hy, hx0 + 1.5, hy + 3, hx('#8a9196'))
            if (r, k) in ((0, 1), (2, 3)):                      # the few keys still there
                c.ell(hx0 - 1.5, hy + 3, hx0 + 3, hy + 7, hx('#9a8a5a'), OUT, 0.4)
                c.rect(hx0, hy + 7, hx0 + 1.5, hy + 11, hx('#9a8a5a'))
            elif (r, k) == (3, 2):                              # empty hook, red tag left behind
                c.rect(hx0 - 2, hy + 4, hx0 + 4, hy + 9, hx('#8a3a33'))
                c.glow_rect(hx0 - 2, hy + 4, hx0 + 4, hy + 9, RED, 0.2, blur=3)
            elif (r * 5 + k) % 2 == 0:
                c.rect(hx0 - 1.5, hy + 4, hx0 + 3.5, hy + 8, dk(PAPER, .15))     # tag only
    # door swung open (edge-on, to the left)
    c.box(x - 5, y + 1, x, y + h - 1, hx('#5a6166'), outline=OUT, hl=.2)


def script_board(c, x0, y0, x1, y1, seed=0):
    rng = random.Random(seed)
    c.occlude(x0 + 2, y0 + 3, x1 + 3, y1 + 5, 90, blur=4); c.apply_shade_now()
    c.box(x0, y0, x1, y1, hx('#4b5056'), outline=OUT, hl=.05)
    c.rect(x0 + 3, y0 + 3, x1 - 3, y1 - 3, hx('#55595c'))
    sw = (x1 - x0 - 16) / 3
    for k in range(6):
        px = x0 + 6 + (k % 3) * (sw + 2); py = y0 + 6 + (k // 3) * ((y1 - y0 - 12) / 2)
        ph = (y1 - y0 - 18) / 2
        c.box(px, py, px + sw, py + ph, hx('#6f726f'), outline=OUT, hl=.02)
        for ln in range(7):
            c.hline(px + 3, px + 3 + rng.uniform(sw * .4, sw - 8), py + 5 + ln * 4.2, hx('#50555a'), 0.5)
        # handwritten red additions at the bottom of the night-script sheets
        if k in (3, 4, 5):
            for ln in range(2):
                yy = py + ph - 12 + ln * 5
                pts = [(px + 4 + i * 3, yy + rng.uniform(-0.8, 0.8)) for i in range(int((sw - 10) / 3))]
                c.line(pts, hx('#8a3a33'), 0.6)
        c.ell(px + sw / 2 - 1.5, py - 1, px + sw / 2 + 1.5, py + 2, hx('#2f4766'))


def survey_screen(c, x0, y0, x1, y1):
    """laptop screen: hourly bars with a huge night spike + flooding rows"""
    c.vgrad(x0, y0, x1, y1, hx('#101820'), hx('#0b1117'))
    n = 24
    bw = (x1 - x0 - 4) / n
    for k in range(n):
        h = (y1 - y0) * (0.08 + (0.62 if 1 <= k <= 4 else 0.06 * (k % 3)))
        c.rect(x0 + 2 + k * bw, y1 - 2 - h, x0 + 2 + (k + 0.7) * bw, y1 - 2, wa(RED if 1 <= k <= 4 else BLUE, 255))
    c.glow_rect(x0, y0, x1, y1, BLUE, 0.4, blur=8)


# ============================================================ STUDIO
def foam_wall(c, x0, y0, x1, y1):
    c.rect(x0, y0, x1, y1, hx('#16181a'))
    t = 12
    for yy in np.arange(y0, y1, t):
        for k, xx in enumerate(np.arange(x0, x1, t)):
            flip = (int((xx - x0) / t) + int((yy - y0) / t)) % 2
            a, b = xx, min(xx + t, x1); cc, d = yy, min(yy + t, y1)
            if flip:
                c.poly([(a, cc), (b, cc), (a, d)], hx('#2a2c2f'))
                c.poly([(b, cc), (b, d), (a, d)], hx('#1d1f21'))
            else:
                c.poly([(a, cc), (b, d), (a, d)], hx('#2a2c2f'))
                c.poly([(a, cc), (b, cc), (b, d)], hx('#222427'))


def pipe_grid(c, x0, x1, y):
    for x in np.arange(x0 + 30, x1, 200):
        c.vline(x, 212, y, hx('#2a2d30'), 1)
    c.box(x0, y, x1, y + 5, hx('#3a3e41'), outline=OUT, hl=.25)
    c.box(x0, y - 18, x1, y - 14, hx('#2e3134'), outline=OUT, hl=.2)


def fresnel(c, x, y, aim=1):
    c.rect(x - 1, y + 5, x + 1, y + 14, hx('#4a4e51'))
    c.line([(x - 10, y + 14), (x - 10, y + 22)], hx('#4a4e51'), 1)
    c.line([(x + 10, y + 14), (x + 10, y + 22)], hx('#4a4e51'), 1)
    c.rect(x - 10, y + 12, x + 10, y + 14, hx('#4a4e51'))
    pts = [(x - 9, y + 16), (x + 9, y + 16), (x + 9 + 6 * aim, y + 38), (x - 9 + 6 * aim, y + 38)]
    c.poly(pts, hx('#1f2123'), OUT)
    c.poly([(x - 7 + 6 * aim, y + 38), (x + 7 + 6 * aim, y + 38), (x + 9 + 6 * aim, y + 44), (x - 9 + 6 * aim, y + 44)], hx('#2e3134'), OUT)
    c.bezier((x + 9, y + 20), (x + 30, y + 10), (x + 50, y + 2), hx('#121416'), 0.7)


def light_stand(c, x, top_y, sandbag=True):
    c.line([(x, top_y), (x, FY - 34)], hx('#4a4e51'), 1.6)
    c.line([(x, FY - 34), (x - 22, FY)], hx('#4a4e51'), 1.2)
    c.line([(x, FY - 34), (x + 22, FY)], hx('#4a4e51'), 1.2)
    c.line([(x, FY - 34), (x + 4, FY)], hx('#3a3e41'), 1)
    c.rect(x - 3, FY - 38, x + 3, FY - 32, hx('#2a2d30'))
    if sandbag:
        c.rrect(x + 8, FY - 9, x + 28, FY, 3, hx('#3e3a30'), OUT, 0.6)


def softbox(c, x, y, facing=1):
    """softbox head on a stand, angled toward the set"""
    light_stand(c, x, y + 10)
    f = facing
    pts = [(x - 4 * f, y), (x + 34 * f, y - 26), (x + 34 * f, y + 46), (x - 4 * f, y + 20)]
    c.poly(pts, hx('#1c1e20'), OUT)
    c.poly([(x + 30 * f, y - 22), (x + 36 * f, y - 26), (x + 36 * f, y + 46), (x + 30 * f, y + 42)], hx('#5e6264'), OUT)   # diffuser edge
    c.rect(min(x - 8 * f, x), y + 6, max(x - 8 * f, x), y + 14, hx('#2a2d30'))


def led_panel(c, x, y):
    light_stand(c, x, y + 30)
    c.line([(x, y + 30), (x - 8, y + 22)], hx('#4a4e51'), 1.2)
    c.box(x - 34, y - 8, x + 18, y + 22, hx('#232528'), outline=OUT, hl=.15)
    c.rect(x - 31, y - 5, x + 15, y + 19, hx('#3a3e41'))
    for r in range(4):
        for k in range(8):
            c.rect(x - 29 + k * 5.6, y - 3 + r * 5.6, x - 27 + k * 5.6, y - 1 + r * 5.6, hx('#55595c'))


def backdrop(c, x0, x1, top):
    # stands + crossbar + paper roll
    for px in (x0 - 12, x1 + 8):
        c.box(px, top - 6, px + 4, FY - 30, hx('#4a4e51'), outline=OUT, hl=.2)
        c.line([(px + 2, FY - 30), (px - 18, FY)], hx('#4a4e51'), 1.2)
        c.line([(px + 2, FY - 30), (px + 22, FY)], hx('#4a4e51'), 1.2)
    c.box(x0 - 14, top - 6, x1 + 14, top - 2, hx('#5a5e60'), outline=OUT, hl=.2)
    c.box(x0 - 4, top - 2, x1 + 4, top + 8, hx('#6a6e70'), outline=OUT, hl=.25)
    paper = hx('#43474a')
    c.vgrad(x0, top + 8, x1, FY - 10, lit(paper, .05), dk(paper, .15))
    c.hgrad(x0, top + 8, x0 + 60, FY - 10, wa(hx('#141516'), 150), wa(hx('#141516'), 0))
    c.hgrad(x1 - 60, top + 8, x1, FY - 10, wa(hx('#141516'), 0), wa(hx('#141516'), 150))
    c.vgrad(x0, FY - 10, x1, FY, dk(paper, .15), dk(paper, .05))
    c.rect(x0, top + 8, x1, FY, None, OUT, 0.8)
    # scuffed footprints near the bottom of the sweep and a wrinkle
    for k in range(6):
        fx = x0 + 120 + k * 22
        c.rrect(fx, FY - 6, fx + 9, FY - 3, 1.5, dk(paper, .3))
    c.line([(x0 + 40, top + 40), (x0 + 60, top + 170), (x0 + 52, FY - 20)], dk(paper, .12), 0.8)
    c.vline(x1 - 30, top + 8, FY - 6, lit(paper, .08), 0.6)


def bar_stool(c, x):
    c.occlude(x - 18, FY - 3, x + 18, FY + 1, 110, blur=3, ellipse=True)
    c.box(x - 16, FY - 72, x + 16, FY - 66, hx('#3a322c'), outline=OUT, hl=.3)
    for sx in (-1, 1):
        c.line([(x + 12 * sx, FY - 66), (x + 18 * sx, FY)], OUT, 2.6)
        c.line([(x + 12 * sx, FY - 66), (x + 18 * sx, FY)], hx('#6a6e71'), 1.4)
    c.hline(x - 15, x + 15, FY - 24, hx('#6a6e71'), 1.2)


def video_camera(c, x, facing=1, tally=True):
    """camera on a tripod in profile, field monitor on top showing the empty set"""
    f = facing
    head_y = FY - 120
    c.occlude(x - 34, FY - 4, x + 34, FY + 1, 110, blur=3, ellipse=True)
    for dx in (-30, 30):
        c.line([(x, head_y + 10), (x + dx, FY)], hx('#3a3e41'), 1.8)
    c.line([(x, head_y + 10), (x - 2, FY)], hx('#2a2d30'), 1.4)
    c.line([(x - 15, FY - 50), (x + 15, FY - 50)], hx('#2a2d30'), 1)                # spreader
    c.box(x - 8, head_y + 2, x + 8, head_y + 12, hx('#2a2d30'), outline=OUT)
    c.line([(x - 8 * f, head_y + 6), (x - 48 * f, head_y + 22)], hx('#3a3e41'), 1.6)  # pan bar
    # body + lens
    bx0, bx1 = (x - 22, x + 18) if f > 0 else (x - 18, x + 22)
    c.box(bx0, head_y - 22, bx1, head_y + 2, hx('#1d1f22'), outline=OUT, hl=.12)
    lx0 = bx1 if f > 0 else bx0 - 34
    c.box(lx0, head_y - 18, lx0 + 34, head_y - 2, hx('#24272a'), outline=OUT, hl=.15)
    c.box(lx0 + (28 if f > 0 else -4), head_y - 22, lx0 + (40 if f > 0 else 8), head_y + 2, hx('#16181a'), outline=OUT)  # hood
    c.rect(lx0 + 6, head_y - 16, lx0 + 22, head_y - 4, hx('#2e3134'))
    # handle + top field monitor (battery) showing the empty stool
    c.box(bx0 + 4, head_y - 28, bx1 - 6, head_y - 22, hx('#2a2d30'), outline=OUT)
    mx0, my0 = bx0 + 2, head_y - 52
    c.box(mx0, my0, mx0 + 34, my0 + 22, hx('#121416'), outline=OUT)
    c.vgrad(mx0 + 2, my0 + 2, mx0 + 32, my0 + 20, hx('#6a6e70'), hx('#4a4e50'))
    c.rect(mx0 + 15, my0 + 9, mx0 + 21, my0 + 11, hx('#202224'))                    # stool seat in the feed
    c.line([(mx0 + 16, my0 + 11), (mx0 + 14, my0 + 19)], hx('#202224'), 0.7)
    c.line([(mx0 + 20, my0 + 11), (mx0 + 22, my0 + 19)], hx('#202224'), 0.7)
    c.glow_rect(mx0, my0, mx0 + 34, my0 + 22, hx('#9aa6ac'), 0.4, blur=6)
    c.box(mx0 + 14, my0 + 22, mx0 + 18, head_y - 28, hx('#2a2d30'), outline=None)
    # red tally light on the front
    if tally:
        tx = lx0 + (30 if f > 0 else 4)
        led(c, tx, head_y - 25, RED, 1.1, 1.0)
        c.glow_ell(tx, head_y - 25, 16, 12, RED, 0.45, blur=8)


def boom_mic(c, x, tip_x, y):
    light_stand(c, x, y + 4, sandbag=True)
    c.line([(x + 30, y + 10), (tip_x, y - 4)], hx('#55595c'), 1.4)
    c.ell(x + 26, y + 6, x + 38, y + 18, hx('#2a2d30'), OUT, 0.6)                     # counterweight
    c.line([(tip_x, y - 4), (tip_x, y + 18)], hx('#2a2d30'), 0.8)
    rng = random.Random(5)
    for k in range(40):                                                             # furry windscreen
        fx = tip_x - 26 + rng.uniform(0, 44); fy = y + 18 + rng.uniform(0, 10)
        c.line([(fx, fy), (fx + rng.uniform(-2, 2), fy + rng.uniform(2, 4))], hx('#5a5650'), 0.6)
    c.rrect(tip_x - 24, y + 19, tip_x + 18, y + 27, 4, hx('#4a4640'))


def road_cases(c, x0, x1):
    c.occlude(x0 - 3, FY - 120, x1 + 3, FY, 110, blur=4); c.apply_shade_now()
    for k, (h, inset) in enumerate(((50, 0), (40, 6), (30, 14))):
        y1 = FY - sum((50, 40, 30)[:k])
        y0 = y1 - h
        a, b = x0 + inset, x1 - inset
        c.box(a, y0, b, y1, hx('#1b1d1f'), outline=OUT, hl=.1)
        c.rect(a, y0, b, y0 + 3, hx('#7a7f82')); c.rect(a, y1 - 3, b, y1, hx('#7a7f82'))
        for cx_ in (a, b - 6):
            c.rect(cx_, y0, cx_ + 6, y0 + 6, hx('#9aa0a3')); c.rect(cx_, y1 - 6, cx_ + 6, y1, hx('#9aa0a3'))
        c.rect((a + b) / 2 - 8, y0 + h / 2 - 2, (a + b) / 2 + 8, y0 + h / 2 + 2, hx('#55595c'))
        if k == 0:
            for wx in (a + 8, b - 16):
                c.ell(wx, FY - 6, wx + 8, FY, hx('#121416'), OUT, 0.4)
    # cable coil hanging on the side
    for r in range(3):
        c.ell(x1 + 2 - r, FY - 100 + r, x1 + 22 + r, FY - 64 + r, None, hx('#16181a'), 1)


def production_desk(c, x0, x1):
    top = FY - 69
    c.occlude(x0 - 3, top, x1 + 3, FY, 110, blur=4); c.apply_shade_now()
    c.box(x0, top, x1, top + 4, hx('#2a2c2f'), outline=OUT, hl=.15)
    for lx in (x0 + 2, x1 - 9):
        c.box(lx, top + 4, lx + 7, FY, hx('#232528'), outline=OUT)
    # audio mixer with faders
    c.poly([(x0 + 6, top), (x0 + 64, top), (x0 + 60, top - 10), (x0 + 10, top - 8)], hx('#24272a'), OUT)
    for k in range(8):
        fx = x0 + 14 + k * 5.6
        c.vline(fx, top - 8, top - 2, hx('#111214'), 0.8)
        c.rect(fx - 1.5, top - 6 + (k * 37 % 5), fx + 1.5, top - 4.6 + (k * 37 % 5), hx('#8a8f92'))
    # switcher + monitor (off) + headphones
    c.box(x0 + 70, top - 6, x1 - 8, top, hx('#1d1f22'), outline=OUT)
    for k in range(6):
        c.rect(x0 + 74 + k * 6, top - 4, x0 + 78 + k * 6, top - 2, hx('#3a3e41'))
    monitor(c, (x0 + x1) / 2 + 20, top - 6, 52, 30, 'off', seed=8)
    c.ell(x1 - 30, top - 14, x1 - 12, top + 2, None, hx('#16191c'), 1.6)
    # rack of recorders under the desk
    c.box(x0 + 12, FY - 46, x0 + 72, FY - 2, hx('#1b1d1f'), outline=OUT)
    for k in range(4):
        c.rect(x0 + 16, FY - 42 + k * 10, x0 + 68, FY - 36 + k * 10, hx('#26292c'))


def gathered_curtain(c, x0, x1, top):
    c.box(x0 - 6, top - 4, x1 + 6, top, hx('#3a3e41'), outline=OUT, hl=.2)
    xx = x0
    k = 0
    while xx < x1:
        w = 6 + (k % 3) * 2
        col = hx('#1e1c1d') if k % 2 else hx('#2b2829')
        c.vgrad(xx, top, min(xx + w, x1), FY - 1, lit(col, .05), dk(col, .15))
        xx += w; k += 1
    c.rect(x0, top, x1, FY - 1, None, OUT, 0.8)
    c.poly([(x0, FY - 1), (x1, FY - 1), (x1 + 6, FY), (x0 - 4, FY)], hx('#1a1819'))   # hem pooling on the floor
