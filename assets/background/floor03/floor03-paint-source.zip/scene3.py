import random, math, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageChops
from lib import *
from objects import *
from objects4 import tape_drive  # noqa (keeps shared helpers importable)
from objects3 import *

X0, X1 = 48, 3152
IX0, IX1 = 78, 3122
TS0, TS1 = 180, 212
FB = 626
GYM = (IX0, 1176); COLA = (1176, 1214); GDOOR = (1214, 1226)
CS = (1226, 2236); COLB = (2236, 2274); CURT = (2276, 2316)
ST = (2274, IX1)

WALL_G = hx('#34302c')
WALL_CS = hx('#343840')

c = Canvas()


def hatch(x0, y0, x1, y1, col=hx('#3a3f44'), step=9):
    def f(od, ox, oy):
        for k in range(int(-(y1 - y0)), int(x1 - x0), step):
            od.line([(P(x0 + k) + ox, P(y1) + oy), (P(x0 + k + (y1 - y0)) + ox, P(y0) + oy)], fill=wa(col, 70), width=P(0.8))
    tdraw(c, (x0, y0, x1, y1), f)


# ------------------------------------------------------------------ shell
def shell():
    c.vgrad(IX0, TS1, IX1, 300, hx('#121212'), hx('#1a1a1b'))
    # gym wall (dark warm gray)
    c.vgrad(GYM[0], 296, GYM[1], FY, dk(WALL_G, .25), WALL_G)
    # CS wall + navy wainscot
    c.vgrad(CS[0], 292, CS[1], FY, dk(WALL_CS, .25), WALL_CS)
    for x in range(int(CS[0]) + 120, int(CS[1]), 170):
        c.vline(x, 292, FY, dk(WALL_CS, .2), 0.8)
    c.vgrad(CS[0], 470, CS[1], FY, hx('#252a36'), hx('#1f232d'))
    c.box(CS[0], 466, CS[1], 470, hx('#5a6070'), outline=OUT, hl=.2)
    # studio: matte black wall
    c.vgrad(ST[0], TS1, ST[1], FY, hx('#18191b'), hx('#202124'))
    # columns
    for (x0, x1) in (COLA, COLB):
        cc = hx('#45484b')
        c.box(x0, TS1, x1, FY, cc, outline=OUT, hl=.06, sh=.35)
        c.vline(x0 + 3, TS1, FY, lit(cc, .15), 0.8)
        c.box(x0 - 2, FY - 12, x1 + 2, FY, dk(cc, .45), outline=OUT)
    c.rect(COLA[0] + 1, FY - 130, COLA[0] + 5, FY - 12, ORANGE_D)
    # skirting
    for (a0, a1), col in ((GYM, dk(WALL_G, .55)), (CS, hx('#171a22'))):
        c.box(a0, FY - 9, a1, FY, col, outline=None)
        c.hline(a0, a1, FY - 9, lit(col, .15), 0.6)
    # floor finishes (section band)
    c.rect(GYM[0], FY, GDOOR[1], FY + 6, hx('#1b1a19'))
    rng = random.Random(3)
    for k in range(900):
        fx = rng.uniform(GYM[0], GDOOR[1]); fy = rng.uniform(FY + 1, FY + 5)
        c.rect(fx, fy, fx + 0.7, fy + 0.7, rng.choice([hx('#3a3836'), hx('#2c2a28'), hx('#4a3a2e')]))
    c.hline(GYM[0], GDOOR[1], FY, mix(ORANGE_D, ORANGE, .3), 0.8)
    c.rect(CS[0], FY, CS[1], FY + 6, hx('#232838'))
    c.hline(CS[0], CS[1], FY, hx('#4a5266'), 0.8)
    c.rect(COLB[0], FY, IX1, FY + 6, hx('#2c2e30'))
    c.hline(COLB[0], IX1, FY, hx('#55595c'), 0.8)
    for x, col in ((2640, hx('#8a7a3a')), (2700, hx('#3f6a8a')), (2776, hx('#8a3a33')), (2790, hx('#8a3a33')), (2860, hx('#3f6a8a'))):
        c.rect(x, FY - 0.6, x + 8, FY + 1.2, col)          # spike tape marks
    # slab
    c.vgrad(X0, FY + 6, X1, FB, hx('#23272a'), hx('#191b1e'))
    for x in (COLA[0] - 12, COLB[0] - 12):
        c.vgrad(x, FB - 2, x + 62, FB + 14, hx('#1f2225'), hx('#16181a'))
        c.rect(x, FB - 2, x + 62, FB + 14, None, OUT, 1)
    c.vgrad(X0, TS0, X1, TS1, hx('#272b30'), hx('#1b1e22'))
    c.vgrad(X0, TS0, IX0, FB, hx('#262a2e'), hx('#1b1e21'))
    c.vgrad(IX1, TS0, X1, FB, hx('#262a2e'), hx('#1b1e21'))
    for a in ((X0, TS0, X1, TS1), (X0, FY + 6, X1, FB), (X0, TS0, IX0, FB), (IX1, TS0, X1, FB)):
        hatch(*a)
    c.hline(X0, X1, TS0, hx('#4b5258'), 1)
    c.hline(IX0, IX1, TS1, hx('#0d0f11'), 1)
    c.vline(IX0 - 1, TS1, FY, hx('#2c3237'), 1)
    c.vline(IX1, TS1, FY, hx('#0e1012'), 1)
    c.hline(X0, X1, FB - 1, hx('#2b2f33'), 1)


# ------------------------------------------------------------------ ceilings
def ceilings():
    # sprinkler main everywhere
    c.box(IX0, 214, IX1, 217.5, hx('#5a3a36'), outline=OUT, hl=.15)
    # gym: exposed black ceiling, big spiral duct, clerestory, cage pendants
    clerestory(c, 100, 262, 1150, 298, seed=2)
    spiral_duct(c, GYM[0] + 12, GYM[1] - 8, 224, 248)
    c.glow_rect(GYM[0], 236, GYM[1], 262, hx('#9a7a58'), 0.16, blur=18)   # street glow on the ceiling
    for x in (190, 400, 610, 820, 1030):
        cage_pendant(c, x, 300)
    neon_strip(c, 100, 1150, 308)
    # customer service: floating acoustic clouds + downlights
    c.box(CS[0], 228, CS[1], 244, hx('#33393e'), outline=OUT, hl=.12, sh=.35)          # duct
    for x0 in (1240, 1488, 1736, 1984):
        acoustic_cloud(c, x0, x0 + 226, 276)
    for x in (1476, 1724, 1972):
        c.vline(x, 244, 284, hx('#2a2f33'), 0.5)
        c.rect(x - 6, 284, x + 6, 290, hx('#2b2f33')); c.rect(x - 4, 290, x + 4, 291, hx('#5c6066'))
    # studio: black ceiling with lighting pipe grid
    pipe_grid(c, ST[0] + 6, ST[1] - 6, 270)
    for x, aim in ((2420, 1), (2640, 1), (2860, -1), (3040, -1)):
        fresnel(c, x, 275, aim)


# ------------------------------------------------------------------ gym
def gym():
    mirror_wall(c, 100, 318, 760, 556, panel=132, crack_panel=2,
                ghosts=[(200, 190, 130), (410, 190, 130), (608, 140, 204), (740, 60, 70)])
    # wall TV (off) above the lockers, speed chart above the trainer desk
    c.occlude(978, 336, 1078, 392, 90, blur=4); c.apply_shade_now()
    c.rrect(976, 332, 1076, 388, 1.2, hx('#0e1012'), OUT, 1)
    screen_content(c, 978.5, 334.5, 1073.5, 385.5, 'off', seed=4)
    speed_chart(c, 1094, 398, 54, 44)
    door_button(c, 1154, 424)
    # equipment
    treadmill(c, 106, 188, facing=1, marks=True, seed=1)
    treadmill(c, 316, 188, facing=1, marks=True, seed=2, key_dangling=True)
    power_rack(c, 548, 668)
    dumbbell_rack(c, 716, 860)
    kettlebell(c, 886, 0.9); kettlebell(c, 904, 0.75)
    mat_bin(c, 914)
    lockers(c, 962, cols=3, w=40, h=167, open_idx=1)
    trainer_desk(c, 1088, 1168)
    # exercise ball left by the treadmills
    exercise_ball(c, 530 - 12) if False else None


# ------------------------------------------------------------------ glass auto-door section
def auto_door():
    x0, x1 = GDOOR
    c.vgrad(x0, TS1, x1, FY, hx('#16191b'), hx('#1e2225'))
    c.box(x0 - 2, 300, x1 + 2, 330, hx('#3a3e41'), outline=OUT, hl=.15)          # door operator header
    led(c, x1 - 3, 324, RED, 0.6, 0.6)                                             # sensor: locked closed
    tdraw(c, (x0, 330, x1, FY), lambda od, ox, oy: od.rectangle([P(x0) + ox, P(330) + oy, P(x1) + ox, P(FY) + oy], fill=(150, 180, 185, 50)))
    reflection(c, x0, 330, x1, FY, 40, 0.1, 0.6)
    c.vline(x0, 330, FY, hx('#6a7276'), 1); c.vline(x1 - 1, 330, FY, hx('#6a7276'), 1)
    c.box(x0 - 3, FY - 4, x1 + 3, FY, hx('#6a7276'), outline=OUT)
    # exit pictogram on the service-center side
    ex = x1 + 12
    c.box(ex, 300, ex + 44, 316, hx('#1a2a1f'), outline=OUT)
    c.rect(ex + 2, 302, ex + 42, 314, hx('#2f6a45'))
    c.ell(ex + 27, 303.5, ex + 30, 306.5, hx('#cfe8d6'))
    c.line([(ex + 28, 307), (ex + 25, 311), (ex + 21, 313)], hx('#cfe8d6'), 0.9)
    c.line([(ex + 27, 308), (ex + 32, 310)], hx('#cfe8d6'), 0.8)
    c.line([(ex + 25, 311), (ex + 28, 313.5)], hx('#cfe8d6'), 0.8)
    c.line([(ex + 16, 308), (ex + 6, 308), (ex + 10, 305)], hx('#cfe8d6'), 0.8)
    c.glow_rect(ex, 300, ex + 44, 316, hx('#4fb57a'), 0.55, blur=14)


# ------------------------------------------------------------------ customer service center
def customer_service():
    TOP = FY - 69
    script_board(c, 1250, 324, 1432, 438, seed=3)
    # call-queue wall display (off)
    c.occlude(1502, 330, 1704, 392, 90, blur=4); c.apply_shade_now()
    c.rrect(1500, 326, 1702, 388, 1.2, hx('#0e1012'), OUT, 1)
    screen_content(c, 1502.5, 328.5, 1699.5, 385.5, 'off', seed=6)
    # wall clock + unlit brand lightbox (abstract mark only)
    c.ell(1730, 334, 1756, 360, hx('#262b30'), OUT, 0.8)
    c.ell(1732.5, 336.5, 1753.5, 357.5, hx('#7b8285'))
    c.line([(1743, 347), (1749, 347.5)], hx('#1b1e21'), 1.1)     # 03:...
    c.line([(1743, 347), (1743, 339)], hx('#1b1e21'), 0.7)
    c.box(1790, 326, 1990, 352, hx('#2b3038'), outline=OUT, hl=.1)
    c.poly([(1806, 346), (1830, 330), (1850, 346)], hx('#4a5568'))
    c.rect(1860, 336, 1974, 340, hx('#3c4452'))
    # filing cabinets + key cabinet + guard logbook
    lateral_files(c, 2024, 2126)
    lateral_files(c, 2128, 2228)
    key_cabinet(c, 2164, 344)
    c.box(2034, FY - 126, 2084, FY - 122, hx('#3a4248'), outline=OUT)                 # open logbook
    c.poly([(2036, FY - 126), (2058, FY - 128), (2058, FY - 124)], hx('#7f827d'))
    c.poly([(2060, FY - 128), (2082, FY - 126), (2060, FY - 124)], hx('#7f827d'))
    c.box(2092, FY - 128, 2118, FY - 122, hx('#2a2d30'), outline=OUT)                 # flashlight
    c.rect(2116, FY - 129, 2120, FY - 121, hx('#55595c'))
    # support workstations
    rng = random.Random(8)
    for (bx0, bx1, cxs, seed) in ((1244, 1620, (1306, 1432, 1558), 1), (1648, 2010, (1708, 1828, 1948), 2)):
        privacy_screen(c, bx0 + 4, bx1 - 4, TOP, 34)
        desk(c, bx0, bx1, TOP, peds=('L', 'R'), seed=seed, col=hx('#5d636b'))
        for i, cx in enumerate(cxs):
            if i > 0:
                side_screen(c, cx - 63, TOP, 44)
                headset_on_hook(c, cx - 61, TOP - 40)
            if seed == 1 and i == 1:
                laptop(c, cx - 8, TOP, 30, 'off', seed=11)
                survey_screen(c, cx - 8 - 12.6, TOP - 19.2, cx - 8 + 12.6, TOP - 3.2)
                floor_spill(c, cx - 40, cx + 30, BLUE, 0.15)
            else:
                monitor(c, cx - 10, TOP, 52, 31, 'off', seed=seed * 10 + i, notes=rng.choice([0, 1, 3]))
            keyboard(c, cx - 10, TOP, 34)
            desk_phone(c, cx + 40, TOP, msg=(seed == 2 and i == 0))
            y = papers(c, cx - 56, cx - 36, TOP, rng.randint(3, 8), seed=seed * 5 + i)
            if rng.random() < 0.6:
                binders(c, cx - 58, y, 2, seed=i + seed, h=22)
            if rng.random() < 0.5:
                mug(c, cx + 56, TOP, rng.choice([hx('#56606a'), hx('#6f5048')]))
            if i == 2 and seed == 1:
                plant_small(c, cx + 56, TOP)
            if i == 0 and seed == 2:
                c.box(cx + 52, TOP - 7, cx + 62, TOP, hx('#7a7d78'), outline=OUT)   # tissue box
            # chairs
            if seed == 2 and i == 2:
                chair_side(c, cx + 16, facing=1, col=hx('#20242c'))
            elif not (seed == 1 and i == 1):          # the laptop seat is empty
                chair_back(c, cx - 6, col=hx('#20242c'))
        cable_to_floor(c, bx0 + 60, TOP + 4, dx=-8)


# ------------------------------------------------------------------ studio
def studio():
    foam_wall(c, CURT[1], TS1 + 2, 2580, FY - 1)
    foam_wall(c, 2968, TS1 + 2, ST[1], FY - 1)
    # ON AIR box on the column (unlit) + gathered blackout curtain
    c.box(COLB[0] + 4, 318, COLB[1] - 4, 334, hx('#3a1e1c'), outline=OUT, hl=.2)
    c.rect(COLB[0] + 8, 322, COLB[1] - 8, 330, hx('#5a2a26'))
    gathered_curtain(c, CURT[0], CURT[1], 262)
    production_desk(c, 2326, 2470)
    backdrop(c, 2620, 2930, 300)
    bar_stool(c, 2778)
    led_panel(c, 2964, 360)
    softbox(c, 2592, 358, facing=1)
    boom_mic(c, 3000, 2784, 382)
    road_cases(c, 3030, 3106)
    video_camera(c, 2520, facing=1, tally=True)
    # cable runs on the floor
    c.bezier((2470, FY - 1), (2500, FY - 4), (2540, FY - 1), hx('#121416'), 1)
    c.bezier((2550, FY - 1), (2700, FY - 3), (2960, FY - 1), hx('#121416'), 1)


def lights():
    for x in (700, 1600, 2000):
        c.ell(x - 5, TS1 + 4, x + 5, TS1 + 10, hx('#7a8084'), OUT, 0.5)
    for x, y in ((1150, 252), (2210, 252)):
        c.vline(x, TS1, y, hx('#3a4045'), 0.8)
        c.box(x - 9, y, x + 9, y + 3, hx('#4a5258'), outline=OUT)
        c.ell(x - 7, y - 2, x + 7, y + 11, hx('#1c2024'), OUT, 0.8)
        led(c, x + 2, y + 6, RED, 0.6, 0.6)


# ------------------------------------------------------------------ finalize
def finalize():
    arr = np.asarray(c.img, np.float32)
    h, w = arr.shape[:2]
    ys = np.linspace(0, 1, h)[:, None]
    xs = np.linspace(0, 1, w)[None, :]
    yy = (ys * H - TS1) / (FY - TS1)
    v = 1.0 - 0.28 * np.clip(1 - yy * 1.5, 0, 1) ** 1.5
    v *= 1.0 - 0.10 * np.clip((yy - 0.75) * 4, 0, 1)
    edge = np.minimum(xs, 1 - xs) * W
    v = v * (0.74 + 0.26 * np.clip(edge / 420.0, 0, 1))
    arr[:, :, :3] *= v[:, :, None]
    sh = np.asarray(c.shade, np.float32)[:, :, None] / 255.0
    arr[:, :, :3] *= (1 - sh * 0.85)
    L = np.asarray(c.light, np.float32) / 255.0
    base = arr[:, :, :3] / 255.0
    out = 1 - (1 - base) * (1 - L)
    lum = (out * np.array([0.299, 0.587, 0.114])).sum(axis=2, keepdims=True)
    out = out * 0.80 + lum * 0.20
    out = out * np.array([0.99, 1.0, 1.02])
    out = np.clip(out, 0, 1) ** 0.92
    out = np.clip((out - 0.5) * 1.10 + 0.5, 0, 1)
    arr[:, :, :3] = out * 255
    img = Image.fromarray(np.rint(arr).clip(0, 255).astype(np.uint8), 'RGBA').resize((W, H), Image.LANCZOS)
    a = np.asarray(img, np.float32)
    rng = np.random.default_rng(3)
    g = (rng.random((H, W)) - 0.5) * 7
    low = Image.fromarray((rng.random((H // 6, W // 6)) * 255).astype(np.uint8), 'L').resize((W, H), Image.BICUBIC)
    low = (np.asarray(low, np.float32) / 255 - 0.5) * 0.07
    a[:, :, :3] = a[:, :, :3] * (1 + low[:, :, None]) + g[:, :, None]
    alpha = np.where(a[:, :, 3] > 127, 255, 0)
    a[:, :, 3] = alpha
    a[:, :, :3] *= (alpha[:, :, None] > 0)
    img = Image.fromarray(np.rint(a).clip(0, 255).astype(np.uint8), 'RGBA')
    m = img.getchannel('A')
    inner = m.filter(ImageFilter.MinFilter(5))
    img.paste(Image.new('RGBA', img.size, (9, 10, 12, 255)), (0, 0), ImageChops.subtract(m, inner))
    inner2 = m.filter(ImageFilter.MinFilter(9))
    img.paste(Image.new('RGBA', img.size, (78, 88, 98, 255)), (0, 0), ImageChops.subtract(inner, inner2).point(lambda v: 150 if v else 0))
    bb = img.getchannel('A').getbbox()
    M = 48
    img = img.crop((bb[0] - M, bb[1] - M, bb[2] + M, bb[3] + M))
    print('bbox', bb, 'floor line y in output =', FY - (bb[1] - M), 'size', img.size)
    return img


def build():
    shell()
    c.noise_tex(GYM[0], 296, GYM[1], FY, 0.07, 30, seed=1, streaks=True)
    c.noise_tex(CS[0], 292, CS[1], FY, 0.06, 26, seed=2, streaks=True)
    c.noise_tex(X0, TS0, X1, TS1, 0.08, 16, seed=4)
    c.noise_tex(X0, FY, X1, FB, 0.08, 16, seed=5)
    c.noise_tex(IX0, TS1, IX1, 300, 0.08, 20, seed=6)
    for i, (x, y, w_, h_) in enumerate([(820, 470, 140, 90), (1300, 470, 160, 80), (1880, 300, 100, 120), (2200, 470, 120, 80)]):
        c.stain(x, y, w_, h_, hx('#14171a'), alpha=40, blur=10, seed=i + 30)
    ceilings()
    c.occlude(IX0, TS1, IX1, TS1 + 10, 150, blur=10)
    c.occlude(IX0, FY - 6, IX1, FY, 120, blur=6)
    c.occlude(IX0, TS1, IX0 + 10, FY, 140, blur=14)
    c.occlude(IX1 - 10, TS1, IX1, FY, 140, blur=14)
    for (x0, x1) in (COLA, COLB):
        c.occlude(x0 - 14, TS1, x0, FY, 110, blur=10)
        c.occlude(x1, TS1, x1 + 14, FY, 110, blur=10)
    c.apply_shade_now()
    gym()
    auto_door()
    customer_service()
    studio()
    lights()
    return finalize()


if __name__ == '__main__':
    img = build()
    out = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/f3/floor03.png'
    img.save(out)
    print('saved', out)
