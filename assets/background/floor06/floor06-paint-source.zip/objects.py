import random, math
from PIL import Image, ImageDraw
from lib import *

FY = 570  # floor line

# palette
METAL = hx('#5d656c')
METAL_D = hx('#2b3035')
DESK_TOP = hx('#6f767b')
DESK_LEG = hx('#262b30')
PLASTIC = hx('#1b1f23')
PAPER = hx('#8f9290')
SCREEN_OFF0 = hx('#161b20')
SCREEN_OFF1 = hx('#0a0d10')

CYAN = hx('#6fc0cf')
GREEN = hx('#7fbf8a')
AMBER = hx('#d8a45c')
RED = hx('#c4473d')
BLUE = hx('#6f8fc6')


def tdraw(c, bbox, fn):
    """draw translucent shapes in bbox (final coords) blended over the image"""
    x0, y0, x1, y1 = bbox
    box = (max(0, P(x0)), max(0, P(y0)), min(W * S, P(x1)), min(H * S, P(y1)))
    if box[2] <= box[0] or box[3] <= box[1]:
        return
    ov = Image.new('RGBA', (box[2] - box[0], box[3] - box[1]), (0, 0, 0, 0))
    od = ImageDraw.Draw(ov)
    fn(od, -box[0], -box[1])
    reg = c.img.crop(box)
    a = reg.getchannel('A')
    reg = Image.alpha_composite(reg, ov)
    reg.putalpha(a)
    c.img.paste(reg, box)
    c.d = ImageDraw.Draw(c.img)


def tpoly(c, pts, color, alpha):
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    def f(od, ox, oy):
        od.polygon([(P(x) + ox, P(y) + oy) for x, y in pts], fill=wa(color, alpha))
    tdraw(c, (min(xs) - 1, min(ys) - 1, max(xs) + 1, max(ys) + 1), f)


def tline(c, pts, color, alpha, w=1):
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    def f(od, ox, oy):
        od.line([(P(x) + ox, P(y) + oy) for x, y in pts], fill=wa(color, alpha), width=max(1, P(w)))
    tdraw(c, (min(xs) - w - 1, min(ys) - w - 1, max(xs) + w + 1, max(ys) + w + 1), f)


def reflection(c, x0, y0, x1, y1, alpha=22, pos=0.55, width=0.18):
    w = x1 - x0
    a = x0 + w * pos; b = a + w * width
    sk = (y1 - y0) * 0.45
    pts = [(a, y0), (b, y0), (b - sk, y1), (a - sk, y1)]
    # clip roughly inside
    def f(od, ox, oy):
        od.polygon([(P(max(x0, min(x1, x))) + ox, P(y) + oy) for x, y in pts], fill=(170, 190, 210, alpha))
    tdraw(c, (x0, y0, x1, y1), f)


# ---------------------------------------------------------------- screens
def screen_content(c, x0, y0, x1, y1, mode, seed=0, glow=True):
    rng = random.Random(seed)
    if mode == 'off':
        c.vgrad(x0, y0, x1, y1, SCREEN_OFF0, SCREEN_OFF1)
        reflection(c, x0, y0, x1, y1, 16, rng.uniform(0.3, 0.6))
        return
    if mode in ('code', 'term', 'code_dim'):
        bg0, bg1 = (hx('#0f1d22'), hx('#0b1418')) if mode != 'term' else (hx('#0b1712'), hx('#08100c'))
        c.vgrad(x0, y0, x1, y1, bg0, bg1)
        pal = [wa(CYAN, 255), wa(dk(CYAN, .35), 255), wa(hx('#8a9aa0'), 255), wa(dk(AMBER, .2), 255), wa(dk(GREEN, .2), 255)]
        if mode == 'term':
            pal = [wa(GREEN, 255), wa(dk(GREEN, .4), 255), wa(dk(GREEN, .6), 255)]
        if mode == 'code_dim':
            pal = [wa(dk(CYAN, .45), 255), wa(dk(hx('#8a9aa0'), .4), 255), wa(dk(AMBER, .5), 255)]
        # gutter
        if mode != 'term' and x1 - x0 > 30:
            c.rect(x0, y0, x0 + 3, y1, dk(bg0, .3))
        y = y0 + 2
        lh = 2.0 if (y1 - y0) > 26 else 1.6
        while y < y1 - 2:
            indent = rng.choice([0, 0, 2, 4, 6, 8]) if mode != 'term' else 0
            xx = x0 + (5 if mode != 'term' else 2) + indent
            for s in range(rng.randint(1, 4)):
                ln = rng.uniform(2, max(3, (x1 - x0) * 0.32))
                if xx + ln > x1 - 2:
                    break
                c.rect(xx, y, xx + ln, y + 0.8, rng.choice(pal))
                xx += ln + 1.5
            if rng.random() < 0.12:
                y += lh
            y += lh
        if mode == 'term':
            c.rect(x0 + 2, y1 - 4, x0 + 5, y1 - 2.5, wa(GREEN, 255))
        col = CYAN if mode != 'term' else GREEN
        if glow:
            inten = 0.5 if mode != 'code_dim' else 0.16
            c.glow_rect(x0, y0, x1, y1, col, inten, blur=max(6, (x1 - x0) * 0.25))
        return
    if mode == 'graph':
        c.vgrad(x0, y0, x1, y1, hx('#0f1a24'), hx('#0a1117'))
        for gy in range(4):
            yy = y0 + (y1 - y0) * (gy + 1) / 5
            c.hline(x0 + 2, x1 - 2, yy, hx('#1d2b36'), 0.5)
        for k, col in enumerate([CYAN, AMBER, dk(BLUE, .1)]):
            pts = []
            base = y0 + (y1 - y0) * (0.35 + 0.2 * k)
            ph = rng.uniform(0, 6)
            for i in range(30):
                xx = x0 + 2 + (x1 - x0 - 4) * i / 29
                yy = base + math.sin(i * 0.6 + ph) * (y1 - y0) * 0.1 + rng.uniform(-1.5, 1.5)
                if k == 0 and i > 22:
                    yy -= (i - 22) * (y1 - y0) * 0.04   # spike
                pts.append((xx, max(y0 + 2, min(y1 - 2, yy))))
            c.line(pts, wa(col, 255), 0.7)
        if glow:
            c.glow_rect(x0, y0, x1, y1, BLUE, 0.4, blur=max(6, (x1 - x0) * 0.25))
        return
    if mode == 'net':   # network topology nodes
        c.vgrad(x0, y0, x1, y1, hx('#0e1722'), hx('#090f16'))
        nodes = [(rng.uniform(x0 + 4, x1 - 4), rng.uniform(y0 + 4, y1 - 4)) for _ in range(9)]
        hub = ((x0 + x1) / 2, (y0 + y1) / 2)
        for n in nodes:
            c.line([hub, n], wa(dk(CYAN, .45), 255), 0.5)
        for i, n in enumerate(nodes):
            col = RED if i == 3 else (CYAN if i % 3 else AMBER)
            c.ell(n[0] - 1.2, n[1] - 1.2, n[0] + 1.2, n[1] + 1.2, wa(col, 255))
        c.ell(hub[0] - 2, hub[1] - 2, hub[0] + 2, hub[1] + 2, wa(lit(CYAN, .2), 255))
        if glow:
            c.glow_rect(x0, y0, x1, y1, CYAN, 0.35, blur=max(6, (x1 - x0) * 0.25))
        return
    if mode == 'dash':  # test dashboard tiles (mostly failing)
        c.vgrad(x0, y0, x1, y1, hx('#141619'), hx('#0d0f11'))
        cols, rows = 9, 4
        tw = (x1 - x0 - 6) / cols; th = (y1 - y0) * 0.55 / rows
        for r in range(rows):
            for k in range(cols):
                p = rng.random()
                col = RED if p < 0.55 else (AMBER if p < 0.78 else GREEN)
                col = dk(col, 0.36 + rng.random() * 0.14)
                xx = x0 + 3 + k * tw; yy = y0 + 3 + r * th
                c.rect(xx + 0.6, yy + 0.6, xx + tw - 0.6, yy + th - 0.6, wa(col, 255))
        # trend line falling
        gy0 = y0 + (y1 - y0) * 0.62; gy1 = y1 - 3
        c.hline(x0 + 3, x1 - 3, gy1, hx('#2a2e33'), 0.5)
        pts = []
        for i in range(24):
            xx = x0 + 3 + (x1 - x0 - 6) * i / 23
            yy = gy0 + (gy1 - gy0) * (0.15 + 0.75 * (i / 23) ** 1.6) + rng.uniform(-1, 1)
            pts.append((xx, yy))
        c.line(pts, wa(dk(RED, .05), 255), 0.8)
        if glow:
            c.glow_rect(x0, y0, x1, y1, hx('#c0574a'), 0.42, blur=max(8, (x1 - x0) * 0.22))
        return
    if mode == 'runner':  # test runner list with pass/fail bars
        c.vgrad(x0, y0, x1, y1, hx('#11171b'), hx('#0b0f12'))
        y = y0 + 2
        while y < y1 - 2:
            p = rng.random()
            col = RED if p < 0.4 else GREEN
            c.rect(x0 + 2, y, x0 + 4, y + 1, wa(dk(col, .1), 255))
            c.rect(x0 + 6, y, x0 + 6 + rng.uniform(5, (x1 - x0) * 0.6), y + 0.8, wa(hx('#7d8a90'), 255))
            y += 2.4
        if glow:
            c.glow_rect(x0, y0, x1, y1, hx('#8fb0b8'), 0.35, blur=max(6, (x1 - x0) * 0.25))
        return
    if mode == 'blue':
        c.vgrad(x0, y0, x1, y1, hx('#1b3550'), hx('#11243a'))
        c.rect(x0 + 3, y0 + 3, x0 + (x1 - x0) * 0.5, y0 + 4, wa(hx('#9fb6cc'), 255))
        c.rect(x0 + 3, y0 + 6, x0 + (x1 - x0) * 0.7, y0 + 7, wa(hx('#7e98b2'), 255))
        if glow:
            c.glow_rect(x0, y0, x1, y1, BLUE, 0.45, blur=8)
        return


def monitor(c, cx, desk_y, w, h, mode='off', seed=0, stand='base', lift=10, portrait=False, notes=0):
    if portrait:
        w, h = h, w
    x0 = cx - w / 2; x1 = cx + w / 2
    yb = desk_y - lift; y0 = yb - h
    # stand
    if stand == 'base':
        c.box(cx - 2.5, yb - 2, cx + 2.5, desk_y - 1.5, hx('#23282c'), outline=OUT)
        c.box(cx - 9, desk_y - 2, cx + 9, desk_y, hx('#1e2226'), outline=None)
    elif stand == 'arm':
        c.rect(cx - 1.5, yb - 2, cx + 1.5, yb + 4, hx('#2a2f34'))
    # bezel
    c.rrect(x0, y0, x1, yb, 1.2, hx('#121518'), OUT, 1)
    c.hline(x0 + 1, x1 - 1, y0 + 0.5, hx('#2a3036'), 0.5)
    b = 1.6
    screen_content(c, x0 + b, y0 + b, x1 - b, yb - b - 1.2, mode, seed)
    rng = random.Random(seed + 99)
    for i in range(notes):
        nx = x0 + rng.uniform(1, w - 6) if rng.random() < .5 else x1 - 5 - i * 3
        col = rng.choice([hx('#b2a35a'), hx('#a3767c'), hx('#7aa2a6')])
        c.rect(nx, y0 - 1 + rng.uniform(0, 2), nx + 4.5, y0 + 3.5, col)
    return (x0, y0, x1, yb)


def laptop(c, cx, desk_y, w=30, mode='off', seed=0, stand=False):
    base_y = desk_y
    if stand:
        c.poly([(cx - w / 2 + 2, desk_y), (cx + w / 2 - 2, desk_y), (cx + w / 2 - 4, desk_y - 8), (cx - w / 2 + 4, desk_y - 8)], hx('#3d444a'), OUT)
        base_y = desk_y - 8
    sh = w * 0.62
    c.box(cx - w / 2, base_y - 2, cx + w / 2, base_y, hx('#4a5258'), outline=OUT)
    x0 = cx - w / 2 + 1; x1 = cx + w / 2 - 1
    c.rrect(x0, base_y - 2 - sh, x1, base_y - 2, 1, hx('#2b3035'), OUT, 0.8)
    screen_content(c, x0 + 1.4, base_y - 2 - sh + 1.4, x1 - 1.4, base_y - 3.2, mode, seed)


def keyboard(c, cx, desk_y, w=34, lit_keys=None):
    c.box(cx - w / 2, desk_y - 2.2, cx + w / 2, desk_y, hx('#1d2125'), outline=OUT)
    if lit_keys:
        c.hline(cx - w / 2 + 1, cx + w / 2 - 1, desk_y - 1.6, wa(lit_keys, 255), 0.5)
        c.glow_rect(cx - w / 2, desk_y - 3, cx + w / 2, desk_y, lit_keys, 0.35, blur=3)


def mouse(c, x, desk_y):
    c.ell(x - 2.5, desk_y - 2.2, x + 2.5, desk_y + 0.3, hx('#1d2226'), OUT, 0.5)


def mug(c, x, desk_y, col=hx('#56606a')):
    c.box(x - 3, desk_y - 7, x + 3, desk_y, col, outline=OUT)
    c.line([(x + 3, desk_y - 6), (x + 5, desk_y - 5), (x + 5, desk_y - 2.5), (x + 3, desk_y - 2)], OUT, 1)


def can(c, x, desk_y, col=hx('#3e6e64'), lying=False):
    if lying:
        c.box(x - 6, desk_y - 4, x + 6, desk_y, col, outline=OUT)
        c.vline(x - 4, desk_y - 4, desk_y, lit(col, .2), 0.6)
        return
    c.box(x - 2.4, desk_y - 11, x + 2.4, desk_y, col, outline=OUT)
    c.hline(x - 2.4, x + 2.4, desk_y - 9, lit(col, .3), 0.6)
    c.vline(x - 1.6, desk_y - 10, desk_y - 1, lit(col, .35), 0.5)


def papers(c, x0, x1, desk_y, n=6, seed=0, col=PAPER):
    rng = random.Random(seed)
    y = desk_y
    for i in range(n):
        o = rng.uniform(-2, 2)
        th = rng.uniform(0.9, 1.6)
        cc = dk(col, rng.uniform(0, .25))
        c.rect(x0 + o, y - th, x1 + o, y, cc)
        c.hline(x0 + o, x1 + o, y - th, lit(cc, .15), 0.4)
        y -= th
    c.rect(x0 - 2, y, x1 + 2, desk_y, None, OUT, 0.5)
    return y


def binders(c, x, desk_y, n=4, seed=0, h=28, lean_last=False):
    rng = random.Random(seed)
    cols = [hx('#3f5466'), hx('#5e4a44'), hx('#4a5a4c'), hx('#545b62'), hx('#6a5d45'), hx('#3d4248')]
    xx = x
    for i in range(n):
        bw = rng.uniform(5, 8)
        hh = h * rng.uniform(0.85, 1.0)
        col = rng.choice(cols)
        if lean_last and i == n - 1:
            c.poly([(xx, desk_y), (xx + bw, desk_y), (xx + bw + hh * 0.35, desk_y - hh * 0.94), (xx + hh * 0.35, desk_y - hh * 0.94)], col, OUT)
            xx += bw
            continue
        c.box(xx, desk_y - hh, xx + bw, desk_y, col, outline=OUT)
        c.rect(xx + 1.5, desk_y - hh * 0.8, xx + bw - 1.5, desk_y - hh * 0.62, dk(PAPER, .2))
        c.ell(xx + bw / 2 - 1, desk_y - hh * 0.3, xx + bw / 2 + 1, desk_y - hh * 0.3 + 2, dk(col, .5))
        xx += bw
    return xx


def books_lying(c, x0, desk_y, n=3, seed=0):
    rng = random.Random(seed)
    y = desk_y
    for i in range(n):
        w = rng.uniform(22, 30); th = rng.uniform(3, 5)
        o = rng.uniform(-2, 3)
        col = rng.choice([hx('#3e4b57'), hx('#5b4c46'), hx('#4b5446'), hx('#2f3338')])
        c.box(x0 + o, y - th, x0 + o + w, y, col, outline=OUT)
        c.hline(x0 + o + w - 2, x0 + o + w - 0.5, y - th + 0.8, dk(PAPER, .1), th - 1.6)
        y -= th
    return y


def desk_lamp(c, x, desk_y, on=False, facing=1):
    c.box(x - 6, desk_y - 2, x + 6, desk_y, hx('#2b2f33'), outline=OUT)
    j1 = (x + 4 * facing, desk_y - 24)
    head = (x + 14 * facing, desk_y - 30)
    c.line([(x, desk_y - 2), j1], hx('#3a3f44'), 1.4)
    c.line([j1, head], hx('#3a3f44'), 1.4)
    hx0 = head[0] - 5; hx1 = head[0] + 5
    c.poly([(hx0, head[1] - 2), (hx1, head[1] - 2), (hx1 + 2, head[1] + 4), (hx0 - 2, head[1] + 4)], hx('#33383d'), OUT)
    if on:
        c.rect(hx0 - 1, head[1] + 3, hx1 + 1, head[1] + 4.5, hx('#f2cf8c'))
        c.cone(head[0], head[1] + 4, desk_y + 2, 12, 46, AMBER, intensity=0.75, blur=4)
        c.glow_ell(head[0], head[1] + 6, 22, 14, AMBER, 0.55, blur=9)
        c.glow_ell(head[0], desk_y, 40, 8, AMBER, 0.45, blur=8)


def plant_small(c, x, desk_y, withered=False):
    c.box(x - 5, desk_y - 9, x + 5, desk_y, hx('#4c4a46'), outline=OUT)
    rng = random.Random(int(x))
    leaf = hx('#3e5143') if not withered else hx('#5f5a43')
    for i in range(6):
        a = -math.pi / 2 + rng.uniform(-1.1, 1.1)
        L = rng.uniform(8, 14) * (0.7 if withered else 1)
        ex = x + math.cos(a) * L; ey = desk_y - 9 + math.sin(a) * L
        if withered:
            ey += L * 0.6
        c.line([(x, desk_y - 9), (ex, ey)], dk(leaf, .1), 1)
        c.ell(ex - 2.5, ey - 1.5, ex + 2.5, ey + 1.5, leaf)


def sticky(c, x, y, col=None):
    col = col or hx('#b2a35a')
    c.rect(x, y, x + 5, y + 5, col)
    c.hline(x, x + 5, y + 5, dk(col, .4), 0.4)


# ---------------------------------------------------------------- furniture
def desk(c, x0, x1, top_y, peds=('L', 'R'), seed=0, col=DESK_TOP):
    th = 4
    c.occlude(x0 + 4, top_y + th, x1 - 4, FY, 110, blur=6)
    # modesty panel (recessed, dark)
    c.rect(x0 + 6, top_y + th, x1 - 6, top_y + th + 34, hx('#1a1e22'))
    c.hline(x0 + 6, x1 - 6, top_y + th + 34, hx('#25292e'), 1)
    # legs
    for lx in (x0 + 2, x1 - 9):
        c.box(lx, top_y + th, lx + 7, FY, DESK_LEG, outline=OUT, hl=.05)
    # pedestals
    if 'L' in peds:
        pedestal(c, x0 + 12, top_y + th + 1, 44)
    if 'R' in peds:
        pedestal(c, x1 - 56, top_y + th + 1, 44)
    # top
    c.box(x0, top_y, x1, top_y + th, col, hl=0.12, sh=0.4, outline=OUT)
    c.hline(x0 + 1, x1 - 1, top_y + 0.4, lit(col, .25), 0.6)


def pedestal(c, x, y, w):
    h = FY - y
    c.box(x, y, x + w, FY - 2, hx('#4d545a'), outline=OUT, hl=0.06)
    dh = (h - 4) / 3
    for i in range(3):
        yy = y + 1 + i * dh
        c.rect(x + 2, yy + 1, x + w - 2, yy + dh - 1, None, dk(hx('#4d545a'), .35), 0.5)
        c.rect(x + w / 2 - 6, yy + 4, x + w / 2 + 6, yy + 5.2, hx('#2a2f33'))
    c.rect(x + 3, FY - 2, x + 6, FY, OUT); c.rect(x + w - 6, FY - 2, x + w - 3, FY, OUT)


def tower(c, x, h=42, w=19, led=hx('#5f86b8'), mesh=False):
    c.occlude(x - 2, FY - h, x + w + 2, FY, 90, blur=3)
    c.box(x, FY - h, x + w, FY - 1.5, hx('#1e2226'), outline=OUT, hl=.08)
    if mesh:
        for yy in range(int(FY - h + 5), int(FY - 6), 2):
            c.hline(x + 3, x + w - 3, yy, hx('#15181b'), 0.6)
    c.rect(x + 3, FY - h + 3, x + w - 3, FY - h + 5, hx('#2c3136'))
    c.ell(x + w / 2 - 1, FY - h + 8, x + w / 2 + 1, FY - h + 10, wa(led, 255))
    c.glow_ell(x + w / 2, FY - h + 9, 3, 3, led, 0.6, blur=2)
    c.rect(x + 1, FY - 1.5, x + 4, FY, OUT); c.rect(x + w - 4, FY - 1.5, x + w - 1, FY, OUT)


def chair_back(c, cx, seat_y=None, col=hx('#1d2125'), blanket=None, lowered=0, armrests=True):
    """office chair viewed from behind (facing the desk / rear wall)"""
    seat_y = (FY - 42 + lowered) if seat_y is None else seat_y
    c.occlude(cx - 26, FY - 4, cx + 26, FY + 1, 120, blur=3, ellipse=True)
    # base
    for dx in (-22, -11, 0, 11, 22):
        pass
    c.poly([(cx - 24, FY - 7), (cx + 24, FY - 7), (cx + 20, FY - 4), (cx - 20, FY - 4)], hx('#24282c'), OUT)
    for dx in (-22, 0, 22):
        c.ell(cx + dx - 3, FY - 6, cx + dx + 3, FY, hx('#121417'), OUT, 0.5)
    c.box(cx - 2, seat_y + 6, cx + 2, FY - 7, hx('#3a4045'), outline=OUT)
    c.box(cx - 5, seat_y + 4, cx + 5, seat_y + 9, hx('#202428'), outline=OUT)
    # seat edges peeking out
    c.rrect(cx - 25, seat_y - 3, cx + 25, seat_y + 5, 2, dk(col, .1), OUT, 1)
    # armrests
    if armrests:
        for s in (-1, 1):
            ax = cx + s * 25
            c.rect(min(ax, ax - s * 3), seat_y - 18, max(ax, ax - s * 3) + 0.5, seat_y, hx('#24282c'))
            c.rrect(ax - 5 if s < 0 else ax - 2, seat_y - 21, ax + 2 if s < 0 else ax + 5, seat_y - 17, 1, hx('#1a1d20'), OUT, 0.6)
    # backrest
    by0 = seat_y - 46; by1 = seat_y - 4
    c.rrect(cx - 21, by0, cx + 21, by1, 7, col, OUT, 1)
    c.vgrad(cx - 19, by0 + 3, cx + 19, by0 + 14, lit(col, .1), col)
    # mesh/stitching
    for yy in range(int(by0 + 6), int(by1 - 4), 3):
        c.hline(cx - 17, cx + 17, yy, dk(col, .25), 0.4)
    c.box(cx - 3, by1, cx + 3, seat_y, hx('#2c3135'), outline=OUT)
    if blanket:
        bl = blanket   # a work jacket draped over the backrest
        c.poly([(cx - 20, by0 - 1), (cx + 19, by0 - 2), (cx + 22, by0 + 14), (cx + 20, by0 + 30), (cx + 8, by0 + 27),
                (cx - 6, by0 + 31), (cx - 19, by0 + 26), (cx - 22, by0 + 12)], bl, OUT)
        c.poly([(cx + 14, by0 + 4), (cx + 22, by0 + 6), (cx + 24, by0 + 40), (cx + 18, by0 + 42), (cx + 16, by0 + 24)], dk(bl, .12), OUT)  # sleeve
        c.line([(cx - 2, by0), (cx - 1, by0 + 30)], dk(bl, .3), 0.8)
        for k in range(3):
            xx = cx - 14 + k * 9
            c.line([(xx, by0 + 4), (xx + 1, by0 + 24)], dk(bl, .22), 0.6)
        c.rect(cx - 9, by0 - 1, cx + 9, by0 + 2, lit(bl, .12))   # collar


def chair_side(c, cx, facing=1, col=hx('#1d2125'), seat_y=None):
    """office chair seen in profile (rolled away from a desk). facing = direction the seat faces"""
    seat_y = seat_y or FY - 42
    f = facing
    c.occlude(cx - 26, FY - 4, cx + 26, FY + 1, 110, blur=3, ellipse=True)
    # five-star base in profile + casters
    c.poly([(cx - 23, FY - 7), (cx + 23, FY - 7), (cx + 20, FY - 4.5), (cx - 20, FY - 4.5)], hx('#24282c'), OUT)
    for dx in (-21, -7, 7, 21):
        c.ell(cx + dx - 3, FY - 6, cx + dx + 3, FY, hx('#121417'), OUT, 0.5)
    c.box(cx - 2, seat_y + 5, cx + 2, FY - 7, hx('#3a4045'), outline=OUT)
    c.box(cx - 4, seat_y + 3, cx + 4, seat_y + 8, hx('#202428'), outline=OUT)
    # seat cushion
    c.rrect(cx - 21, seat_y - 4, cx + 21, seat_y + 4, 3.5, col, OUT, 1)
    c.hline(cx - 18, cx + 18, seat_y - 3, lit(col, .12), 0.8)
    # back support bracket + backrest at the rear
    rx = cx - f * 21
    c.poly([(cx - f * 8, seat_y + 2), (rx, seat_y + 2), (rx - f * 2, seat_y - 10), (rx + f * 1, seat_y - 10)], hx('#2c3135'), OUT)
    bx0 = rx - f * 9; bx1 = rx + f * 1
    c.rrect(min(bx0, bx1), seat_y - 50, max(bx0, bx1), seat_y - 9, 4, col, OUT, 1)
    c.vline(min(bx0, bx1) + 2, seat_y - 46, seat_y - 13, lit(col, .1), 0.7)
    # armrest
    c.rect(cx - 2, seat_y - 18, cx + 1, seat_y - 3, hx('#24282c'))
    c.rrect(cx - 11, seat_y - 21, cx + 10, seat_y - 17, 1.5, hx('#1a1d20'), OUT, 0.6)


def stool(c, cx):
    c.occlude(cx - 18, FY - 3, cx + 18, FY + 1, 110, blur=3, ellipse=True)
    c.poly([(cx - 18, FY - 6), (cx + 18, FY - 6), (cx + 15, FY - 3), (cx - 15, FY - 3)], hx('#24282c'), OUT)
    for dx in (-16, 0, 16):
        c.ell(cx + dx - 2.5, FY - 5, cx + dx + 2.5, FY, hx('#121417'), OUT, 0.5)
    c.box(cx - 2, FY - 62, cx + 2, FY - 6, hx('#4a5056'), outline=OUT)
    c.rect(cx - 12, FY - 28, cx + 12, FY - 25, hx('#3a4045'))
    c.rrect(cx - 16, FY - 68, cx + 16, FY - 60, 3, hx('#252a2e'), OUT, 1)


def backpack(c, x, col=hx('#2c3633')):
    c.occlude(x - 2, FY - 30, x + 26, FY, 80, blur=3)
    c.rrect(x, FY - 32, x + 24, FY, 6, col, OUT, 1)
    c.rrect(x + 4, FY - 18, x + 20, FY - 3, 3, dk(col, .2), OUT, 0.6)
    c.line([(x + 6, FY - 32), (x + 12, FY - 37), (x + 18, FY - 32)], hx('#1a1e1e'), 1.4)


def cardboard(c, x, y_bottom, w, h, seed=0, open_top=False):
    col = hx('#5e5242')
    c.box(x, y_bottom - h, x + w, y_bottom, col, outline=OUT, hl=0.08, sh=0.25)
    c.hline(x, x + w, y_bottom - h + h * 0.18, dk(col, .2), 0.6)
    c.rect(x + w * 0.42, y_bottom - h, x + w * 0.58, y_bottom - h + h * 0.18, hx('#6c6658'))
    rng = random.Random(seed)
    if rng.random() < 0.7:
        c.rect(x + w * 0.15, y_bottom - h * 0.6, x + w * 0.45, y_bottom - h * 0.42, dk(PAPER, .05))
    if open_top:
        c.poly([(x, y_bottom - h), (x - 6, y_bottom - h - 7), (x + w * 0.3, y_bottom - h - 5), (x + w * 0.35, y_bottom - h)], dk(col, .1), OUT)


def cable_to_floor(c, x, y, sag=6, col=hx('#111316'), dx=8):
    c.bezier((x, y), (x + dx * 0.3, y + (FY - y) * 0.8 + sag), (x + dx, FY - 0.5), col, 1)


def phone(c, x, y_bottom, w=7, h=13, on=False, seed=0):
    c.rrect(x, y_bottom - h, x + w, y_bottom, 1.2, hx('#121518'), OUT, 0.6)
    if on:
        c.rect(x + 1, y_bottom - h + 1.5, x + w - 1, y_bottom - 1.5, hx('#3b5f73'))
        c.rect(x + 1.6, y_bottom - h + 3, x + w - 1.6, y_bottom - h + 4, hx('#9bc3d0'))
        c.glow_rect(x, y_bottom - h, x + w, y_bottom, CYAN, 0.35, blur=4)
    else:
        c.rect(x + 1, y_bottom - h + 1.5, x + w - 1, y_bottom - 1.5, hx('#0d1013'))
        c.vline(x + w * 0.6, y_bottom - h + 2, y_bottom - h + 6, hx('#2a3138'), 0.5)


def led(c, x, y, col, r=0.7, glow=0.5):
    c.ell(x - r, y - r, x + r, y + r, wa(lit(col, .2), 255))
    if glow:
        c.glow_ell(x, y, r * 2.5, r * 2.5, col, glow, blur=r * 2)


# ---------------------------------------------------------------- racks
def rack(c, x, w=58, h=186, kind='patch', seed=0, door_glass=False, door_open=False):
    rng = random.Random(seed)
    top = FY - h
    c.occlude(x - 3, top, x + w + 3, FY, 110, blur=5)
    c.box(x, top, x + w, FY - 3, hx('#15181b'), outline=OUT, hl=0.05)
    c.rect(x, top, x + w, top + 6, hx('#1d2125'))
    c.hline(x, x + w, top + 0.5, hx('#3a4046'), 0.8)
    # vent slots top
    for k in range(6):
        c.rect(x + 8 + k * 7, top + 2, x + 12 + k * 7, top + 4, hx('#0b0d0f'))
    rx0, rx1 = x + 5, x + w - 5
    c.vgrad(rx0, top + 7, rx1, FY - 10, hx('#13171a'), hx('#0b0d0f'))
    for rx in (rx0, rx1 - 2):
        c.rect(rx, top + 7, rx + 2, FY - 10, hx('#2b3136'))
        for yy in range(int(top + 9), int(FY - 12), 4):
            c.rect(rx + 0.5, yy, rx + 1.5, yy + 1, hx('#121518'))
    y = top + 9
    U = 4.0
    layout = []
    if kind == 'patch':
        layout = ['patch', 'mgmt', 'switch', 'patch', 'switch', 'blank', 'patch', 'switch', 'switch', 'blank', 'fiber', 'blank', 'server2', 'server2', 'blank', 'ups4']
    elif kind == 'servers':
        layout = ['switch', 'blank', 'server2', 'server2', 'server1', 'server1', 'server2', 'blank', 'server2', 'server2', 'kvm', 'server2', 'server1', 'blank', 'ups4']
    elif kind == 'dev':
        layout = ['patch', 'switch', 'blank', 'server2', 'empty', 'empty', 'server2', 'shelf', 'empty', 'empty', 'server1', 'blank', 'ups4']
    cable_cols = [hx('#3e6aa0'), hx('#b39a4a'), hx('#7a8a92'), hx('#4f7f6a')]
    extra = []
    for _ in range(30):
        extra.append(rng.choice(['server2', 'server1', 'blank', 'server2', 'empty' if kind == 'dev' else 'server2']))
    layout = layout[:-1] + extra + [layout[-1]]
    for item in layout:
        if item != 'ups4' and y > FY - 10 - U * 4 - 8:
            continue
        if y > FY - 16:
            break
        if item == 'patch':
            hh = U
            c.box(rx0 + 2, y, rx1 - 2, y + hh, hx('#3f464c'), outline=OUT, hl=.1)
            for k in range(14):
                px = rx0 + 5 + k * ((rx1 - rx0 - 10) / 14)
                c.rect(px, y + 1.2, px + 1.6, y + 2.6, hx('#0d0f11'))
                if rng.random() < 0.75:
                    col = rng.choice(cable_cols)
                    c.rect(px, y + 1.6, px + 1.6, y + 3, col)
                    # little cable droops
                    c.bezier((px + 0.8, y + 3), (px + 0.8 + rng.uniform(-1, 1), y + 6), (px + rng.uniform(-3, 3), y + 9), dk(col, .2), 0.6)
            y += hh + 5
        elif item == 'switch':
            hh = U
            c.box(rx0 + 2, y, rx1 - 2, y + hh, hx('#22272b'), outline=OUT, hl=.1)
            for k in range(12):
                px = rx0 + 5 + k * ((rx1 - rx0 - 14) / 12)
                c.rect(px, y + 1.4, px + 1.6, y + 2.8, hx('#0a0c0e'))
                if rng.random() < 0.55:
                    col = GREEN if rng.random() < 0.75 else AMBER
                    led(c, px + 0.8, y + 0.9, col, 0.35, glow=0.35)
            led(c, rx1 - 5, y + 2, GREEN, 0.5, glow=0.5)
            y += hh + 1
        elif item == 'mgmt':
            y += 2
        elif item == 'fiber':
            hh = U * 2
            c.box(rx0 + 2, y, rx1 - 2, y + hh, hx('#2f363b'), outline=OUT)
            for k in range(6):
                px = rx0 + 8 + k * 6
                c.rect(px, y + 2, px + 3, y + 5, hx('#8a7a3e'))
                c.bezier((px + 1.5, y + 5), (px + 3, y + 10), (px + 8, y + 12), hx('#a08a3c'), 0.6)
            y += hh + 1
        elif item in ('server1', 'server2'):
            hh = U * (1 if item == 'server1' else 2)
            c.box(rx0 + 1, y, rx1 - 1, y + hh, hx('#2a3035'), outline=OUT, hl=.1)
            nb = 8 if item == 'server2' else 6
            for k in range(nb):
                bx = rx0 + 4 + k * ((rx1 - rx0 - 18) / nb)
                c.rect(bx, y + 1, bx + 3.2, y + hh - 1, hx('#1a1e22'))
                c.hline(bx, bx + 3.2, y + hh * 0.5, hx('#3a4248'), 0.4)
                if rng.random() < 0.5:
                    led(c, bx + 2.5, y + 1.6, GREEN if rng.random() < .8 else BLUE, 0.3, glow=0.25)
            c.rect(rx1 - 10, y + 1, rx1 - 3, y + hh - 1, hx('#15181b'))
            led(c, rx1 - 6, y + 2, BLUE if rng.random() < .6 else GREEN, 0.45, glow=0.45)
            y += hh + 0.6
        elif item == 'kvm':
            hh = U
            c.box(rx0 + 1, y, rx1 - 1, y + hh, hx('#1f2327'), outline=OUT)
            c.rect(rx0 + 6, y + 1, rx0 + 20, y + 3, hx('#0f1b1f'))
            y += hh + 1
        elif item == 'shelf':
            c.rect(rx0, y + 8, rx1, y + 9.5, hx('#3a4046'))
            # dev board / laptop on shelf
            c.box(rx0 + 6, y + 4, rx0 + 22, y + 8, hx('#2f4a3c'), outline=OUT)
            led(c, rx0 + 9, y + 5, RED, 0.4, glow=0.4)
            c.box(rx0 + 26, y + 5.5, rx1 - 6, y + 8, hx('#3d444a'), outline=OUT)
            y += 11
        elif item == 'blank':
            c.box(rx0 + 1, y, rx1 - 1, y + U, hx('#191c1f'), outline=None)
            y += U + 0.5
        elif item == 'empty':
            y += U + 1
        elif item == 'ups4':
            yy = FY - 10 - U * 4
            c.box(rx0 + 1, yy, rx1 - 1, FY - 11, hx('#262b2f'), outline=OUT)
            c.rect(rx0 + 6, yy + 3, rx0 + 18, yy + 7, hx('#141a14'))
            c.rect(rx0 + 7, yy + 4, rx0 + 13, yy + 6, wa(dk(AMBER, .2), 255))
            c.glow_rect(rx0 + 6, yy + 3, rx0 + 18, yy + 7, AMBER, 0.35, blur=3)
            for k in range(5):
                c.hline(rx0 + 24, rx1 - 4, yy + 3 + k * 2.4, hx('#1a1e21'), 0.6)
            y = FY
    # vertical cable management bundles
    for side, xx in ((0, rx0 + 1), (1, rx1 - 4)):
        col = cable_cols[side]
        for k in range(3):
            c.line([(xx + k * 1.1, top + 8), (xx + k * 1.1 + rng.uniform(-0.6, 0.6), FY - 30)], dk(col, 0.25 + k * .1), 0.7)
    # feet
    c.rect(x + 2, FY - 3, x + 8, FY, OUT); c.rect(x + w - 8, FY - 3, x + w - 2, FY, OUT)
    # glass door
    if door_glass:
        if door_open:
            # door swung open: seen as a narrow skewed panel on the right
            c.poly([(x + w, top + 2), (x + w + 14, top + 8), (x + w + 14, FY - 9), (x + w, FY - 4)], hx('#1a2026'), OUT)
            tpoly(c, [(x + w + 2, top + 8), (x + w + 12, top + 12), (x + w + 12, FY - 12), (x + w + 2, FY - 8)], hx('#6e8796'), 30)
        else:
            c.rect(x + 2, top + 6, x + w - 2, FY - 6, None, hx('#2c3237'), 1.4)
            tdraw(c, (x, top, x + w, FY), lambda od, ox, oy: od.rectangle(
                [P(x + 3) + ox, P(top + 7) + oy, P(x + w - 3) + ox, P(FY - 7) + oy], fill=(60, 80, 96, 48)))
            reflection(c, x + 3, top + 7, x + w - 3, FY - 7, 24, 0.15, 0.25)
            c.rect(x + w - 6, top + 70, x + w - 4, top + 92, hx('#4b5258'))


def floor_spill(c, x0, x1, col, inten=0.35):
    c.glow_rect(x0, FY - 1, x1, FY + 3, col, inten, blur=4)


def recycle_bin(c, x, seed=0):
    rng = random.Random(seed)
    c.occlude(x - 2, FY - 34, x + 26, FY, 80, blur=3)
    c.box(x, FY - 32, x + 24, FY, hx('#3a4a52'), outline=OUT, hl=.08)
    c.rect(x - 1, FY - 33, x + 25, FY - 30, hx('#2b383e'))
    for k in range(6):
        cx_ = x + 3 + rng.uniform(0, 16)
        col = rng.choice([hx('#3e6e64'), hx('#5a5145'), hx('#4a5a6a'), hx('#6a4a45')])
        a = rng.uniform(-0.6, 0.6)
        c.line([(cx_, FY - 31), (cx_ + math.sin(a) * 6, FY - 31 - math.cos(a) * 8)], col, 2.6)
    c.ell(x + 14, FY - 36, x + 22, FY - 30, dk(PAPER, .15), OUT, 0.5)    # crumpled paper


def rolled_mat(c, x, lean=1):
    # rolled sleeping mat leaning on furniture
    col = hx('#3b4a44')
    pts = [(x, FY), (x + 9, FY), (x + 9 + 10 * lean, FY - 66), (x + 10 * lean, FY - 66)]
    c.poly(pts, col, OUT)
    for k in range(4):
        yy = FY - 10 - k * 15
        c.line([(x + (FY - yy) / 66 * 10 * lean, yy), (x + 9 + (FY - yy) / 66 * 10 * lean, yy - 1)], dk(col, .3), 0.6)
    c.ell(x + 10 * lean - 0.5, FY - 69, x + 9.5 + 10 * lean, FY - 63, dk(col, .2), OUT, 0.6)
    c.rect(x + 2 + 7 * lean, FY - 40, x + 8 + 7 * lean, FY - 37, hx('#5a5145'))   # strap
