import math, random
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageChops

S = 2                      # supersampling factor
W, H = 3200, 768           # final canvas
OUT = (12, 14, 16, 255)    # outline colour

def P(v):
    return int(round(v * S))

def hx(c, a=255):
    c = c.lstrip('#')
    return (int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16), a)

def mix(c1, c2, t):
    return tuple(int(round(c1[i] * (1 - t) + c2[i] * t)) for i in range(3)) + ((c1[3] if len(c1) > 3 else 255),)

def lit(c, t):
    return mix(c, (255, 255, 255, 255), t)

def dk(c, t):
    return mix(c, (0, 0, 0, 255), t)

def wa(c, a):
    return tuple(c[:3]) + (a,)


class Canvas:
    def __init__(self):
        self.img = Image.new('RGBA', (W * S, H * S), (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.img)
        self.light = Image.new('RGB', (W * S, H * S), (0, 0, 0))
        self.shade = Image.new('L', (W * S, H * S), 0)   # extra darkness (occlusion)

    # ---------------- primitives ----------------
    def rect(self, x0, y0, x1, y1, fill, outline=None, ow=1):
        if x1 <= x0 or y1 <= y0:
            return
        a0, b0 = P(x0), P(y0)
        a1, b1 = max(a0 + 1, P(x1)), max(b0 + 1, P(y1))
        if fill is not None:
            self.d.rectangle([a0, b0, a1 - 1, b1 - 1], fill=fill)
        if outline is not None:
            w = max(1, P(ow))
            self.d.rectangle([a0, b0, a1 - 1, b1 - 1], outline=outline, width=w)

    def rrect(self, x0, y0, x1, y1, r, fill, outline=None, ow=1):
        x1 = max(x1, x0 + 1.5); y1 = max(y1, y0 + 1.5)
        self.d.rounded_rectangle([P(x0), P(y0), P(x1) - 1, P(y1) - 1], radius=P(r), fill=fill,
                                 outline=outline, width=max(1, P(ow)) if outline else 0)

    def ell(self, x0, y0, x1, y1, fill, outline=None, ow=1):
        x0, x1 = min(x0, x1), max(x0, x1); y0, y1 = min(y0, y1), max(y0, y1)
        x1 = max(x1, x0 + 1); y1 = max(y1, y0 + 1)
        self.d.ellipse([P(x0), P(y0), P(x1) - 1, P(y1) - 1], fill=fill, outline=outline,
                       width=max(1, P(ow)) if outline else 0)

    def poly(self, pts, fill, outline=None):
        self.d.polygon([(P(x), P(y)) for x, y in pts], fill=fill, outline=outline)

    def line(self, pts, fill, w=1):
        self.d.line([(P(x), P(y)) for x, y in pts], fill=fill, width=max(1, P(w)), joint='curve')

    def hline(self, x0, x1, y, fill, w=1):
        self.rect(x0, y, x1, y + w, fill)

    def vline(self, x, y0, y1, fill, w=1):
        self.rect(x, y0, x + w, y1, fill)

    def blend_rect(self, x0, y0, x1, y1, color, alpha):
        """alpha-composite a translucent colour over existing pixels"""
        if x1 <= x0 or y1 <= y0:
            return
        box = (P(x0), P(y0), P(x1), P(y1))
        ov = Image.new('RGBA', (box[2] - box[0], box[3] - box[1]), wa(color, int(alpha)))
        reg = self.img.crop(box)
        a = reg.getchannel('A')
        reg = Image.alpha_composite(reg, ov)
        reg.putalpha(a)
        self.img.paste(reg, box)

    def vgrad(self, x0, y0, x1, y1, c0, c1, alpha=None):
        h = P(y1) - P(y0); w = P(x1) - P(x0)
        if h <= 0 or w <= 0:
            return
        t = np.linspace(0, 1, h)[:, None]
        arr = np.zeros((h, w, 4), np.float32)
        for i in range(4):
            a0 = c0[i] if i < len(c0) else 255
            a1 = c1[i] if i < len(c1) else 255
            arr[:, :, i] = a0 * (1 - t) + a1 * t
        im = Image.fromarray(arr.clip(0, 255).astype(np.uint8), 'RGBA')
        self.img.alpha_composite(im, (P(x0), P(y0)))

    def hgrad(self, x0, y0, x1, y1, c0, c1):
        h = P(y1) - P(y0); w = P(x1) - P(x0)
        if h <= 0 or w <= 0:
            return
        t = np.linspace(0, 1, w)[None, :]
        arr = np.zeros((h, w, 4), np.float32)
        for i in range(4):
            a0 = c0[i] if i < len(c0) else 255
            a1 = c1[i] if i < len(c1) else 255
            arr[:, :, i] = a0 * (1 - t) + a1 * t
        im = Image.fromarray(arr.clip(0, 255).astype(np.uint8), 'RGBA')
        self.img.alpha_composite(im, (P(x0), P(y0)))

    def box(self, x0, y0, x1, y1, c, hl=0.10, sh=0.22, outline=OUT, top=True, ow=1):
        """shaded solid box (front face) with top highlight and outline"""
        if x1 - x0 < 0.5 or y1 - y0 < 0.5:
            return
        self.vgrad(x0, y0, x1, y1, lit(c, hl), dk(c, sh))
        if top and y1 - y0 > 3:
            self.hline(x0, x1, y0, lit(c, hl * 2.2), 1)
        if outline is not None:
            self.rect(x0, y0, x1, y1, None, outline, ow)

    def bezier(self, p0, p1, p2, fill, w=1, n=24):
        pts = []
        for i in range(n + 1):
            t = i / n
            x = (1 - t) ** 2 * p0[0] + 2 * (1 - t) * t * p1[0] + t * t * p2[0]
            y = (1 - t) ** 2 * p0[1] + 2 * (1 - t) * t * p1[1] + t * t * p2[1]
            pts.append((x, y))
        self.line(pts, fill, w)

    def cable(self, a, b, sag, fill, w=1.2):
        mx = (a[0] + b[0]) / 2
        my = max(a[1], b[1]) + sag
        self.bezier(a, (mx, my), b, fill, w)

    # ---------------- light & shadow ----------------
    def _add_blur_light(self, shape_fn, bbox, color, intensity, blur):
        x0, y0, x1, y1 = bbox
        pad = blur * 3
        bx0, by0 = int(P(x0 - pad)), int(P(y0 - pad))
        bx1, by1 = int(P(x1 + pad)), int(P(y1 + pad))
        bx0 = max(0, bx0); by0 = max(0, by0)
        bx1 = min(W * S, bx1); by1 = min(H * S, by1)
        if bx1 <= bx0 or by1 <= by0:
            return
        m = Image.new('L', (bx1 - bx0, by1 - by0), 0)
        md = ImageDraw.Draw(m)
        shape_fn(md, -bx0, -by0)
        if blur > 0:
            m = m.filter(ImageFilter.GaussianBlur(P(blur)))
        arr = np.asarray(m, np.float32)[:, :, None] / 255.0 * intensity
        col = np.array(color[:3], np.float32)[None, None, :]
        add = (arr * col).clip(0, 255).astype(np.uint8)
        reg = self.light.crop((bx0, by0, bx1, by1))
        reg = ImageChops.add(reg, Image.fromarray(add, 'RGB'))
        self.light.paste(reg, (bx0, by0))

    def glow_ell(self, cx, cy, rx, ry, color, intensity=0.6, blur=None):
        blur = blur if blur is not None else max(rx, ry) * 0.5
        def f(md, ox, oy):
            md.ellipse([P(cx - rx) + ox, P(cy - ry) + oy, P(cx + rx) + ox, P(cy + ry) + oy], fill=255)
        self._add_blur_light(f, (cx - rx, cy - ry, cx + rx, cy + ry), color, intensity, blur)

    def glow_rect(self, x0, y0, x1, y1, color, intensity=0.5, blur=6):
        def f(md, ox, oy):
            md.rectangle([P(x0) + ox, P(y0) + oy, P(x1) + ox, P(y1) + oy], fill=255)
        self._add_blur_light(f, (x0, y0, x1, y1), color, intensity, blur)

    def glow_poly(self, pts, color, intensity=0.4, blur=10):
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        def f(md, ox, oy):
            md.polygon([(P(x) + ox, P(y) + oy) for x, y in pts], fill=255)
        self._add_blur_light(f, (min(xs), min(ys), max(xs), max(ys)), color, intensity, blur)

    def cone(self, cx, top, bottom, w_top, w_bot, color, intensity=0.25, blur=14):
        """vertical light cone with fall-off toward the bottom"""
        x0 = cx - w_bot / 2; x1 = cx + w_bot / 2
        bx0, by0 = max(0, P(x0 - blur * 3)), max(0, P(top - blur))
        bx1, by1 = min(W * S, P(x1 + blur * 3)), min(H * S, P(bottom + blur))
        m = Image.new('L', (bx1 - bx0, by1 - by0), 0)
        md = ImageDraw.Draw(m)
        pts = [(cx - w_top / 2, top), (cx + w_top / 2, top), (cx + w_bot / 2, bottom), (cx - w_bot / 2, bottom)]
        md.polygon([(P(x) - bx0, P(y) - by0) for x, y in pts], fill=255)
        m = m.filter(ImageFilter.GaussianBlur(P(blur)))
        arr = np.asarray(m, np.float32) / 255.0
        hh = arr.shape[0]
        fall = np.linspace(1.0, 0.15, hh)[:, None] ** 1.4
        arr = arr * fall * intensity
        col = np.array(color[:3], np.float32)[None, None, :]
        add = (arr[:, :, None] * col).clip(0, 255).astype(np.uint8)
        reg = self.light.crop((bx0, by0, bx1, by1))
        reg = ImageChops.add(reg, Image.fromarray(add, 'RGB'))
        self.light.paste(reg, (bx0, by0))

    def occlude(self, x0, y0, x1, y1, amount=120, blur=8, ellipse=False):
        """soft ambient occlusion (darkening) mask"""
        pad = blur * 3
        bx0, by0 = max(0, P(x0 - pad)), max(0, P(y0 - pad))
        bx1, by1 = min(W * S, P(x1 + pad)), min(H * S, P(y1 + pad))
        m = Image.new('L', (bx1 - bx0, by1 - by0), 0)
        md = ImageDraw.Draw(m)
        box = [P(x0) - bx0, P(y0) - by0, P(x1) - bx0, P(y1) - by0]
        if ellipse:
            md.ellipse(box, fill=amount)
        else:
            md.rectangle(box, fill=amount)
        m = m.filter(ImageFilter.GaussianBlur(P(blur)))
        reg = self.shade.crop((bx0, by0, bx1, by1))
        reg = ImageChops.lighter(reg, m)
        self.shade.paste(reg, (bx0, by0))

    def apply_shade_now(self, region=None):
        """bake the occlusion mask into the image and reset it"""
        arr = np.asarray(self.img, np.float32)
        sh = np.asarray(self.shade, np.float32)[:, :, None] / 255.0
        arr[:, :, :3] *= (1 - sh * 0.85)
        self.img = Image.fromarray(np.rint(arr).clip(0, 255).astype(np.uint8), 'RGBA')
        self.d = ImageDraw.Draw(self.img)
        self.shade = Image.new('L', (W * S, H * S), 0)

    # ---------------- textures ----------------
    def noise_tex(self, x0, y0, x1, y1, strength=0.06, scale=40, seed=0, streaks=False):
        """multiplicative low-frequency mottling + fine grain on an area"""
        rng = np.random.default_rng(seed)
        w, h = P(x1) - P(x0), P(y1) - P(y0)
        if w <= 0 or h <= 0:
            return
        sw, sh_ = max(2, int(w / P(scale)) + 2), max(2, int(h / P(scale)) + 2)
        low = Image.fromarray((rng.random((sh_, sw)) * 255).astype(np.uint8), 'L').resize((w, h), Image.BICUBIC)
        low = np.asarray(low, np.float32) / 255.0 - 0.5
        fine = rng.random((h, w)).astype(np.float32) - 0.5
        n = low * strength * 2 + fine * strength * 0.6
        if streaks:
            cols = Image.fromarray((rng.random((2, max(2, w // P(3)))) * 255).astype(np.uint8), 'L').resize((w, h), Image.BICUBIC)
            cols = np.asarray(cols, np.float32) / 255.0 - 0.5
            vfade = np.linspace(0.2, 1.0, h)[:, None]
            n += cols * strength * 0.9 * vfade
        box = (P(x0), P(y0), P(x1), P(y1))
        reg = np.asarray(self.img.crop(box), np.float32)
        reg[:, :, :3] *= (1 + n[:, :, None])
        self.img.paste(Image.fromarray(np.rint(reg).clip(0, 255).astype(np.uint8), 'RGBA'), box)
        self.d = ImageDraw.Draw(self.img)

    def stain(self, x, y, w, h, color, alpha=40, blur=6, seed=1):
        rng = random.Random(seed)
        bx0, by0 = P(x - blur * 3), P(y - blur * 3)
        bw, bh = P(w + blur * 6), P(h + blur * 6)
        m = Image.new('L', (bw, bh), 0)
        md = ImageDraw.Draw(m)
        for _ in range(7):
            cx = rng.uniform(blur * 3, blur * 3 + w); cy = rng.uniform(blur * 3, blur * 3 + h * 0.4)
            rx = rng.uniform(w * 0.15, w * 0.45); ry = rng.uniform(h * 0.2, h * 0.6)
            md.ellipse([P(cx - rx), P(cy - ry * 0.3), P(cx + rx), P(cy + ry)], fill=alpha)
        m = m.filter(ImageFilter.GaussianBlur(P(blur)))
        ov = Image.new('RGBA', (bw, bh), wa(color, 255))
        ov.putalpha(m)
        reg = self.img.crop((bx0, by0, bx0 + bw, by0 + bh))
        a = reg.getchannel('A')
        reg = Image.alpha_composite(reg, ov)
        reg.putalpha(a)
        self.img.paste(reg, (bx0, by0))
        self.d = ImageDraw.Draw(self.img)


def paint_glow(c, clip, shape, color, intensity=0.5, blur=10):
    """screen-blend a blurred glow straight into the image, clipped to clip=(x0,y0,x1,y1).
    shape = ('ell', cx, cy, rx, ry) or ('rect', x0, y0, x1, y1). Used for light that sits BEHIND later objects."""
    if shape[0] == 'ell':
        _, cx, cy, rx, ry = shape
        sb = (cx - rx, cy - ry, cx + rx, cy + ry)
    else:
        sb = shape[1:]
    pad_f = blur * 3
    x0 = max(clip[0], sb[0] - pad_f); y0 = max(clip[1], sb[1] - pad_f)
    x1 = min(clip[2], sb[2] + pad_f); y1 = min(clip[3], sb[3] + pad_f)
    box = (max(0, P(x0)), max(0, P(y0)), min(W * S, P(x1)), min(H * S, P(y1)))
    if box[2] <= box[0] or box[3] <= box[1]:
        return
    pad = int(P(blur) * 3)
    bw, bh = box[2] - box[0] + 2 * pad, box[3] - box[1] + 2 * pad
    m = Image.new('L', (bw, bh), 0)
    md = ImageDraw.Draw(m)
    ox, oy = -box[0] + pad, -box[1] + pad
    if shape[0] == 'ell':
        md.ellipse([P(cx - rx) + ox, P(cy - ry) + oy, P(cx + rx) + ox, P(cy + ry) + oy], fill=255)
    else:
        a0, b0, a1, b1 = sb
        md.rectangle([P(a0) + ox, P(b0) + oy, P(a1) + ox, P(b1) + oy], fill=255)
    m = m.filter(ImageFilter.GaussianBlur(P(blur))).crop((pad, pad, pad + box[2] - box[0], pad + box[3] - box[1]))
    k = np.asarray(m, np.float32)[:, :, None] / 255.0 * intensity
    reg = np.asarray(c.img.crop(box), np.float32)
    col = np.array(color[:3], np.float32)[None, None, :] / 255.0
    base = reg[:, :, :3] / 255.0
    reg[:, :, :3] = (1 - (1 - base) * (1 - k * col)) * 255
    c.img.paste(Image.fromarray(np.rint(reg).clip(0, 255).astype(np.uint8), 'RGBA'), box)
    c.d = ImageDraw.Draw(c.img)
