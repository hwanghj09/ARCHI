import random, math, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageChops
from lib import *
from objects import *
from objects5 import partition, conf_phone
from objects6 import *

X0, X1 = 48, 3152
IX0, IX1 = 78, 3122
TS0, TS1 = 180, 212
FB = 626
CL = 304
A = (IX0, 1340); COL = (1340, 1378)
B = (1378, 2336); PT = (2336, 2360)
C = (2360, IX1)

WALL = hx('#45432f')
WALL_C = hx('#3d3d32')

c = Canvas()
exec(open('reuse.py').read().split('\n', 4)[4], globals())    # city() bound to this canvas


def hatch(x0, y0, x1, y1, col=hx('#3a3f44'), step=9):
    def f(od, ox, oy):
        for k in range(int(-(y1 - y0)), int(x1 - x0), step):
            od.line([(P(x0 + k) + ox, P(y1) + oy), (P(x0 + k + (y1 - y0)) + ox, P(y0) + oy)], fill=wa(col, 70), width=P(0.8))
    tdraw(c, (x0, y0, x1, y1), f)


# ------------------------------------------------------------------ shell
def shell():
    c.vgrad(IX0, TS1, IX1, CL, hx('#111209'), hx('#18190f'))
    c.vgrad(A[0], CL, B[1], FY, dk(WALL, .25), WALL)
    c.vgrad(C[0], CL, C[1], FY, dk(WALL_C, .25), WALL_C)
    for x in np.arange(A[0] + 160, B[1], 190):
        c.vline(x, CL, FY, dk(WALL, .2), 0.8)
        c.vline(x + 0.8, CL, FY, lit(WALL, .05), 0.5)
    for a0, a1, wc in ((A[0], B[1], WALL), (C[0], C[1], WALL_C)):
        c.vgrad(a0, 482, a1, FY, dk(wc, .32), dk(wc, .45))
        c.box(a0, 478, a1, 482, MUSTARD, outline=None, hl=.2)
        c.hline(a0, a1, 482, OUT, 0.6)
        c.box(a0, FY - 9, a1, FY, dk(wc, .6), outline=None)
        c.hline(a0, a1, FY - 9, dk(wc, .3), 0.6)
    # column with mustard band
    cc = hx('#4c4a3a')
    c.box(COL[0], TS1, COL[1], FY, cc, outline=OUT, hl=.06, sh=.35)
    c.vline(COL[0] + 3, TS1, FY, lit(cc, .15), 0.8)
    c.box(COL[0], 470, COL[1], 486, MUSTARD, outline=OUT, hl=.25)
    c.box(COL[0] - 2, FY - 12, COL[1] + 2, FY, dk(cc, .45), outline=OUT)
    # olive carpet tiles (section band), checker
    c.rect(IX0, FY, IX1, FY + 7, hx('#1b1d14'))
    for k, x in enumerate(np.arange(IX0, IX1, 40)):
        c.rect(x, FY, min(x + 40, IX1), FY + 6, hx('#232519') if k % 2 else hx('#1e2015'))
    c.hline(IX0, IX1, FY, hx('#6e6a3a'), 0.8)
    # slab
    c.vgrad(X0, FY + 7, X1, FB, hx('#23251f'), hx('#191a16'))
    for x in (COL[0] - 10, PT[0] - 18):
        c.vgrad(x, FB - 2, x + 60, FB + 14, hx('#1f201b'), hx('#161712'))
        c.rect(x, FB - 2, x + 60, FB + 14, None, OUT, 1)
    c.vgrad(X0, TS0, X1, TS1, hx('#2a2b25'), hx('#1d1e19'))
    c.vgrad(X0, TS0, IX0, FB, hx('#292a24'), hx('#1d1e19'))
    c.vgrad(IX1, TS0, X1, FB, hx('#292a24'), hx('#1d1e19'))
    for a in ((X0, TS0, X1, TS1), (X0, FY + 7, X1, FB), (X0, TS0, IX0, FB), (IX1, TS0, X1, FB)):
        hatch(*a, col=hx('#43443a'))
    c.hline(X0, X1, TS0, hx('#4e5048'), 1)
    c.hline(IX0, IX1, TS1, hx('#0d0e0b'), 1)
    c.vline(IX0 - 1, TS1, FY, hx('#2e3029'), 1)
    c.vline(IX1, TS1, FY, hx('#0e0f0c'), 1)
    c.hline(X0, X1, FB - 1, hx('#2d2e28'), 1)


# ------------------------------------------------------------------ plenum
def plenum():
    for x in range(int(IX0) + 50, int(IX1), 170):
        c.vline(x, TS1, 222, hx('#2a2b25'), 0.8)
    c.box(IX0, 220, IX1, 240, hx('#36382f'), outline=OUT, hl=.12, sh=.35)
    for x in range(int(IX0) + 80, int(IX1), 120):
        c.box(x, 219, x + 3, 241, hx('#43453a'), outline=None, hl=.1)
    c.box(IX0, 246, IX1, 249.5, hx('#5a3a36'), outline=OUT, hl=.15)
    for x in range(int(IX0) + 110, int(IX1), 240):
        c.rect(x - 0.8, 249.5, x + 0.8, CL + 3, hx('#5a3a36'))
        c.rect(x - 3, CL + 3, x + 3, CL + 4.5, hx('#8b8f91'))
    # heavy cable tray over the whole technical floor
    c.rect(IX0 + 10, 258, IX1 - 10, 260, hx('#55574b'))
    c.rect(IX0 + 10, 268, IX1 - 10, 269.5, hx('#3e4036'))
    for x in np.arange(IX0 + 10, IX1 - 10, 14):
        c.vline(x, 258, 269.5, hx('#46483e'), 0.6)
    rng = random.Random(6)
    for k in range(40):
        xx = rng.uniform(IX0 + 20, IX1 - 100)
        col = rng.choice([hx('#15160f'), hx('#15160f'), hx('#3e6aa0'), hx('#7a8a92'), hx('#4f7f6a')])
        c.cable((xx, 266), (xx + rng.uniform(40, 110), 266), rng.uniform(2, 12), dk(col, .3), rng.choice([0.8, 1.1, 1.4]))
    for x in np.arange(IX0 + 40, IX1, 300):
        c.vline(x, TS1, 258, hx('#2a2b25'), 0.6)
    for x in range(int(IX0) + 30, int(IX1), 112):
        c.vline(x, 270, CL - 5, hx('#2a2b25'), 0.4)


def ceiling_and_lights():
    ceiling_band(c, IX0, COL[0], CL)
    ceiling_band(c, COL[1], PT[0], CL)
    ceiling_band(c, PT[1], IX1, CL)
    for x in (380, 960, 1650, 2250, 2870):
        slot_diffuser(c, x, CL)
    for x, st in ((150, 'off'), (450, 'on'), (750, 'off'), (1060, 'off'),
                  (1480, 'off'), (1840, 'on'), (2130, 'off'),
                  (2500, 'off'), (2740, 'flicker'), (2960, 'off')):
        troffer(c, x, CL, st)
    for x, y in ((1320, CL), (2380, CL)):
        c.box(x - 9, y, x + 9, y + 3, hx('#4a4c44'), outline=OUT)
        c.ell(x - 7, y - 2, x + 7, y + 11, hx('#1c1d18'), OUT, 0.8)
        led(c, x + 2, y + 6, RED, 0.6, 0.6)


# ------------------------------------------------------------------ A: technical development workspace
def workspace():
    TOP = FY - 69
    fin_window(c, 104, 330, 1316, 470, seed=61, city_fn=city)
    rng = random.Random(11)
    units = [(100, 500, 1, (1,)), (524, 924, 2, (0, 3)), (948, 1320, 3, (2,))]
    for x0, x1, seed, opened in units:
        cxs = hutch_desk(c, x0, x1, TOP, seed=seed, open_doors=opened)
        for i, cx in enumerate(cxs):
            big = (seed + i) % 2 == 0
            if big:
                monitor(c, cx - 22, TOP, 66, 38, 'off', seed=seed * 10 + i, notes=rng.choice([0, 2]))
                monitor(c, cx + 40, TOP, 44, 26, 'off', seed=seed * 10 + i + 5, stand='arm', lift=22, portrait=True)
            else:
                monitor(c, cx - 26, TOP, 50, 30, 'off', seed=seed * 10 + i, notes=rng.choice([0, 1, 3]))
                monitor(c, cx + 26, TOP, 50, 30, 'off', seed=seed * 10 + i + 5)
            keyboard(c, cx, TOP, 36); mouse(c, cx + 26, TOP)
            if rng.random() < 0.7:
                papers(c, cx - 66, cx - 44, TOP, rng.randint(5, 18), seed=seed * 7 + i)
            if rng.random() < 0.6:
                mug(c, cx + 56, TOP, rng.choice([hx('#56606a'), hx('#6f5048'), hx('#5e5a54')]))
            cable_to_floor(c, cx - 30, TOP + 4, dx=rng.uniform(-12, 12))
        tower(c, x0 + 66, 44, 20, led=hx('#3a4a3a'), mesh=True)
        tower(c, x1 - 86, 44, 20, led=hx('#3a4a3a'))
    # the engineer's desk: monitor plastered with sticky notes
    for k in range(9):
        sticky(c, 600 + (k % 5) * 6, 466 + (k // 5) * 6, [hx('#a69a58'), hx('#9b7177'), hx('#a69a58')][k % 3])
    # one laptop left running on battery
    laptop(c, 1210, TOP, 30, 'code_dim', seed=12)
    floor_spill(c, 1180, 1240, CYAN, 0.16)
    # chairs
    for x, kw in ((200, {}), (388, {'blanket': hx('#3a3a30')}), (630, {}), (1050, {}), (1240, {})):
        chair_back(c, x, **kw)
    chair_side(c, 830, facing=-1)
    # a monitor box tower and a cot-like folded camping mat under the last desk
    cardboard(c, 1290, FY, 34, 40, seed=4)
    c.rrect(960, FY - 12, 1040, FY - 2, 4, hx('#3b4a44'), OUT, 0.8)


# ------------------------------------------------------------------ B: shared engineering area
def engineering():
    TOP = FY - 69
    mobile_shelving(c, 1392, n=4, w=52, h=185)
    drawings_board(c, 1612, 322, 1900, 410, seed=5)
    rules_board(c, 1920, 330, 70, 86)
    plotter(c, 1616)
    # engineering bench
    desk(c, 1770, 2110, TOP, peds=('R',), seed=8, col=hx('#686b60'))
    c.box(1778, FY - 34, 1980, FY - 30, hx('#3a3c34'), outline=OUT)       # lower shelf
    for k in range(4):
        c.box(1786 + k * 46, FY - 52, 1826 + k * 46, FY - 34, rng_box(k), outline=OUT)
    monitor(c, 1830, TOP, 74, 42, 'off', seed=81, notes=1)
    monitor(c, 1906, TOP, 50, 30, 'off', seed=82, stand='arm', lift=16)
    c.box(1880, TOP - 9, 1932, TOP, hx('#22272b'), outline=OUT, hl=.1)     # switch on the bench
    for j in range(8):
        led(c, 1886 + j * 5.5, TOP - 7, GREEN if j % 3 else AMBER, 0.35, 0.35)
    for j in range(6):
        c.bezier((1886 + j * 7, TOP - 4), (1880 + j * 8, TOP + 10), (1866 + j * 3, TOP - 1), hx('#3e6aa0') if j % 2 else hx('#7a8a92'), 0.6)
    keyboard(c, 1830, TOP, 36)
    form_stack(c, 1784, 1814, TOP, n=20)
    token_tray(c, 1950, TOP)
    oncall_phone(c, 2070, TOP)
    papers(c, 2030, 2054, TOP, 9, seed=83)
    chair_back(c, 1846)
    chair_back(c, 2020, lowered=3)
    # wall network cabinet, DR circuit box, the new fibre through the floor, usage log, room sign
    wall_net_cabinet(c, 2128, 340)
    fiber_box(c, 2208, 380, 2296)
    floor_sleeve(c, 2296, FY + 7, FB)
    usage_log(c, 2262, 322)
    sign_plate(c, 2272, 396, 56, 14)
    # cable reel + boxes
    c.ell(2120, FY - 28, 2148, FY, hx('#5a4a3a'), OUT, 0.8)
    c.ell(2128, FY - 20, 2140, FY - 8, hx('#1a1b16'), OUT, 0.6)
    cardboard(c, 2160, FY, 40, 22, seed=9, open_top=True)


def rng_box(k):
    return [hx('#3e5a6e'), hx('#5e4e3c'), hx('#4a4f53'), hx('#5a3c38')][k % 4]


# ------------------------------------------------------------------ C: technical meeting room
def meeting():
    TOP = FY - 69
    dr_whiteboard(c, 2384, 318, 2822, 458)
    vc_display(c, 2852, 336, 176, 98)
    # steel credenza at the end with binders
    c.occlude(3040, FY - 74, 3114, FY, 100, blur=4); c.apply_shade_now()
    c.box(3040, FY - 72, 3112, FY - 2, hx('#4a4c42'), outline=OUT, hl=.08)
    c.rect(3044, FY - 66, 3108, FY - 8, None, dk(hx('#4a4c42'), .3), 0.6)
    binders(c, 3046, FY - 72, 7, seed=91, h=28, lean_last=True)
    # long meeting table (light laminate on steel legs)
    desk(c, 2414, 2996, TOP, peds=(), seed=9, col=hx('#74776b'))
    c.box(2700, TOP + 4, 2710, FY, DESK_LEG, outline=OUT)
    c.box(2560, TOP + 4, 2850, TOP + 12, hx('#22241e'), outline=OUT)        # cable trough
    rng = random.Random(21)
    for x, n in ((2470, 8), (2560, 14), (2660, 5), (2780, 11), (2900, 7)):
        y = papers(c, x - 16, x + 16, TOP, n, seed=x)
        if n > 10:
            c.ell(x - 10, y - 0.6, x + 10, y + 0.8, None, hx('#7b3a33'), 0.5)
    laptop(c, 2620, TOP, 30, 'off', seed=22)
    laptop(c, 2840, TOP, 30, 'code_dim', seed=23)
    conf_phone(c, 2720, TOP)
    for x in (2510, 2760, 2950):
        mug(c, x, TOP, rng.choice([hx('#56606a'), hx('#6f5048')]))
    for x in (2470, 2580, 2800, 2910):
        chair_back(c, x, col=hx('#23251e'))
    chair_side(c, 2690, facing=1, col=hx('#23251e'))


def partition_and_sign():
    partition(c, PT[0], PT[1], TS1, door_h=210, style='solid', door_side='R')


# ------------------------------------------------------------------ finalize
def finalize():
    arr = np.asarray(c.img, np.float32)
    h, w = arr.shape[:2]
    ys = np.linspace(0, 1, h)[:, None]
    xs = np.linspace(0, 1, w)[None, :]
    yy = (ys * H - TS1) / (FY - TS1)
    v = 1.0 - 0.28 * np.clip(1 - yy * 1.5, 0, 1) ** 1.5
    v *= 1.0 - 0.10 * np.clip((yy - 0.75) * 4, 0, 1)
    edge = np.minimum(xs, 1 - xs) * W
    v = v * (0.74 + 0.26 * np.clip(edge / 420.0, 0, 1))
    arr[:, :, :3] *= v[:, :, None]
    sh = np.asarray(c.shade, np.float32)[:, :, None] / 255.0
    arr[:, :, :3] *= (1 - sh * 0.85)
    L = np.asarray(c.light, np.float32) / 255.0
    base = arr[:, :, :3] / 255.0
    out = 1 - (1 - base) * (1 - L)
    lum = (out * np.array([0.299, 0.587, 0.114])).sum(axis=2, keepdims=True)
    out = out * 0.80 + lum * 0.20
    out = out * np.array([0.98, 1.0, 1.0])
    out = np.clip(out, 0, 1) ** 0.92
    out = np.clip((out - 0.5) * 1.10 + 0.5, 0, 1)
    arr[:, :, :3] = out * 255
    img = Image.fromarray(np.rint(arr).clip(0, 255).astype(np.uint8), 'RGBA').resize((W, H), Image.LANCZOS)
    a = np.asarray(img, np.float32)
    rng = np.random.default_rng(6)
    g = (rng.random((H, W)) - 0.5) * 7
    low = Image.fromarray((rng.random((H // 6, W // 6)) * 255).astype(np.uint8), 'L').resize((W, H), Image.BICUBIC)
    low = (np.asarray(low, np.float32) / 255 - 0.5) * 0.07
    a[:, :, :3] = a[:, :, :3] * (1 + low[:, :, None]) + g[:, :, None]
    alpha = np.where(a[:, :, 3] > 127, 255, 0)
    a[:, :, 3] = alpha
    a[:, :, :3] *= (alpha[:, :, None] > 0)
    img = Image.fromarray(np.rint(a).clip(0, 255).astype(np.uint8), 'RGBA')
    m = img.getchannel('A')
    inner = m.filter(ImageFilter.MinFilter(5))
    img.paste(Image.new('RGBA', img.size, (9, 10, 8, 255)), (0, 0), ImageChops.subtract(m, inner))
    inner2 = m.filter(ImageFilter.MinFilter(9))
    img.paste(Image.new('RGBA', img.size, (86, 88, 76, 255)), (0, 0), ImageChops.subtract(inner, inner2).point(lambda v: 150 if v else 0))
    bb = img.getchannel('A').getbbox()
    M = 48
    img = img.crop((bb[0] - M, bb[1] - M, bb[2] + M, bb[3] + M))
    print('bbox', bb, 'floor line y in output =', FY - (bb[1] - M), 'size', img.size)
    return img


def build():
    shell()
    c.noise_tex(A[0], CL, B[1], FY, 0.07, 30, seed=1, streaks=True)
    c.noise_tex(C[0], CL, C[1], FY, 0.06, 26, seed=2, streaks=True)
    c.noise_tex(X0, TS0, X1, TS1, 0.08, 16, seed=4)
    c.noise_tex(X0, FY, X1, FB, 0.08, 16, seed=5)
    c.noise_tex(IX0, TS1, IX1, CL, 0.08, 20, seed=6)
    for i, (x, y, w_, h_) in enumerate([(260, 480, 140, 80), (1450, 320, 100, 140), (2000, 480, 140, 80), (2860, 470, 120, 80)]):
        c.stain(x, y, w_, h_, hx('#14150f'), alpha=40, blur=10, seed=i + 60)
    c.stain(2130, CL, 90, 150, hx('#101109'), alpha=50, blur=9, seed=77)     # leak stain near the risers
    plenum()
    c.occlude(IX0, CL, IX1, CL + 10, 150, blur=10)
    c.occlude(IX0, FY - 6, IX1, FY, 120, blur=6)
    c.occlude(IX0, TS1, IX0 + 10, FY, 140, blur=14)
    c.occlude(IX1 - 10, TS1, IX1, FY, 140, blur=14)
    for (x0, x1) in (COL, PT):
        c.occlude(x0 - 14, TS1, x0, FY, 110, blur=10)
        c.occlude(x1, TS1, x1 + 14, FY, 110, blur=10)
    c.apply_shade_now()
    workspace()
    engineering()
    meeting()
    partition_and_sign()
    ceiling_and_lights()
    return finalize()


if __name__ == '__main__':
    img = build()
    out = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/f6/floor06.png'
    img.save(out)
    print('saved', out)
