import random, math
import numpy as np
from PIL import Image, ImageDraw
from lib import *
from objects import *

OLIVE = hx('#2a2c1f')
KHAKI = hx('#4a4836')
MUSTARD = hx('#8a8240')
MUSTARD_L = hx('#b8ae5a')
FLUO = hx('#cfe4dc')


# ------------------------------------------------------------ ceiling & light
def troffer(c, x, cl, state='off', w=110):
    """recessed 2x4 fluorescent troffer cut in the ceiling line"""
    c.box(x, cl - 16, x + w, cl - 4, hx('#30332c'), outline=OUT)            # housing in plenum
    c.rect(x + w - 26, cl - 24, x + w - 6, cl - 16, hx('#3a3d34'))           # emergency battery pack
    if state == 'off':
        c.rect(x + 2, cl - 4, x + w - 2, cl, hx('#5a5e56'))
        for k in range(8):
            c.vline(x + 6 + k * (w - 10) / 8, cl - 4, cl, hx('#474b44'), 0.5)
        return
    if state == 'on':
        c.rect(x + 2, cl - 4, x + w - 2, cl, FLUO)
        c.glow_rect(x, cl - 3, x + w, cl + 3, hx('#bfe0d6'), 0.85, blur=6)
        c.cone(x + w / 2, cl, FY, w, w * 2.2, hx('#a8c8c0'), 0.42, blur=20)
        c.glow_rect(x - 50, cl, x + w + 50, cl + 70, hx('#9fc0b8'), 0.16, blur=30)
        c.glow_rect(x - 20, FY - 72, x + w + 20, FY - 66, hx('#cfe4dc'), 0.18, blur=6)   # cold sheen on desk tops
        c.glow_rect(x - 40, FY - 1, x + w + 40, FY + 3, hx('#cfe4dc'), 0.22, blur=6)
        led(c, x + w - 12, cl - 20, GREEN, 0.5, 0.4)
    elif state == 'flicker':
        lit_w = w * 0.45
        c.rect(x + 2, cl - 4, x + 2 + lit_w, cl, FLUO)
        c.rect(x + 2 + lit_w, cl - 4, x + w - 2, cl, hx('#4a4e48'))
        c.rect(x + 2, cl - 4, x + 9, cl, hx('#6a5f4c'))
        c.glow_rect(x + 8, cl - 3, x + 2 + lit_w, cl + 3, hx('#bfe0d6'), 0.6, blur=5)
        c.cone(x + 2 + lit_w / 2, cl, FY, lit_w, lit_w * 2.4, hx('#a8c8c0'), 0.24, blur=22)
        led(c, x + w - 12, cl - 20, AMBER, 0.5, 0.4)


def ceiling_band(c, x0, x1, cl, step=60):
    """mineral-board suspended ceiling seen in section: tile band + T-bars + slot diffusers"""
    c.box(x0, cl - 4, x1, cl, hx('#4e5148'), outline=None, hl=.06)
    for tx in np.arange(x0, x1 + 1, step):
        c.rect(tx - 1, cl - 5, tx + 1, cl + 0.8, hx('#6a6d63'))
    c.hline(x0, x1, cl, OUT, 0.6)


def slot_diffuser(c, x, cl):
    c.box(x - 30, cl - 2, x + 30, cl + 1, hx('#3a3d34'), outline=OUT)
    for k in range(4):
        c.rect(x - 26 + k * 14, cl - 1, x - 16 + k * 14, cl + 0.5, hx('#141510'))


# ------------------------------------------------------------ window
def fin_window(c, x0, y0, x1, y1, seed=0, city_fn=None):
    """band window: privacy film on the lower part, external horizontal sunshade fins"""
    city_fn(x0, y0, x1, y1, seed=seed)
    tdraw(c, (x0, y0, x1, y1), lambda od, ox, oy: od.rectangle([P(x0) + ox, P(y0) + oy, P(x1) + ox, P(y1) + oy], fill=(40, 50, 44, 40)))
    # exterior fins (seen through the glass): thick horizontal aluminium blades
    for yy in np.arange(y0 + 10, y1 - 4, 17):
        c.box(x0, yy, x1, yy + 4, hx('#1a1c18'), outline=None, hl=.0, sh=.2)
        c.hline(x0, x1, yy, hx('#3a3c34'), 0.6)
    # frosted privacy film on the lower third
    fy = y1 - (y1 - y0) * 0.36
    tdraw(c, (x0, fy, x1, y1), lambda od, ox, oy: od.rectangle([P(x0) + ox, P(fy) + oy, P(x1) + ox, P(y1) + oy], fill=(150, 160, 150, 96)))
    c.hline(x0, x1, fy, hx('#8a907f'), 0.8)
    # peeled corner of the film
    c.poly([(x0 + 300, fy), (x0 + 330, fy), (x0 + 318, fy + 12)], hx('#9aa090'), OUT)
    mulls = list(np.arange(x0, x1 + 1, 200))
    if mulls[-1] < x1 - 4:
        mulls.append(x1)
    for i in range(len(mulls) - 1):
        reflection(c, mulls[i], y0, mulls[i + 1], y1, 9, 0.3 + 0.08 * i, 0.12)
    for m in mulls[1:-1]:
        c.box(m - 3, y0, m + 3, y1, hx('#2a2c26'), outline=None, hl=.15)
    c.rect(x0 - 4, y0 - 4, x1 + 4, y0, hx('#2a2c26'))
    c.rect(x0 - 4, y0 - 4, x0, y1, hx('#2a2c26')); c.rect(x1, y0 - 4, x1 + 4, y1, hx('#2a2c26'))
    c.box(x0 - 8, y1, x1 + 8, y1 + 6, hx('#55574a'), outline=OUT, hl=.2)
    c.glow_rect(x0, y0, x1, fy, hx('#4a6070'), 0.16, blur=22)


# ------------------------------------------------------------ desks with hutch
def hutch_desk(c, x0, x1, top_y, seed=0, open_doors=(), notes_on=()):
    """steel developer desk with an overhead binder hutch; returns workstation centres"""
    rng = random.Random(seed)
    hb, ht = 434, 392                                                    # hutch bottom / top
    # hutch side posts + back panel
    c.box(x0 + 2, ht, x0 + 8, top_y, hx('#3c3e36'), outline=OUT, hl=.15)
    c.box(x1 - 8, ht, x1 - 2, top_y, hx('#3c3e36'), outline=OUT, hl=.15)
    c.vgrad(x0 + 8, top_y - 24, x1 - 8, top_y, hx('#2c2e28'), hx('#25271f'))   # low tack board behind the desk
    # hutch cabinet with flipper doors
    n = max(2, int((x1 - x0) / 96))
    dw = (x1 - x0 - 16) / n
    c.box(x0 + 2, ht, x1 - 2, hb, hx('#585a4e'), outline=OUT, hl=.1, sh=.3)
    for k in range(n):
        dx0 = x0 + 8 + k * dw
        if k in open_doors:
            c.rect(dx0 + 1, ht + 3, dx0 + dw - 1, hb - 2, hx('#16170f'))
            binders(c, dx0 + 4, hb - 3, int(dw / 7) - 1, seed=seed * 10 + k, h=34)
            c.box(dx0, ht - 6, dx0 + dw, ht, hx('#62645a'), outline=OUT, hl=.2)     # flipper door lifted
        else:
            c.rect(dx0 + 1, ht + 3, dx0 + dw - 1, hb - 3, None, dk(hx('#585a4e'), .3), 0.6)
            c.box(dx0 + dw / 2 - 8, hb - 10, dx0 + dw / 2 + 8, hb - 7, hx('#2a2c26'), outline=None)
            c.rect(dx0 + 6, ht + 8, dx0 + 22, ht + 14, dk(PAPER, .2))              # blank label holder
    # things on top of the hutch: boxes, rolled drawings
    xx = x0 + 10
    while xx < x1 - 40:
        r = rng.random()
        if r < 0.3:
            cardboard(c, xx, ht, rng.uniform(30, 44), rng.uniform(14, 22), seed=int(xx))
        elif r < 0.5:
            for j in range(3):
                c.rrect(xx + j * 2, ht - 5 - j * 4, xx + 50 + j * 2, ht - 1 - j * 4, 2, hx('#7f827a'), OUT, 0.5)
        xx += rng.uniform(60, 110)
    desk(c, x0, x1, top_y, peds=('L', 'R'), seed=seed, col=hx('#686b60'))
    cxs = [x0 + (x1 - x0) * 0.28, x0 + (x1 - x0) * 0.72]
    return cxs


# ------------------------------------------------------------ engineering area
def mobile_shelving(c, x0, n=4, w=52, h=185):
    """compact archive shelving: carriage end panels with three-spoke handwheels"""
    top = FY - h
    x1 = x0 + n * w
    c.occlude(x0 - 3, top, x1 + 3, FY, 115, blur=5); c.apply_shade_now()
    c.box(x0 - 4, FY - 4, x1 + 4, FY, hx('#3a3c34'), outline=OUT)                   # floor rails
    for k in range(n):
        ex = x0 + k * w
        col = hx('#4a4c42') if k % 2 else hx('#46483e')
        c.box(ex, top, ex + w - 2, FY - 4, col, outline=OUT, hl=.08, sh=.3)
        c.rect(ex + 6, top + 10, ex + w - 8, top + 40, hx('#7a7d70'))                # blank index card holder
        c.rect(ex + 6, top + 10, ex + w - 8, top + 40, None, OUT, 0.5)
        for j in range(4):
            c.hline(ex + 9, ex + w - 12, top + 16 + j * 6, hx('#55574b'), 0.5)
        cx, cy = ex + w / 2 - 1, top + 92
        c.ell(cx - 14, cy - 14, cx + 14, cy + 14, None, hx('#2a2c26'), 1.6)
        for a in (0, 2.094, 4.189):
            c.line([(cx, cy), (cx + math.cos(a) * 13, cy + math.sin(a) * 13)], hx('#2a2c26'), 1.4)
            c.ell(cx + math.cos(a) * 13 - 2.5, cy + math.sin(a) * 13 - 2.5, cx + math.cos(a) * 13 + 2.5, cy + math.sin(a) * 13 + 2.5, hx('#3a3c34'), OUT, 0.4)
        c.ell(cx - 4, cy - 4, cx + 4, cy + 4, hx('#8a8f86'), OUT, 0.5)
    # one aisle opened: shelves with binders visible in the gap
    gx0, gx1 = x0 + 2 * w - 2, x0 + 2 * w + 34
    c.rect(gx0, top + 4, gx1, FY - 6, hx('#121309'))
    for k in range(5):
        yy = top + 12 + k * 34
        c.rect(gx0, yy + 28, gx1, yy + 30, hx('#3a3c34'))
        binders(c, gx0 + 2, yy + 28, 4, seed=k + 70, h=24)


def plotter(c, x):
    """wide-format plotter on its stand, a long drawing curling into the basket"""
    c.occlude(x - 4, FY - 104, x + 136, FY, 100, blur=4)
    for lx in (x + 8, x + 118):
        c.box(lx, FY - 70, lx + 6, FY - 4, hx('#2c2e28'), outline=OUT)
        c.box(lx - 8, FY - 4, lx + 14, FY, hx('#2c2e28'), outline=OUT)
    c.box(x + 10, FY - 40, x + 122, FY - 36, hx('#2c2e28'), outline=OUT)
    c.rrect(x, FY - 104, x + 132, FY - 70, 8, hx('#3e4038'), OUT, 1)
    c.rect(x + 8, FY - 98, x + 124, FY - 94, hx('#2a2c26'))
    c.rect(x + 96, FY - 90, x + 120, FY - 82, hx('#121510'))
    led(c, x + 110, FY - 86, GREEN, 0.5, 0.4)
    # drawing output curling into a fabric basket
    c.bezier((x + 30, FY - 70), (x + 20, FY - 40), (x + 50, FY - 22), hx('#868a7f'), 3)
    c.bezier((x + 50, FY - 22), (x + 80, FY - 10), (x + 100, FY - 28), hx('#868a7f'), 3)
    c.poly([(x + 16, FY - 36), (x + 116, FY - 36), (x + 104, FY - 14), (x + 28, FY - 14)], hx('#2a2b22'), OUT)
    for k in range(5):
        c.line([(x + 30 + k * 18, FY - 34), (x + 34 + k * 16, FY - 16)], hx('#3a3b30'), 0.6)


def drawings_board(c, x0, y0, x1, y1, seed=0):
    rng = random.Random(seed)
    c.occlude(x0 + 2, y0 + 3, x1 + 3, y1 + 5, 90, blur=4); c.apply_shade_now()
    c.box(x0, y0, x1, y1, hx('#4a3e31'), outline=OUT, hl=.03)
    sheets = []
    xx = x0 + 6
    while xx < x1 - 50:
        sw = rng.uniform(56, 84)
        sheets.append((xx, sw))
        xx += sw + rng.uniform(4, 10)
    for i, (sx, sw) in enumerate(sheets):
        sy = y0 + 6 + rng.uniform(0, 6)
        sh = y1 - y0 - 14 - rng.uniform(0, 8)
        c.box(sx, sy, sx + sw, sy + sh, hx('#7c7f76'), outline=OUT, hl=.02)
        # architecture/topology drawing in blue-line style
        for r in range(3):
            for k in range(2):
                bx = sx + 6 + k * (sw / 2 - 2); by = sy + 8 + r * (sh / 3.4)
                c.rect(bx, by, bx + sw / 2 - 10, by + sh / 6, None, hx('#2f4766'), 0.6)
        c.vline(sx + sw / 2, sy + 8, sy + sh - 8, hx('#2f4766'), 0.5)
        c.ell(sx + sw / 2 - 1.5, sy - 1, sx + sw / 2 + 1.5, sy + 2, MUSTARD)
        if rng.random() < 0.4:
            sticky(c, sx + sw - 9, sy + sh - 12, hx('#a69a58'))


def rules_board(c, x0, y0, w=70, h=86):
    """night approval rule sheet in a frame, a handwritten addition underneath"""
    c.occlude(x0 + 1, y0 + 2, x0 + w + 2, y0 + h + 3, 80, blur=3); c.apply_shade_now()
    c.box(x0 - 3, y0 - 3, x0 + w + 3, y0 + h + 3, MUSTARD, outline=OUT, hl=.25)
    c.box(x0, y0, x0 + w, y0 + h, hx('#7f8278'), outline=None, hl=.02)
    c.rect(x0 + 4, y0 + 4, x0 + w - 4, y0 + 12, hx('#3a3c34'))
    for k in range(6):
        c.hline(x0 + 6, x0 + w - 8 - (k % 3) * 8, y0 + 18 + k * 6, hx('#4f5458'), 0.6)
    # taped-on handwritten addition, in blue pen, slightly crooked
    c.poly([(x0 + 4, y0 + 58), (x0 + w - 2, y0 + 56), (x0 + w - 1, y0 + h - 4), (x0 + 5, y0 + h - 2)], hx('#8c8e84'), OUT)
    rng = random.Random(3)
    for k in range(3):
        yy = y0 + 64 + k * 6
        pts = [(x0 + 8 + i * 3, yy + rng.uniform(-0.8, 0.8) - i * 0.04) for i in range(int((w - 18) / 3))]
        c.line(pts, hx('#2f4766'), 0.6)
    c.rect(x0 + 2, y0 + 55, x0 + 12, y0 + 59, hx('#9a9c8e'))
    c.rect(x0 + w - 12, y0 + 54, x0 + w - 2, y0 + 58, hx('#9a9c8e'))


def wall_net_cabinet(c, x, y, w=62, h=86):
    c.occlude(x + 1, y + 2, x + w + 3, y + h + 4, 100, blur=4); c.apply_shade_now()
    c.box(x, y, x + w, y + h, hx('#2a2c28'), outline=OUT, hl=.1)
    c.rect(x + 4, y + 4, x + w - 4, y + h - 4, hx('#101210'))
    rng = random.Random(4)
    for k, kind in enumerate(['patch', 'switch', 'patch', 'switch', 'blank', 'ups']):
        yy = y + 8 + k * 12
        if kind == 'patch':
            c.box(x + 6, yy, x + w - 6, yy + 6, hx('#3f464c'), outline=OUT)
            for j in range(10):
                px = x + 9 + j * 4.6
                col = rng.choice([hx('#3e6aa0'), hx('#7a8a92'), hx('#4f7f6a')])
                c.rect(px, yy + 2, px + 2, yy + 4, col)
                c.bezier((px + 1, yy + 4), (px + 1, yy + 8), (px + rng.uniform(-3, 3), yy + 12), dk(col, .2), 0.5)
        elif kind == 'switch':
            c.box(x + 6, yy, x + w - 6, yy + 6, hx('#22272b'), outline=OUT)
            for j in range(8):
                if rng.random() < .3:
                    led(c, x + 10 + j * 5.5, yy + 1.5, GREEN, 0.3, 0.3)
        elif kind == 'ups':
            c.box(x + 6, yy, x + w - 6, yy + 10, hx('#26292c'), outline=OUT)
            c.rect(x + 10, yy + 3, x + 20, yy + 7, hx('#0e1610'))
            c.rect(x + 11, yy + 4, x + 15, yy + 6, MUSTARD_L)
            c.glow_rect(x + 10, yy + 3, x + 20, yy + 7, MUSTARD, 0.35, blur=3)
    tdraw(c, (x + 4, y + 4, x + w - 4, y + h - 4), lambda od, ox, oy: od.rectangle([P(x + 4) + ox, P(y + 4) + oy, P(x + w - 4) + ox, P(y + h - 4) + oy], fill=(60, 80, 90, 40)))
    reflection(c, x + 4, y + 4, x + w - 4, y + h - 4, 22, 0.2, 0.3)
    c.box(x + w - 8, y + h / 2 - 8, x + w - 5, y + h / 2 + 8, hx('#6a6e66'), outline=None)


def fiber_box(c, x, y, sleeve_x):
    """DR replication circuit termination box with one new yellow fibre running into a floor sleeve"""
    c.occlude(x + 1, y + 2, x + 44, y + 52, 80, blur=3); c.apply_shade_now()
    c.box(x, y, x + 42, y + 50, hx('#4c4f46'), outline=OUT, hl=.1)
    c.rect(x + 4, y + 4, x + 38, y + 46, None, hx('#353830'), 0.6)
    for k in range(4):
        c.rect(x + 8 + k * 7, y + 36, x + 12 + k * 7, y + 42, hx('#1a1c18'))
    led(c, x + 34, y + 10, RED, 0.6, 0.6)
    # old grey trunk cables
    for k in range(3):
        c.bezier((x + 10 + k * 5, y + 50), (x + 6 + k * 5, y + 90), (x + 2 + k * 4, FY - 1), hx('#3a3c38'), 1.1)
    # the new one: clean bright yellow, printed label flag, straight into the floor sleeve
    c.bezier((x + 30, y + 50), (x + 34, y + 120), (sleeve_x, FY - 2), hx('#d8b83a'), 1.6)
    c.rect(x + 28, y + 62, x + 40, y + 68, hx('#e6e6dc'))
    c.rect(x + 28, y + 62, x + 40, y + 68, None, OUT, 0.4)
    c.glow_rect(x + 26, y + 50, x + 40, y + 120, hx('#d8b83a'), 0.12, blur=6)


def floor_sleeve(c, x, slab_top, slab_bottom):
    """core-drilled penetration: fibre continues down through the slab section (toward B2)"""
    c.rect(x - 6, FY - 3, x + 6, FY, hx('#5a5c50'))
    c.rect(x - 4, slab_top, x + 4, slab_bottom, hx('#0d0e0b'))
    c.rect(x - 4, slab_top, x - 3, slab_bottom, hx('#3a3c34'))
    c.rect(x + 3, slab_top, x + 4, slab_bottom, hx('#3a3c34'))
    c.vline(x - 0.8, FY - 2, slab_bottom + 10, hx('#d8b83a'), 1.6)
    for yy in (slab_top + 4, slab_top + 10):                                  # fire-stop putty
        c.rect(x - 4, yy, x + 4, yy + 4, hx('#7a4a3a'))


def oncall_phone(c, x, desk_y):
    """the duty extension on UPS, ringing: display lit, red ring lamp"""
    c.poly([(x - 16, desk_y), (x + 16, desk_y), (x + 12, desk_y - 10), (x - 14, desk_y - 8)], hx('#1f2226'), OUT)
    c.rect(x - 8, desk_y - 7, x + 4, desk_y - 3.5, hx('#9ab890'))
    c.glow_rect(x - 9, desk_y - 8, x + 5, desk_y - 3, hx('#9ab890'), 0.5, blur=4)
    c.rrect(x - 16, desk_y - 14, x + 7, desk_y - 9, 2, hx('#24282b'), OUT, 0.6)
    c.bezier((x - 16, desk_y - 11), (x - 28, desk_y + 4), (x - 20, desk_y - 1), hx('#121416'), 0.6)
    led(c, x + 10, desk_y - 8, RED, 1.0, 1.0)
    c.glow_ell(x + 10, desk_y - 8, 14, 10, RED, 0.35, blur=8)
    # faint vibration ticks around the handset (drawn as soft arcs, not text)
    for k in range(2):
        c.ell(x - 22 - k * 4, desk_y - 22 - k * 4, x + 12 + k * 4, desk_y - 4 + k * 4, None, wa(hx('#7a3a33'), 255), 0.4)


def token_tray(c, x, desk_y):
    c.box(x, desk_y - 3, x + 36, desk_y, hx('#2b2e2a'), outline=OUT)
    for k in range(12):
        tx = x + 2 + k * 2.8
        c.rect(tx, desk_y - 6, tx + 2, desk_y - 3, hx('#3e4a52') if k != 7 else hx('#8a3a33'))
    c.box(x + 40, desk_y - 4, x + 70, desk_y, hx('#3a4248'), outline=OUT)               # ledger
    c.rect(x + 42, desk_y - 4.6, x + 68, desk_y - 3.8, hx('#7f827d'))


def form_stack(c, x0, x1, desk_y, n=20):
    """twenty identical request forms, each with the same stamp"""
    y = desk_y
    for k in range(n):
        o = (k % 3 - 1) * 0.6
        c.rect(x0 + o, y - 0.8, x1 + o, y, hx('#7d8078') if k % 2 else hx('#73766e'))
        y -= 0.8
    c.rect(x0 - 1, y, x1 + 1, desk_y, None, OUT, 0.5)
    c.ell(x1 - 12, y - 7, x1 - 2, y + 1, None, hx('#8a3a33'), 0.8)          # stamp on the top sheet
    c.ell(x1 - 10, y - 5, x1 - 4, y - 1, None, hx('#8a3a33'), 0.5)


def usage_log(c, x, y, w=58, h=44):
    """line usage printout: flat line all day, saturated block 03:05-03:40"""
    c.occlude(x + 1, y + 2, x + w + 2, y + h + 3, 70, blur=2); c.apply_shade_now()
    c.box(x, y, x + w, y + h, hx('#7f827d'), outline=OUT, hl=.02)
    base = y + h - 6
    c.hline(x + 4, x + w - 4, base, hx('#3a3c38'), 0.6)
    c.hline(x + 4, x + w - 4, y + 8, hx('#3a3c38'), 0.4)                     # 100% line
    pts = []
    for i in range(40):
        xx = x + 4 + (w - 8) * i / 39
        yy = base - 3 - math.sin(i * 0.7) * 1.2
        pts.append((xx, yy))
    c.line(pts, hx('#2f4766'), 0.6)
    bx = x + 4 + (w - 8) * 3.1 / 24
    c.rect(bx, y + 8, bx + (w - 8) * 0.6 / 24 + 1.5, base, hx('#8a3a33'))
    c.ell(bx - 4, y + 3, bx + 6, base + 3, None, hx('#8a3a33'), 0.5)
    c.rect(x + w / 2 - 6, y - 2, x + w / 2 + 6, y + 2, hx('#9a9c8e'))


def dr_whiteboard(c, x0, y0, x1, y1):
    """full-width whiteboard wall: DR replication topology, a dashed link off to nowhere"""
    c.occlude(x0 + 2, y0 + 3, x1 + 3, y1 + 5, 80, blur=4); c.apply_shade_now()
    c.rect(x0, y0, x1, y1, hx('#4f5348'))
    c.vgrad(x0 + 3, y0 + 3, x1 - 3, y1 - 3, hx('#6c7068'), hx('#5a5e56'))
    for k in range(5):
        c.stain(x0 + 20 + k * 80, y0 + 20 + (k % 2) * 40, 60, 20, hx('#7f837a'), alpha=24, blur=4, seed=k)
    ink = hx('#2b3034'); blue = hx('#2f4766'); red = hx('#7b3a33')
    # left: our data centre stack (B2), middle: customer DR centre, right: dashed link to an unknown cloud
    def stack(bx, by, n, col):
        for k in range(n):
            c.rect(bx, by + k * 11, bx + 46, by + k * 11 + 8, None, col, 0.9)
            c.hline(bx + 4, bx + 24, by + k * 11 + 4, col, 0.5)
    stack(x0 + 30, y0 + 26, 5, ink)
    stack(x0 + 190, y0 + 26, 4, blue)
    c.line([(x0 + 76, y0 + 50), (x0 + 190, y0 + 50)], blue, 1.2)                       # registered DR line
    c.poly([(x0 + 186, y0 + 47), (x0 + 190, y0 + 50), (x0 + 186, y0 + 53)], blue)
    # new path drawn later in red: from B2 straight past the DR centre to a cloud shape
    for xx in np.arange(x0 + 76, x0 + 380, 7):
        c.hline(xx, xx + 4, y0 + 76, red, 1.1)
    cx, cy = x0 + 410, y0 + 76
    for dx, dy, r in ((-14, 4, 12), (0, -6, 15), (16, 2, 12), (2, 8, 11)):
        c.ell(cx + dx - r, cy + dy - r * 0.7, cx + dx + r, cy + dy + r * 0.7, None, red, 0.9)
    c.ell(cx - 34, cy - 26, cx + 36, cy + 26, None, red, 1.1)
    c.line([(cx + 30, cy + 22), (cx + 44, cy + 34)], red, 1.1)
    # time bar: one short slot filled in solid
    ty = y1 - 26
    c.hline(x0 + 30, x1 - 30, ty, ink, 1)
    for k in range(25):
        xx = x0 + 30 + (x1 - x0 - 60) * k / 24
        c.vline(xx, ty - 2, ty + 2, ink, 0.6)
    s0 = x0 + 30 + (x1 - x0 - 60) * 3.08 / 24; s1 = x0 + 30 + (x1 - x0 - 60) * 3.67 / 24
    c.rect(s0, ty - 6, s1, ty, red)
    # half-erased older notes and sticky notes
    for k in range(4):
        sx = x1 - 120 + k * 22
        pts = [(sx + i * 3, y0 + 30 + rng_jit(i, k)) for i in range(6)]
        c.line(pts, hx('#80847a'), 0.7)
    for k, (sx, sy) in enumerate([(x1 - 60, y0 + 14), (x1 - 48, y0 + 22), (x1 - 70, y0 + 40)]):
        sticky(c, sx, sy, [hx('#a69a58'), hx('#9b7177'), hx('#a69a58')][k])
    c.rect(x0, y0, x1, y1, None, hx('#787c70'), 1); c.rect(x0, y0, x1, y1, None, OUT, 0.5)
    c.box(x0 + 6, y1, x1 - 6, y1 + 4, hx('#5e6258'), outline=OUT)
    c.rect(x0 + 20, y1 - 1.6, x0 + 30, y1, red); c.rect(x0 + 34, y1 - 1.6, x0 + 44, y1, blue)


def rng_jit(i, k):
    return math.sin(i * 1.7 + k) * 1.2


def vc_display(c, x0, y0, w=180, h=100):
    c.occlude(x0 + 2, y0 + 3, x0 + w + 3, y0 + h + 5, 100, blur=4); c.apply_shade_now()
    c.rrect(x0, y0, x0 + w, y0 + h, 1.5, hx('#0e1012'), OUT, 1)
    screen_content(c, x0 + 3, y0 + 3, x0 + w - 3, y0 + h - 3, 'off', seed=6)
    c.box(x0 + w / 2 - 30, y0 - 10, x0 + w / 2 + 30, y0 - 2, hx('#1b1d1f'), outline=OUT)     # camera bar
    c.ell(x0 + w / 2 - 4, y0 - 9, x0 + w / 2 + 4, y0 - 3, hx('#2a3238'), OUT, 0.4)
    led(c, x0 + w / 2 + 20, y0 - 6, RED, 0.45, 0.5)
    led(c, x0 + w - 5, y0 + h - 2, RED, 0.45, 0.4)


def sign_plate(c, x, y, w=50, h=14):
    c.box(x, y, x + w, y + h, hx('#121309'), outline=OUT)
    c.rect(x + 2, y + 2, x + w - 2, y + h - 2, None, MUSTARD, 0.8)
    c.rect(x + 6, y + 5, x + 12, y + h - 5, MUSTARD_L)                         # pictogram block only
