import random, math
import numpy as np
from lib import *
from objects import *

def city(x0, y0, x1, y1, seed=0, leds=True):
    rng = random.Random(seed)
    c.vgrad(x0, y0, x1, y1, hx('#0b1019'), hx('#1c2735'))
    # haze band near horizon
    c.vgrad(x0, y1 - 70, x1, y1, wa(hx('#24324a'), 0), wa(hx('#2b3a4f'), 200))
    layers = [
        (hx('#141c27'), 40, 150, 26, 60, 0.10, 0.65),
        (hx('#101721'), 30, 120, 30, 70, 0.14, 0.85),
        (hx('#0c121a'), 20, 70, 40, 90, 0.18, 1.0),
    ]
    for li, (col, hmin, hmax, wmin, wmax, p, sc) in enumerate(layers):
        x = x0 - rng.uniform(0, 30)
        while x < x1:
            bw = rng.uniform(wmin, wmax); bh = rng.uniform(hmin, hmax)
            top = y1 - bh
            bx0, bx1 = max(x, x0), min(x + bw, x1)
            if bx1 > bx0:
                c.rect(bx0, max(top, y0), bx1, y1, col)
                c.vline(bx0, max(top, y0), y1, lit(col, .06), 0.6)
                # lit windows
                pb = rng.choice([0.0, 0.01, 0.03, 0.06, 0.12, 0.22]) * (p / 0.14)
                tone = rng.choice([hx('#b89763'), hx('#a3885e'), hx('#7f98ad'), hx('#8f9fa8')])
                for wy in np.arange(top + 5, y1 - 2, 5 * sc + 1):
                    row_on = rng.random() < 0.08
                    for wx in np.arange(x + 3, x + bw - 3, 4 * sc + 1):
                        if x0 + 1 < wx < x1 - 3 and wy > y0 + 1 and rng.random() < (0.55 if row_on else pb):
                            wc = dk(tone, 0.32 + 0.14 * (2 - li) + rng.uniform(0, .15))
                            c.rect(wx, wy, wx + 1.6 * sc, wy + 2.2 * sc, wc)
                if leds and bh > hmax * 0.85 and top > y0 + 4 and rng.random() < 0.3:
                    led(c, x + bw / 2, top - 1.5, RED, 0.8, glow=0.6)
                    c.vline(x + bw / 2 - 0.3, top - 1.5, top, hx('#222a33'), 0.6)
            x += bw + rng.uniform(0, 10)


def blinds(x0, y0, x1, drop, slat=3.2, col=hx('#40474d'), tilt_gap=False, skew=0.0, seed=0):
    rng = random.Random(seed)
    c.rect(x0 - 2, y0 - 6, x1 + 2, y0, hx('#2e3439'))     # head rail
    y = y0
    n = int(drop / (slat + 0.8))
    for i in range(n):
        yy = y0 + i * (slat + 0.8)
        cc = mix(col, dk(col, .35), i / max(1, n))
        c.rect(x0, yy, x1, yy + slat, cc)
        c.hline(x0, x1, yy, lit(cc, .12), 0.5)
    by = y0 + n * (slat + 0.8)
    if skew:
        c.poly([(x0, by), (x1, by), (x1, by + skew), (x0, by + 2)], dk(col, .3), OUT)
        by2 = by + skew
        c.rect(x0, by - 1, x1, by + 1.2, hx('#2c3135'))
        c.line([(x0, by + 1.5), (x1, by2)], hx('#2c3135'), 1.6)
    else:
        c.rect(x0 - 1, by, x1 + 1, by + 2.2, hx('#2c3135'))
    # cords
    cx = x1 - 10
    c.vline(cx, y0, by + 40, hx('#5a6168'), 0.5)
    c.ell(cx - 1.2, by + 40, cx + 1.8, by + 44, hx('#5a6168'))
    return by


