import random, math
from lib import *
from objects import *

BRASS = hx('#8a7246')
WOOD = hx('#4a3d31')
SLATE = hx('#3a3f45')


def vlouvers(c, x0, y0, x1, y1, seed=0, slat=10, missing=(), turned=()):
    """vertical fabric louvers in front of a window. turned: indices rotated edge-on (see-through)"""
    rng = random.Random(seed)
    c.box(x0 - 3, y0 - 6, x1 + 3, y0, hx('#2f343a'), outline=OUT)   # head rail
    n = int((x1 - x0) / (slat + 1))
    for i in range(n):
        sx = x0 + i * (slat + 1)
        if i in missing:
            continue
        hang = y1 - 6 - rng.uniform(0, 3)
        col = mix(hx('#41474d'), hx('#33383e'), rng.random())
        if i in turned:
            # edge-on: thin slat, city visible to both sides
            c.box(sx + slat / 2 - 1.2, y0, sx + slat / 2 + 1.2, hang, dk(col, .1), outline=None, hl=.05)
            continue
        sw = slat if rng.random() > 0.25 else slat * 0.6          # some half-turned
        ox = (slat - sw) / 2
        c.vgrad(sx + ox, y0, sx + ox + sw, hang, lit(col, .05), dk(col, .25))
        c.vline(sx + ox, y0, hang, lit(col, .12), 0.5)
        c.vline(sx + ox + sw - 0.6, y0, hang, dk(col, .35), 0.6)
        c.rect(sx + 1, hang - 1.5, sx + slat - 1, hang, hx('#2b3035'))   # bottom weight
    # bottom chain
    for i in range(n):
        sx = x0 + i * (slat + 1) + slat / 2
        if i in missing:
            continue
        c.rect(sx - 0.5, y1 - 5, sx + 0.5, y1 - 4.4, hx('#6a7076'))


def fallen_slat(c, x, y, length=120, angle=0.18):
    """a louver slat that came off, leaning diagonally against the sill"""
    pts = [(x, y), (x + 9, y), (x + 9 + math.sin(angle) * length, y - length), (x + math.sin(angle) * length, y - length)]
    c.poly(pts, hx('#50565c'), OUT)
    c.line([(x + 1.5, y - 1), (x + 1.5 + math.sin(angle) * length, y - length + 1)], hx('#646a70'), 0.6)


def bookcase(c, x, w, h, seed=0, shelves=5, sparse=False, top_items=None):
    rng = random.Random(seed)
    top = FY - h
    c.occlude(x - 3, top, x + w + 3, FY, 115, blur=5)
    c.apply_shade_now()
    body = hx('#3d3a35')
    c.box(x, top, x + w, FY, body, outline=OUT, hl=.08, sh=.3)
    c.rect(x + 4, top + 4, x + w - 4, FY - 8, hx('#181715'))
    sh_h = (h - 12) / shelves
    spines = [hx('#3f4f5e'), hx('#5c4b42'), hx('#4a5646'), hx('#5d5f61'), hx('#6b5a3c'), hx('#3d4148'),
              hx('#6a4c45'), hx('#4f5a63'), hx('#7a6c50')]
    for k in range(shelves):
        sy0 = top + 4 + k * sh_h
        sy1 = sy0 + sh_h - 3
        # shelf board
        c.box(x + 4, sy1, x + w - 4, sy1 + 3, lit(body, .05), outline=None, hl=.15)
        xx = x + 6
        while xx < x + w - 10:
            r = rng.random()
            if sparse and r < 0.12:
                xx += rng.uniform(8, 18); continue
            if r < 0.07:                                   # gap + leaning book
                lw = rng.uniform(4, 6); lh = (sy1 - sy0) * rng.uniform(.6, .85)
                col = rng.choice(spines)
                c.poly([(xx, sy1), (xx + lw, sy1), (xx + lw + lh * .4, sy1 - lh * .92), (xx + lh * .4, sy1 - lh * .92)], col, OUT)
                xx += lw + lh * .45 + 2; continue
            if r < 0.16:                                   # lying stack
                sw = rng.uniform(16, 24)
                if xx + sw > x + w - 8: break
                yy = sy1
                for j in range(rng.randint(2, 4)):
                    th = rng.uniform(2.5, 4)
                    c.box(xx, yy - th, xx + sw, yy, rng.choice(spines), outline=OUT)
                    yy -= th
                xx += sw + 2; continue
            if r < 0.19:                                   # archive box
                bw = rng.uniform(16, 22)
                if xx + bw > x + w - 8: break
                bh = (sy1 - sy0) * 0.8
                c.box(xx, sy1 - bh, xx + bw, sy1, hx('#5a5040'), outline=OUT, hl=.06)
                c.rect(xx + 3, sy1 - bh * .7, xx + bw - 3, sy1 - bh * .5, dk(PAPER, .15))
                xx += bw + 1; continue
            bw = rng.uniform(3.2, 7)
            bh = (sy1 - sy0) * rng.uniform(.62, .92)
            if xx + bw > x + w - 6: break
            col = rng.choice(spines)
            c.box(xx, sy1 - bh, xx + bw, sy1, col, outline=None, hl=.1, sh=.3)
            c.vline(xx + bw - 0.5, sy1 - bh, sy1, OUT, 0.5)
            if rng.random() < .35:
                c.hline(xx + .6, xx + bw - .6, sy1 - bh * .78, lit(col, .25), 0.6)
            xx += bw
        c.occlude(x + 4, sy0, x + w - 4, sy0 + 8, 90, blur=3)
    c.apply_shade_now()
    # plinth
    c.rect(x + 2, FY - 8, x + w - 2, FY, dk(body, .3))
    # dust on top
    c.hline(x + 1, x + w - 1, top + 0.5, hx('#5d5a52'), 0.8)
    if top_items:
        top_items(top)


def kick_step(c, x):
    """two-step rolling library step (the movable footstool)"""
    col = hx('#4a5258')
    c.occlude(x - 2, FY - 40, x + 46, FY, 90, blur=3)
    c.box(x, FY - 20, x + 44, FY - 2, col, outline=OUT, hl=.1)
    c.box(x + 18, FY - 38, x + 44, FY - 20, col, outline=OUT, hl=.1)
    c.rect(x + 2, FY - 21, x + 42, FY - 19, hx('#2a2f33'))     # tread rubber
    c.rect(x + 20, FY - 39, x + 42, FY - 37, hx('#2a2f33'))
    for wx in (x + 4, x + 36):
        c.ell(wx, FY - 4, wx + 5, FY, hx('#15181b'), OUT, 0.4)


def doc_cart(c, x, w=48, seed=0):
    c.occlude(x - 2, FY - 92, x + w + 2, FY, 90, blur=3)
    for lx in (x, x + w - 3):
        c.box(lx, FY - 92, lx + 3, FY - 4, hx('#4f575d'), outline=OUT)
    for k, yy in enumerate((FY - 90, FY - 52, FY - 14)):
        c.box(x, yy, x + w, yy + 3, hx('#59616a'), outline=OUT)
    binders(c, x + 3, FY - 52, 5, seed=seed + 1, h=34, lean_last=True)
    papers(c, x + 4, x + w - 6, FY - 90, 9, seed=seed + 2)
    cardboard(c, x + 5, FY - 14, w - 12, 24, seed=seed + 3, open_top=True)
    for wx in (x + 2, x + w - 7):
        c.ell(wx, FY - 5, wx + 5, FY, hx('#15181b'), OUT, 0.4)


def perforated(c, x0, y0, x1, y1, seed=0, panel=88):
    base = hx('#2c3035')
    c.vgrad(x0, y0, x1, y1, lit(base, .04), dk(base, .1))
    for px in range(int(x0), int(x1), panel):
        c.vline(px, y0, y1, dk(base, .35), 0.8)
        c.vline(px + 0.8, y0, y1, lit(base, .08), 0.4)
        for yy in range(int(y0) + 6, int(y1) - 4, 5):
            for xx in range(px + 5, min(px + panel - 3, int(x1) - 3), 5):
                c.rect(xx, yy, xx + 1, yy + 1, dk(base, .45))


def wood_louver_wall(c, x0, y0, x1, y1, seed=0):
    rng = random.Random(seed)
    c.rect(x0, y0, x1, y1, hx('#161210'))
    xx = x0 + 1
    while xx < x1 - 4:
        col = mix(WOOD, dk(WOOD, .25), rng.random())
        c.vgrad(xx, y0, xx + 5, y1, lit(col, .06), dk(col, .2))
        c.vline(xx, y0, y1, lit(col, .14), 0.5)
        xx += 7
    c.box(x0, y0, x1, y0 + 4, BRASS, outline=OUT, hl=.2)
    c.box(x0, y1 - 4, x1, y1, dk(BRASS, .2), outline=OUT, hl=.2)


def security_cabinet(c, x, w=64, h=170, seed=0):
    top = FY - h
    c.occlude(x - 3, top, x + w + 3, FY, 115, blur=5)
    c.apply_shade_now()
    col = hx('#3b4248')
    c.box(x, top, x + w, FY - 3, col, outline=OUT, hl=.08, sh=.32)
    c.vline(x + w / 2, top + 4, FY - 6, OUT, 0.8)
    for side in (0, 1):
        px = x + 4 + side * w / 2
        c.rect(px, top + 4, px + w / 2 - 8, FY - 8, None, dk(col, .3), 0.6)
        for k in range(3):
            c.hline(px + 6, px + w / 2 - 14, top + 12 + k * 3, dk(col, .35), 0.6)   # vents
    # keypad + dial
    kx = x + w / 2 + 6
    c.box(kx, top + 52, kx + 16, top + 76, hx('#22272b'), outline=OUT)
    for r in range(3):
        for k in range(3):
            c.rect(kx + 3 + k * 4, top + 60 + r * 4.5, kx + 5.5 + k * 4, top + 62.5 + r * 4.5, hx('#4a5258'))
    c.rect(kx + 3, top + 54, kx + 13, top + 58, hx('#1a1210'))
    led(c, kx + 13, top + 55.5, RED, 0.6, 0.6)
    c.box(x + w / 2 - 6, top + 88, x + w / 2 - 2, top + 108, hx('#6a7176'), outline=OUT)   # handles
    c.box(x + w / 2 + 2, top + 88, x + w / 2 + 6, top + 108, hx('#6a7176'), outline=OUT)
    # blank warning plate (yellow/black)
    c.box(x + 8, top + 30, x + 26, top + 44, hx('#8a7a3a'), outline=OUT)
    for k in range(3):
        c.line([(x + 9 + k * 6, top + 43), (x + 13 + k * 6, top + 31)], hx('#2a2a22'), 1)
    c.rect(x + 2, FY - 3, x + 8, FY, OUT); c.rect(x + w - 8, FY - 3, x + w - 2, FY, OUT)


def printer_tall(c, x, seed=0):
    """audit-log line printer on a stand with a long printout spilling to the floor"""
    c.occlude(x - 3, FY - 96, x + 66, FY, 100, blur=4)
    c.box(x + 4, FY - 60, x + 8, FY - 2, hx('#2c3135'), outline=OUT)
    c.box(x + 54, FY - 60, x + 58, FY - 2, hx('#2c3135'), outline=OUT)
    c.box(x, FY - 62, x + 62, FY - 58, hx('#3e454a'), outline=OUT)
    c.box(x + 2, FY - 92, x + 60, FY - 62, hx('#5d6469'), outline=OUT, hl=.1)
    c.rect(x + 6, FY - 86, x + 56, FY - 82, hx('#2a2f33'))
    led(c, x + 52, FY - 70, GREEN, 0.5, 0.4)
    # fanfold printout
    pts = [(x + 12, FY - 82), (x + 48, FY - 82), (x + 52, FY - 66), (x + 46, FY - 40), (x + 58, FY - 14), (x + 80, FY - 1),
           (x + 120, FY - 1), (x + 120, FY), (x + 70, FY), (x + 44, FY - 12), (x + 34, FY - 40), (x + 16, FY - 66)]
    c.poly(pts, hx('#7e817c'), OUT)
    for k in range(9):
        yy = FY - 78 + k * 8
        if yy < FY - 4:
            c.hline(x + 20, x + 44, yy, hx('#5d605c'), 0.5)
    c.hline(x + 74, x + 116, FY - 0.6, hx('#9a9c96'), 0.6)


def conf_phone(c, cx, desk_y):
    c.poly([(cx - 16, desk_y), (cx + 16, desk_y), (cx + 11, desk_y - 5), (cx - 11, desk_y - 5)], hx('#1b1f23'), OUT)
    c.rect(cx - 10, desk_y - 6, cx + 10, desk_y - 4.6, hx('#2a2f33'))
    c.rect(cx - 6, desk_y - 3.2, cx + 6, desk_y - 2.2, hx('#c4473d'))
    c.glow_rect(cx - 8, desk_y - 4, cx + 8, desk_y - 1, RED, 0.75, blur=4)
    c.glow_ell(cx, desk_y, 30, 6, RED, 0.25, blur=10)


def bottle(c, x, desk_y):
    tpoly(c, [(x - 2.5, desk_y), (x + 2.5, desk_y), (x + 2.5, desk_y - 13), (x + 1.2, desk_y - 16), (x - 1.2, desk_y - 16), (x - 2.5, desk_y - 13)], hx('#8aa0ae'), 70)
    c.rect(x - 1.3, desk_y - 18, x + 1.3, desk_y - 16, hx('#2f4766'))
    c.rect(x - 2.5, desk_y - 9, x + 2.5, desk_y - 6, hx('#5d6a74'))


def meeting_table(c, x0, x1, top_y):
    th = 5
    c.occlude(x0 + 6, top_y + th, x1 - 6, FY, 100, blur=6)
    c.apply_shade_now()
    # panel bases
    for bx in (x0 + 60, x1 - 120):
        c.box(bx, top_y + th, bx + 60, FY - 2, hx('#2d2621'), outline=OUT, hl=.05)
        c.rect(bx - 6, FY - 4, bx + 66, FY, hx('#1d1916'))
    # cable spine
    c.box(x0 + 120, top_y + th, x1 - 120, top_y + th + 8, hx('#1d2024'), outline=OUT)
    c.box(x0, top_y, x1, top_y + th, hx('#5a4a3c'), outline=OUT, hl=.15, sh=.4)
    c.hline(x0 + 1, x1 - 1, top_y + 0.4, hx('#7a6a58'), 0.6)
    c.hline(x0, x1, top_y + th - 1, dk(BRASS, .3), 0.6)


def credenza(c, x, w, seed=0):
    top = FY - 72
    c.occlude(x - 3, top, x + w + 3, FY, 100, blur=4)
    c.apply_shade_now()
    c.box(x, top, x + w, FY - 4, hx('#40352c'), outline=OUT, hl=.08)
    n = 3
    dw = (w - 8) / n
    for k in range(n):
        dx = x + 4 + k * dw
        c.rect(dx, top + 6, dx + dw - 3, FY - 10, None, dk(hx('#40352c'), .35), 0.6)
        c.box(dx + dw / 2 - 6, top + 14, dx + dw / 2 + 4, top + 16, BRASS, outline=None)
    c.box(x - 2, top - 3, x + w + 2, top, hx('#54473b'), outline=OUT)
    c.rect(x + 3, FY - 4, x + 8, FY, OUT); c.rect(x + w - 8, FY - 4, x + w - 3, FY, OUT)


def partition(c, x0, x1, top, door_h=205, style='solid', door_side='R', reader=False):
    """interior partition cut in section, with a doorway; door leaf open (edge-on)"""
    dtop = FY - door_h
    cut = hx('#24282c')
    c.vgrad(x0, top, x1, dtop, lit(cut, .05), dk(cut, .1))
    # hatch
    from objects import tdraw
    def f(od, ox, oy):
        for k in range(int(-(dtop - top)), int(x1 - x0) + 2, 6):
            od.line([(P(x0 + k) + ox, P(dtop) + oy), (P(x0 + k + (dtop - top)) + ox, P(top) + oy)], fill=(70, 76, 82, 80), width=P(0.7))
    tdraw(c, (x0, top, x1, dtop), f)
    c.rect(x0, top, x1, dtop, None, OUT, 1)
    # doorway: looking through the opening into the dark depth of the wall
    c.vgrad(x0, dtop, x1, FY, hx('#121417'), hx('#1c1f23'))
    c.vline(x0 + 3, dtop + 5, FY, hx('#2a2f34'), 0.8)
    c.vline(x1 - 4, dtop + 5, FY, hx('#0b0c0e'), 0.8)
    # door head + jambs
    c.box(x0 - 3, dtop, x1 + 3, dtop + 5, hx('#3b4146') if style != 'wood' else hx('#4a3d31'), outline=OUT, hl=.2)
    c.box(x0 - 3, dtop, x0, FY, hx('#30363b'), outline=None)
    c.box(x1, dtop, x1 + 3, FY, hx('#30363b'), outline=None)
    # threshold
    c.box(x0 - 6, FY - 2, x1 + 6, FY + 1, hx('#5d646a') if style != 'wood' else BRASS, outline=OUT)
    # open door leaf seen edge-on
    lx = x1 + 3 if door_side == 'R' else x0 - 9
    leaf = hx('#3e454b') if style == 'steel' else (hx('#4d3f32') if style == 'wood' else hx('#4a5258'))
    c.box(lx, dtop + 4, lx + 6, FY - 3, leaf, outline=OUT, hl=.2)
    hx_ = lx + (6 if door_side == 'R' else -4)
    c.box(hx_, dtop + 104, hx_ + 4, dtop + 108, BRASS if style == 'wood' else hx('#8a9196'), outline=OUT)
    if style == 'steel':
        c.rect(lx + 1, dtop + 40, lx + 5, dtop + 70, hx('#2a2f34'))
