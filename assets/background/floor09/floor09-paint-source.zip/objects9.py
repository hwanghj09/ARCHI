import random, math
import numpy as np
from PIL import Image, ImageDraw
from lib import *
from objects import *

CHAR = hx('#2e2a2c')
WINE = hx('#5a2a36')
WINE_L = hx('#7a4a58')
WALNUT = hx('#4a3428')
WALNUT_L = hx('#6a4a36')
BRASS9 = hx('#8a7650')


# ============================================================ walls & ceilings
def walnut_wainscot(c, x0, x1, y0, y1):
    c.vgrad(x0, y0, x1, y1, WALNUT, dk(WALNUT, .25))
    for x in np.arange(x0, x1, 92):
        c.rect(x + 6, y0 + 6, min(x + 86, x1 - 6), y1 - 6, None, dk(WALNUT, .35), 0.8)
        c.vline(x + 7, y0 + 7, y1 - 7, lit(WALNUT, .1), 0.5)
    c.box(x0, y0 - 4, x1, y0, WALNUT_L, outline=OUT, hl=.25)


def cove_ceiling(c, x0, x1, cl, step_h=10):
    """stepped plaster ceiling with a dark cove slot (indirect light off)"""
    c.box(x0, cl - 16, x1, cl - step_h, hx('#3a3436'), outline=OUT, hl=.08)
    c.rect(x0 + 20, cl - step_h, x1 - 20, cl - step_h + 2, hx('#141012'))
    c.box(x0 + 22, cl - step_h + 2, x1 - 22, cl, hx('#423c3e'), outline=OUT, hl=.08)
    for x in np.arange(x0 + 70, x1 - 40, 140):
        c.rect(x - 6, cl - 1, x + 6, cl + 1.2, hx('#1b1719'))
        c.rect(x - 4, cl + 1.2, x + 4, cl + 2, hx('#5a5254'))


def linear_pendant_pair(c, x, y, w=160, top=212):
    for dx in (14, w - 14):
        c.vline(x + dx, top, y, hx('#4a4446'), 0.5)
    c.box(x, y, x + w, y + 6, hx('#2a2628'), outline=OUT, hl=.15)
    c.rect(x + 3, y + 5, x + w - 3, y + 6.6, hx('#55505a'))


def track_light(c, x0, x1, y, heads, top=212):
    for x in (x0 + 30, x1 - 30):
        c.vline(x, top, y, hx('#3a3638'), 0.6)
    c.box(x0, y, x1, y + 4, hx('#1d1a1c'), outline=OUT, hl=.2)
    for hx_, aim in heads:
        c.rect(hx_ - 1, y + 4, hx_ + 1, y + 10, hx('#3a3638'))
        pts = [(hx_ - 5, y + 10), (hx_ + 5, y + 10), (hx_ + 5 + 8 * aim, y + 26), (hx_ - 5 + 8 * aim, y + 26)]
        c.poly(pts, hx('#141214'), OUT)


# ============================================================ window with wooden venetian blinds
def wood_blind_window(c, x0, y0, x1, y1, seed=0, city_fn=None):
    rng = random.Random(seed)
    city_fn(x0, y0, x1, y1, seed=seed)
    tdraw(c, (x0, y0, x1, y1), lambda od, ox, oy: od.rectangle([P(x0) + ox, P(y0) + oy, P(x1) + ox, P(y1) + oy], fill=(46, 40, 44, 40)))
    mulls = list(np.arange(x0, x1 + 1, (x1 - x0) / 3))
    for i in range(len(mulls) - 1):
        a, b = mulls[i] + 4, mulls[i + 1] - 4
        drop = [y1 - y0 - 6, (y1 - y0) * 0.55, y1 - y0 - 6][i]
        c.box(a - 2, y0 + 2, b + 2, y0 + 8, hx('#3a2a22'), outline=OUT, hl=.2)   # head rail
        n = int(drop / 7)
        for k in range(n):
            yy = y0 + 9 + k * 7
            tilt = 3.2 if not (i == 2 and 6 <= k <= 9) else 1.4                # a few slats twisted open
            col = mix(WALNUT_L, WALNUT, k / max(1, n))
            c.rect(a, yy, b, yy + tilt, col)
            c.hline(a, b, yy, lit(col, .15), 0.5)
            if i == 2 and k == 12:                                               # one slat snapped and hanging
                c.poly([(a + 30, yy), (b - 40, yy), (b - 10, yy + 18), (b - 18, yy + 20), (a + 60, yy + 4)], col, OUT)
        c.box(a - 1, y0 + 9 + n * 7, b + 1, y0 + 12 + n * 7, hx('#3a2a22'), outline=OUT)
        for lx in (a + 20, b - 20):                                              # ladder cords
            c.vline(lx, y0 + 8, y0 + 9 + n * 7, hx('#2a2220'), 0.4)
    for m in mulls[1:-1]:
        c.box(m - 3, y0, m + 3, y1, hx('#2a2628'), outline=None, hl=.15)
    c.rect(x0 - 4, y0 - 4, x1 + 4, y0, hx('#2a2628'))
    c.rect(x0 - 4, y0 - 4, x0, y1, hx('#2a2628')); c.rect(x1, y0 - 4, x1 + 4, y1, hx('#2a2628'))
    c.box(x0 - 8, y1, x1 + 8, y1 + 6, WALNUT_L, outline=OUT, hl=.2)
    c.glow_rect(x0, y0, x1, y1, hx('#4a5a70'), 0.14, blur=24)


# ============================================================ business office
def business_desk(c, x0, x1, top_y, seed=0):
    rng = random.Random(seed)
    # low walnut screen at the back
    c.box(x0 + 6, top_y - 26, x1 - 6, top_y, WALNUT, outline=OUT, hl=.2, sh=.3)
    c.hline(x0 + 6, x1 - 6, top_y - 26, WALNUT_L, 1)
    desk(c, x0, x1, top_y, peds=('L', 'R'), seed=seed, col=hx('#5a4436'))
    return [x0 + (x1 - x0) * 0.27, x0 + (x1 - x0) * 0.73]


def seal_and_pad(c, x, desk_y):
    """Korean company seal with its red ink pad, next to a signed contract"""
    c.box(x, desk_y - 4, x + 16, desk_y, hx('#2a2022'), outline=OUT)
    c.rect(x + 2, desk_y - 4.6, x + 14, desk_y - 3.6, hx('#8a2a26'))
    c.box(x + 20, desk_y - 14, x + 26, desk_y, hx('#6a4a36'), outline=OUT, hl=.2)   # seal standing up
    c.rect(x + 20, desk_y - 2, x + 26, desk_y, hx('#8a2a26'))


def contract_stack(c, x0, x1, desk_y, n=10, seed=0):
    y = papers(c, x0, x1, desk_y, n, seed=seed)
    c.ell(x1 - 9, y - 3.5, x1 - 3, y + 0.5, None, hx('#8a2a26'), 0.7)          # seal impression on top sheet
    c.rect(x0 + 2, y - 1, x0 + 6, desk_y, hx('#2f4766'))                        # blue folder spine
    return y


def tabbed_folders(c, x, desk_y, n=5, seed=0):
    rng = random.Random(seed)
    for k in range(n):
        col = rng.choice([hx('#5a3a36'), hx('#3a4a5a'), hx('#4a5a3a'), hx('#6a5a36')])
        c.box(x + k * 2, desk_y - 4 - k * 2.4, x + 30 + k * 2, desk_y - k * 2.4, col, outline=OUT)
        c.rect(x + 22 + k * 2 - (k % 3) * 6, desk_y - 6 - k * 2.4, x + 28 + k * 2 - (k % 3) * 6, desk_y - 4 - k * 2.4, dk(col, -.2))


def calculator(c, x, desk_y):
    c.poly([(x, desk_y), (x + 18, desk_y), (x + 16, desk_y - 4), (x + 2, desk_y - 4)], hx('#2a2a2c'), OUT)
    c.rect(x + 4, desk_y - 4, x + 12, desk_y - 3, hx('#5a6a5a'))


def card_holder(c, x, desk_y):
    c.box(x, desk_y - 6, x + 12, desk_y, hx('#3a3a3c'), outline=OUT)
    c.rect(x + 2, desk_y - 9, x + 10, desk_y - 6, hx('#8a8c86'))


def plaque_cabinet(c, x, w=110, h=180):
    """glass display cabinet packed with award plaques; the newest one is cleaner and different"""
    top = FY - h
    c.occlude(x - 3, top, x + w + 3, FY, 115, blur=5); c.apply_shade_now()
    c.box(x, top, x + w, FY - 2, hx('#2a2022'), outline=OUT, hl=.1)
    c.rect(x + 5, top + 5, x + w - 5, FY - 34, hx('#141012'))
    shelves = 4
    sh = (FY - 34 - top - 10) / shelves
    rng = random.Random(3)
    for k in range(shelves):
        sy = top + 5 + (k + 1) * sh
        c.rect(x + 5, sy - 2, x + w - 5, sy, hx('#5a6266'))
        xx = x + 9
        j = 0
        while xx < x + w - 22:
            pw = rng.uniform(16, 22); ph = sh * rng.uniform(.62, .82)
            newest = (k == 0 and xx + pw > x + w - 32)
            body = hx('#151618') if newest else rng.choice([WALNUT, hx('#3a2a22'), hx('#4a3a2a')])
            plate = hx('#9aa0a4') if newest else BRASS9
            c.poly([(xx, sy - 2), (xx + pw, sy - 2), (xx + pw + 3, sy - ph), (xx + 3, sy - ph)], body, OUT)
            c.rect(xx + 4, sy - ph + 5, xx + pw - 1, sy - ph * 0.45, dk(plate, .15))
            if newest:
                c.glow_rect(xx, sy - ph, xx + pw + 3, sy - 2, hx('#9aa6ac'), 0.18, blur=4)
            xx += pw + 3; j += 1
    tdraw(c, (x + 5, top + 5, x + w - 5, FY - 34), lambda od, ox, oy: od.rectangle([P(x + 5) + ox, P(top + 5) + oy, P(x + w - 5) + ox, P(FY - 34) + oy], fill=(80, 90, 96, 34)))
    reflection(c, x + 5, top + 5, x + w - 5, FY - 34, 22, 0.15, 0.25)
    c.vline(x + w / 2, top + 5, FY - 34, hx('#3a3436'), 0.8)
    c.rect(x + 5, FY - 30, x + w - 5, FY - 6, None, hx('#3a2e2e'), 0.6)


def framed_painting(c, x0, y0, x1, y1, seed=0):
    rng = random.Random(seed)
    c.occlude(x0 + 2, y0 + 3, x1 + 3, y1 + 5, 90, blur=4); c.apply_shade_now()
    c.box(x0 - 4, y0 - 4, x1 + 4, y1 + 4, hx('#1d1719'), outline=OUT, hl=.2)
    c.vgrad(x0, y0, x1, y1, hx('#3a4048'), hx('#2a2c2a'))
    # abstract mountain-and-river landscape
    c.poly([(x0, y1 - 20), (x0 + 40, y0 + 24), (x0 + 70, y0 + 40), (x0 + 110, y0 + 14), (x1, y0 + 36), (x1, y1 - 20)], hx('#2c3236'))
    c.poly([(x0, y1 - 14), (x0 + 60, y0 + 46), (x0 + 120, y1 - 26), (x1, y0 + 50), (x1, y1 - 14)], hx('#22282a'))
    c.rect(x0, y1 - 14, x1, y1, hx('#3a4248'))
    c.ell(x1 - 34, y0 + 10, x1 - 22, y0 + 22, hx('#7a6a4a'))


def credenza9(c, x0, x1, h=74):
    top = FY - h
    c.occlude(x0 - 3, top, x1 + 3, FY, 100, blur=4); c.apply_shade_now()
    c.box(x0, top, x1, FY - 4, WALNUT, outline=OUT, hl=.08)
    n = max(2, int((x1 - x0) / 60))
    dw = (x1 - x0 - 8) / n
    for k in range(n):
        dx = x0 + 4 + k * dw
        c.rect(dx, top + 6, dx + dw - 3, FY - 10, None, dk(WALNUT, .35), 0.6)
        c.box(dx + dw / 2 - 6, top + 14, dx + dw / 2 + 4, top + 16, BRASS9, outline=None)
    c.box(x0 - 2, top - 3, x1 + 2, top, WALNUT_L, outline=OUT, hl=.2)
    c.rect(x0 + 3, FY - 4, x0 + 8, FY, OUT); c.rect(x1 - 8, FY - 4, x1 - 3, FY, OUT)
    return top - 3


def planter_box(c, x0, x1, h=50, seed=0):
    rng = random.Random(seed)
    top = FY - h
    c.occlude(x0 - 2, top, x1 + 2, FY, 100, blur=4)
    for k in range(26):
        bx = rng.uniform(x0 + 10, x1 - 10)
        L = rng.uniform(30, 90)
        a = -math.pi / 2 + rng.uniform(-0.35, 0.35)
        ex, ey = bx + math.cos(a) * L * 0.4, top + math.sin(a) * L
        c.line([(bx, top), (ex, ey)], hx('#1e2a1e'), 1)
        for j in range(3):
            lx, ly = bx + (ex - bx) * (0.45 + j * 0.27), top + (ey - top) * (0.45 + j * 0.27)
            s = 1 if (k + j) % 2 else -1
            c.poly([(lx, ly), (lx + 11 * s, ly - 3), (lx + 14 * s, ly + 3), (lx + 3 * s, ly + 4)], hx('#263224') if (k + j) % 3 else hx('#344030'), OUT)
    c.box(x0, top, x1, FY, hx('#2a2628'), outline=OUT, hl=.12)
    c.box(x0 - 2, top - 3, x1 + 2, top, WALNUT_L, outline=OUT, hl=.2)


# ============================================================ sales & customer management
def korea_map(c, x0, y0, x1, y1):
    """framed map of the peninsula with customer pins and threads (no lettering)"""
    c.occlude(x0 + 2, y0 + 3, x1 + 3, y1 + 5, 90, blur=4); c.apply_shade_now()
    c.box(x0 - 4, y0 - 4, x1 + 4, y1 + 4, hx('#1d1719'), outline=OUT, hl=.2)
    c.vgrad(x0, y0, x1, y1, hx('#3a4a52'), hx('#2e3c44'))                    # sea
    w, h = x1 - x0, y1 - y0
    pts = [(0.16, 0.06), (0.30, 0.02), (0.46, 0.05), (0.60, 0.01), (0.78, 0.00), (0.74, 0.08), (0.64, 0.16),
           (0.66, 0.24), (0.72, 0.34), (0.76, 0.46), (0.80, 0.58), (0.83, 0.70), (0.82, 0.80), (0.76, 0.86),
           (0.66, 0.88), (0.56, 0.86), (0.48, 0.90), (0.40, 0.88), (0.34, 0.84), (0.36, 0.78), (0.30, 0.72),
           (0.34, 0.66), (0.30, 0.60), (0.36, 0.54), (0.32, 0.48), (0.38, 0.44), (0.30, 0.40), (0.24, 0.38),
           (0.20, 0.34), (0.28, 0.30), (0.26, 0.24), (0.18, 0.20), (0.12, 0.14)]
    land = [(x0 + px * w, y0 + py * h) for px, py in pts]
    c.poly(land, hx('#6e7064'), OUT)
    c.ell(x0 + 0.34 * w, y0 + 0.95 * h - 3, x0 + 0.46 * w, y0 + 0.95 * h + 3, hx('#6e7064'), OUT, 0.5)   # island
    c.ell(x0 + 0.86 * w, y0 + 0.40 * h, x0 + 0.89 * w, y0 + 0.42 * h, hx('#6e7064'))
    pins = [(0.42, 0.45), (0.52, 0.52), (0.64, 0.62), (0.74, 0.78), (0.54, 0.80), (0.44, 0.70), (0.40, 0.48)]
    for k, (px, py) in enumerate(pins):
        X, Y = x0 + px * w, y0 + py * h
        col = hx('#8a3a33') if k else hx('#2f4766')
        c.line([(X, Y), (x0 + 0.42 * w, y0 + 0.45 * h)], hx('#8a3a33'), 0.5)     # every thread runs back to HQ
        c.ell(X - 2, Y - 2, X + 2, Y + 2, col, OUT, 0.4)


def customer_board(c, x0, y0, x1, y1, seed=0):
    """magnetic customer status board: name cards in columns + a usage chart where one bar dwarfs the rest"""
    rng = random.Random(seed)
    c.occlude(x0 + 2, y0 + 3, x1 + 3, y1 + 5, 90, blur=4); c.apply_shade_now()
    c.rect(x0, y0, x1, y1, hx('#4f5458'))
    c.vgrad(x0 + 3, y0 + 3, x1 - 3, y1 - 3, hx('#6c7174'), hx('#5c6164'))
    cw = (x1 - x0) * 0.55 / 3
    for k in range(3):
        cx0 = x0 + 8 + k * cw
        c.rect(cx0, y0 + 8, cx0 + cw - 6, y0 + 14, WINE)
        for j in range(rng.randint(4, 7)):
            c.rect(cx0, y0 + 18 + j * 10, cx0 + cw - 6, y0 + 25 + j * 10, hx('#7f827d'))
            c.ell(cx0 + cw - 12, y0 + 19 + j * 10, cx0 + cw - 7, y0 + 24 + j * 10, rng.choice([hx('#2f4766'), hx('#8a3a33'), hx('#5a6a3a')]))
    # printed usage chart
    px0 = x0 + (x1 - x0) * 0.6; px1 = x1 - 8
    c.box(px0, y0 + 8, px1, y1 - 10, hx('#7f827d'), outline=OUT, hl=.02)
    base = y1 - 16
    n = 9
    bw = (px1 - px0 - 10) / n
    for k in range(n):
        bh = (base - y0 - 22) * (0.92 if k == 0 else rng.uniform(0.08, 0.22))
        c.rect(px0 + 5 + k * bw, base - bh, px0 + 5 + (k + 0.7) * bw, base, hx('#8a3a33') if k == 0 else hx('#4f5458'))
    c.ell(px0 + 2, y0 + 10, px0 + 5 + 0.9 * bw, base + 3, None, hx('#2f4766'), 0.6)
    c.rect(x0, y0, x1, y1, None, hx('#7a8186'), 1); c.rect(x0, y0, x1, y1, None, OUT, 0.5)


def sales_station(c, cx, top_y, seed=0, msg=False):
    rng = random.Random(seed)
    monitor(c, cx - 22, top_y, 46, 28, 'off', seed=seed, notes=rng.choice([0, 1, 2]))
    monitor(c, cx + 26, top_y, 46, 28, 'off', seed=seed + 1)
    keyboard(c, cx, top_y, 32)
    desk_phone9(c, cx + 64, top_y, msg)
    # headset hanging off the monitor edge
    c.ell(cx + 42, top_y - 46, cx + 56, top_y - 32, None, hx('#16191c'), 1.3)
    c.rrect(cx + 52, top_y - 38, cx + 57, top_y - 31, 2, hx('#16191c'))
    tabbed_folders(c, cx - 70, top_y, rng.randint(2, 5), seed=seed)
    if rng.random() < 0.6:
        card_holder(c, cx - 36, top_y)
    if rng.random() < 0.5:
        mug(c, cx - 44, top_y, rng.choice([hx('#56606a'), hx('#6f5048')]))


def desk_phone9(c, x, desk_y, msg=False):
    c.poly([(x - 13, desk_y), (x + 13, desk_y), (x + 9, desk_y - 9), (x - 11, desk_y - 7)], hx('#1f1d1f'), OUT)
    c.rrect(x - 13, desk_y - 12, x + 5, desk_y - 8, 2, hx('#252224'), OUT, 0.6)
    c.bezier((x - 13, desk_y - 10), (x - 22, desk_y + 4), (x - 16, desk_y - 1), hx('#121012'), 0.6)
    if msg:
        led(c, x + 8, desk_y - 6, RED, 0.7, 0.8)


def mfp(c, x, w=84):
    """floor-standing multifunction printer with a fax handset and paper trays"""
    top = FY - 116
    c.occlude(x - 3, top, x + w + 3, FY, 110, blur=4); c.apply_shade_now()
    c.box(x, top + 26, x + w, FY - 2, hx('#4a4c4e'), outline=OUT, hl=.08, sh=.3)
    for k in range(3):
        yy = top + 46 + k * 22
        c.rect(x + 4, yy, x + w - 4, yy + 18, None, hx('#353739'), 0.6)
        c.box(x + w / 2 - 12, yy + 7, x + w / 2 + 12, yy + 10, hx('#2a2c2e'), outline=None)
    c.box(x - 4, top + 6, x + w + 4, top + 26, hx('#5a5c5e'), outline=OUT, hl=.12)
    c.box(x + 6, top, x + w - 6, top + 6, hx('#626466'), outline=OUT)                 # scanner lid
    c.rect(x + 8, top + 12, x + 44, top + 16, hx('#2a2c2e'))
    c.box(x + w - 30, top + 9, x + w - 6, top + 22, hx('#1b1d1f'), outline=OUT)     # panel
    c.rect(x + w - 27, top + 11, x + w - 13, top + 17, hx('#0f1416'))
    # printed sheets left in the output tray
    c.poly([(x + 10, top + 24), (x + 44, top + 23), (x + 46, top + 26), (x + 12, top + 27)], hx('#8a8c86'), OUT)
    c.rect(x + 2, FY - 2, x + 8, FY, OUT); c.rect(x + w - 8, FY - 2, x + w - 2, FY, OUT)


def veneer_files(c, x0, w=86, h=132, seed=0, ledger=False):
    top = FY - h
    c.occlude(x0 - 3, top, x0 + w + 3, FY, 110, blur=4); c.apply_shade_now()
    c.box(x0, top, x0 + w, FY - 2, hx('#4a3a30'), outline=OUT, hl=.08, sh=.3)
    for k in range(4):
        yy = top + 4 + k * (h - 8) / 4
        c.rect(x0 + 4, yy, x0 + w - 4, yy + (h - 8) / 4 - 3, None, dk(hx('#4a3a30'), .35), 0.6)
        c.box(x0 + w / 2 - 12, yy + 8, x0 + w / 2 + 12, yy + 11, BRASS9, outline=None)
        c.rect(x0 + 10, yy + 6, x0 + 24, yy + 12, dk(PAPER, .15))                   # blank index card
    c.box(x0 - 2, top - 3, x0 + w + 2, top, WALNUT_L, outline=OUT, hl=.2)
    if ledger:
        # licence ledger lying open: one column of identical automatic-approval stamps
        lx = x0 + 10
        c.poly([(lx, top - 3), (lx + 30, top - 6), (lx + 30, top - 3)], hx('#7f827d'))
        c.poly([(lx + 32, top - 6), (lx + 62, top - 3), (lx + 32, top - 3)], hx('#7f827d'))
        c.box(lx - 2, top - 3, lx + 64, top - 1, hx('#3a2a22'), outline=OUT)
        for k in range(5):
            c.ell(lx + 44 + k * 3.4, top - 6.2 + k * 0.5, lx + 47 + k * 3.4, top - 3.6 + k * 0.5, None, hx('#8a2a26'), 0.4)
    return top - 3


def fax_on_cabinet(c, x, top_y):
    c.poly([(x, top_y), (x + 44, top_y), (x + 40, top_y - 14), (x + 6, top_y - 12)], hx('#3a3c3e'), OUT)
    c.rrect(x + 4, top_y - 17, x + 22, top_y - 12, 2, hx('#252224'), OUT, 0.6)
    c.poly([(x + 12, top_y - 12), (x + 36, top_y - 12), (x + 32, top_y - 30), (x + 16, top_y - 30)], hx('#8a8c86'), OUT)   # curled fax paper
    led(c, x + 38, top_y - 8, GREEN, 0.45, 0.3)


def phone_system(c, x, y):
    """wall-mounted key-telephone system unit with line lamps"""
    c.box(x, y, x + 40, y + 52, hx('#3a3c3e'), outline=OUT, hl=.1)
    for r in range(4):
        for k in range(4):
            col = hx('#8a3a33') if (r, k) in ((0, 2), (2, 1)) else hx('#202224')
            c.rect(x + 6 + k * 8, y + 8 + r * 9, x + 11 + k * 8, y + 12 + r * 9, col)
    for k in range(3):
        c.bezier((x + 10 + k * 10, y + 52), (x + 6 + k * 10, y + 90), (x + k * 8, FY - 1), hx('#1d1b1d'), 0.9)


def brochure_rack(c, x, y):
    c.box(x, y, x + 40, y + 74, hx('#2a2628'), outline=OUT, hl=.1)
    for r in range(3):
        yy = y + 6 + r * 22
        c.rect(x + 3, yy + 14, x + 37, yy + 17, hx('#5a5e60'))
        for k in range(2):
            col = [WINE, hx('#3a4a5a'), hx('#5a5a3a')][(r + k) % 3]
            c.poly([(x + 5 + k * 17, yy + 15), (x + 18 + k * 17, yy + 15), (x + 19 + k * 17, yy), (x + 6 + k * 17, yy + 1)], col, OUT)


# ============================================================ project room
def gantt_board(c, x0, y0, x1, y1, seed=0):
    """magnetic project board: swim lanes of coloured bars, a today line, red magnets at the far right"""
    rng = random.Random(seed)
    c.occlude(x0 + 2, y0 + 3, x1 + 3, y1 + 5, 90, blur=4); c.apply_shade_now()
    c.rect(x0, y0, x1, y1, hx('#4f5458'))
    c.vgrad(x0 + 3, y0 + 3, x1 - 3, y1 - 3, hx('#6c7174'), hx('#5a5f62'))
    gx0 = x0 + 40
    for k in range(13):
        c.vline(gx0 + (x1 - 10 - gx0) * k / 12, y0 + 8, y1 - 8, hx('#5a5f62'), 0.5)
    lanes = 7
    lh = (y1 - y0 - 20) / lanes
    cols = [hx('#3f5a6a'), hx('#4a5a4a'), hx('#5a5040'), WINE, hx('#3f5a6a'), hx('#5a4a5a'), hx('#4a5a4a')]
    for r in range(lanes):
        ly = y0 + 12 + r * lh
        c.rect(x0 + 6, ly, x0 + 34, ly + lh - 4, hx('#7f827d'))
        a = rng.uniform(0, 0.5); b = a + rng.uniform(0.2, 0.45)
        c.rect(gx0 + (x1 - 10 - gx0) * a, ly + 2, gx0 + (x1 - 10 - gx0) * min(b, 0.98), ly + lh - 6, cols[r])
    tx = gx0 + (x1 - 10 - gx0) * 0.62
    c.vline(tx, y0 + 6, y1 - 6, hx('#8a3a33'), 1)
    for k in range(4):
        c.ell(x1 - 18, y0 + 14 + k * 12, x1 - 10, y0 + 22 + k * 12, hx('#8a3a33'), OUT, 0.4)
    c.rect(x0, y0, x1, y1, None, hx('#7a8186'), 1); c.rect(x0, y0, x1, y1, None, OUT, 0.5)
    c.box(x0 + 6, y1, x1 - 6, y1 + 4, hx('#5e666c'), outline=OUT)


def proposal_wall(c, x0, y0, x1, y1, seed=0):
    rng = random.Random(seed)
    c.occlude(x0 + 2, y0 + 3, x1 + 3, y1 + 5, 80, blur=3); c.apply_shade_now()
    c.box(x0, y0, x1, y1, hx('#3a2a2e'), outline=OUT, hl=.03)
    sw = (x1 - x0 - 12) / 2
    for k in range(4):
        px = x0 + 4 + (k % 2) * (sw + 4); py = y0 + 4 + (k // 2) * ((y1 - y0 - 8) / 2)
        ph = (y1 - y0 - 12) / 2
        c.box(px, py, px + sw, py + ph, hx('#7f827d'), outline=OUT, hl=.02)
        c.rect(px + 3, py + 3, px + sw - 3, py + 9, WINE)
        for ln in range(5):
            c.hline(px + 4, px + 4 + rng.uniform(sw * .4, sw - 8), py + 14 + ln * 4.5, hx('#4f5458'), 0.5)
        c.ell(px + sw / 2 - 1.5, py - 1, px + sw / 2 + 1.5, py + 2, BRASS9)


def booking_panel(c, x, y):
    """room-booking panel beside the door, still on battery: one block lit at three in the morning"""
    c.box(x, y, x + 22, y + 30, hx('#1d1b1d'), outline=OUT, hl=.12)
    c.rect(x + 2, y + 2, x + 20, y + 24, hx('#0e1214'))
    for k in range(12):
        c.hline(x + 4, x + 18, y + 4 + k * 1.7, hx('#1d2226'), 0.4)
    c.rect(x + 4, y + 4 + 3 * 1.7, x + 18, y + 4 + 4 * 1.7, hx('#c96a5a'))
    c.glow_rect(x + 2, y + 2, x + 20, y + 24, hx('#8aa0b0'), 0.25, blur=4)
    led(c, x + 11, y + 27, RED, 0.6, 0.6)


def tripod_cam(c, x, facing=-1):
    head_y = FY - 128
    f = facing
    c.occlude(x - 30, FY - 4, x + 30, FY + 1, 100, blur=3, ellipse=True)
    for dx in (-26, 26):
        c.line([(x, head_y + 10), (x + dx, FY)], hx('#3a3638'), 1.6)
    c.line([(x, head_y + 10), (x + 2, FY)], hx('#2a2628'), 1.2)
    c.box(x - 7, head_y + 2, x + 7, head_y + 12, hx('#2a2628'), outline=OUT)
    bx0, bx1 = (x - 16, x + 16)
    c.box(bx0, head_y - 18, bx1, head_y + 2, hx('#1d1b1e'), outline=OUT, hl=.12)
    lx0 = bx0 - 22 if f < 0 else bx1
    c.box(lx0, head_y - 14, lx0 + 22, head_y - 2, hx('#24222a'), outline=OUT, hl=.15)
    led(c, (lx0 + 3) if f < 0 else (lx0 + 19), head_y - 17, RED, 0.9, 0.9)
    c.glow_ell((lx0 + 3) if f < 0 else (lx0 + 19), head_y - 17, 12, 9, RED, 0.35, blur=7)


def ptz_camera(c, x, y):
    c.vline(x, 212, y, hx('#3a3638'), 0.8)
    c.box(x - 10, y, x + 10, y + 4, hx('#4a4446'), outline=OUT)
    c.ell(x - 8, y + 3, x + 8, y + 17, hx('#1c1a1c'), OUT, 0.8)
    c.ell(x - 4, y + 8, x + 2, y + 14, hx('#2a3238'), OUT, 0.4)
    led(c, x + 5, y + 7, RED, 0.6, 0.7)


def leather_chair(c, cx, col=hx('#211a1c')):
    chair_back(c, cx, col=col)
    c.hline(cx - 18, cx + 18, FY - 42 - 44, lit(col, .15), 0.8)
