import random, math, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageChops
from lib import *
from objects import *
from objects5 import conf_phone
from objects9 import *

X0, X1 = 48, 3152
IX0, IX1 = 78, 3122
TS0, TS1 = 180, 212
FB = 626
OF = (IX0, 1200); COL = (1200, 1236)
SA = (1236, 2300); GP = (2300, 2318)
PR = (2318, IX1)
OCL, SCL = 300, 296

c = Canvas()
exec(open('reuse.py').read().split('\n', 4)[4], globals())


def hatch(x0, y0, x1, y1, col=hx('#3f383b'), step=9):
    def f(od, ox, oy):
        for k in range(int(-(y1 - y0)), int(x1 - x0), step):
            od.line([(P(x0 + k) + ox, P(y1) + oy), (P(x0 + k + (y1 - y0)) + ox, P(y0) + oy)], fill=wa(col, 70), width=P(0.8))
    tdraw(c, (x0, y0, x1, y1), f)


# ------------------------------------------------------------------ shell
def shell():
    c.vgrad(IX0, TS1, IX1, 300, hx('#120e10'), hx('#1a1517'))
    c.vgrad(OF[0], OCL, OF[1], FY, dk(CHAR, .2), CHAR)
    c.vgrad(SA[0], SCL, SA[1], FY, dk(CHAR, .2), CHAR)
    c.vgrad(GP[0], TS1, PR[1], FY, hx('#1d181a'), hx('#252022'))
    for x in np.arange(SA[0] + 120, SA[1], 180):
        c.vline(x, SCL, FY, dk(CHAR, .25), 0.8)
    walnut_wainscot(c, OF[0], OF[1], 474, FY - 9)
    c.box(SA[0], 474, SA[1], 478, WINE, outline=OUT, hl=.25)
    c.vgrad(SA[0], 478, SA[1], FY, dk(CHAR, .3), dk(CHAR, .42))
    c.box(PR[0], 474, PR[1], 478, WINE, outline=OUT, hl=.25)
    for (a0, a1) in (OF, SA, PR):
        c.box(a0, FY - 9, a1, FY, hx('#1a1416'), outline=None)
        c.hline(a0, a1, FY - 9, hx('#2e2628'), 0.6)
    # column
    cc = hx('#3a3436')
    c.box(COL[0], TS1, COL[1], FY, cc, outline=OUT, hl=.06, sh=.35)
    c.vline(COL[0] + 3, TS1, FY, lit(cc, .15), 0.8)
    c.box(COL[0], 474, COL[1], 478, WINE, outline=OUT, hl=.25)
    # wine carpet (section band)
    c.rect(IX0, FY, IX1, FY + 7, hx('#1d1116'))
    for k, x in enumerate(np.arange(IX0, IX1, 40)):
        c.rect(x, FY, min(x + 40, IX1), FY + 6, hx('#22141a') if k % 2 else hx('#1d1116'))
    c.rect(PR[0], FY, PR[1], FY + 6, hx('#1a0f13'))
    c.hline(IX0, IX1, FY, hx('#7a4a58'), 0.8)
    # slab + section cuts
    c.vgrad(X0, FY + 7, X1, FB, hx('#252022'), hx('#1a1618'))
    for x in (COL[0] - 12, GP[0] - 22):
        c.vgrad(x, FB - 2, x + 60, FB + 14, hx('#211c1e'), hx('#171314'))
        c.rect(x, FB - 2, x + 60, FB + 14, None, OUT, 1)
    c.vgrad(X0, TS0, X1, TS1, hx('#2b2729'), hx('#1e1a1c'))
    c.vgrad(X0, TS0, IX0, FB, hx('#2a2628'), hx('#1e1a1c'))
    c.vgrad(IX1, TS0, X1, FB, hx('#2a2628'), hx('#1e1a1c'))
    for a in ((X0, TS0, X1, TS1), (X0, FY + 7, X1, FB), (X0, TS0, IX0, FB), (IX1, TS0, X1, FB)):
        hatch(*a)
    c.hline(X0, X1, TS0, hx('#504a4c'), 1)
    c.hline(IX0, IX1, TS1, hx('#0d0b0c'), 1)
    c.vline(IX0 - 1, TS1, FY, hx('#2e2a2c'), 1)
    c.vline(IX1, TS1, FY, hx('#0e0c0d'), 1)
    c.hline(X0, X1, FB - 1, hx('#2e2a2c'), 1)


def ceilings():
    c.box(IX0, 220, IX1, 238, hx('#35302f'), outline=OUT, hl=.12, sh=.35)
    for x in range(int(IX0) + 80, int(IX1), 120):
        c.box(x, 219, x + 3, 239, hx('#413b3a'), outline=None, hl=.1)
    c.box(IX0, 244, IX1, 247.5, hx('#5a3a36'), outline=OUT, hl=.15)
    rng = random.Random(4)
    c.rect(IX0 + 10, 258, IX1 - 10, 260, hx('#4a4446'))
    c.rect(IX0 + 10, 266, IX1 - 10, 267.5, hx('#3a3436'))
    for x in np.arange(IX0 + 10, IX1 - 10, 14):
        c.vline(x, 258, 267.5, hx('#403a3c'), 0.6)
    for k in range(14):
        xx = rng.uniform(IX0 + 30, IX1 - 90)
        c.cable((xx, 264), (xx + rng.uniform(40, 90), 264), rng.uniform(2, 7), hx('#151213'), 0.9)
    cove_ceiling(c, OF[0], OF[1], OCL)
    c.box(SA[0], SCL - 8, SA[1], SCL, hx('#3a3436'), outline=OUT, hl=.08)
    for x in (1290, 1520, 1800, 2060):
        linear_pendant_pair(c, x, 324, 160, SCL)
    for x in range(int(IX0) + 110, int(IX1), 240):
        cl = OCL if x < COL[0] else (SCL if x < GP[0] else 290)
        c.rect(x - 0.8, 247.5, x + 0.8, cl + 3, hx('#5a3a36'))
        c.rect(x - 3, cl + 3, x + 3, cl + 4.5, hx('#8b8f91'))


# ------------------------------------------------------------------ business office
def office():
    TOP = FY - 69
    wood_blind_window(c, 104, 322, 760, 500, seed=91, city_fn=city)
    plaque_cabinet(c, 784, 110, 180)
    framed_painting(c, 924, 330, 1084, 420)
    ctop = credenza9(c, 912, 1180)
    binders(c, 924, ctop, 7, seed=5, h=28, lean_last=True)
    c.box(1000, ctop - 30, 1028, ctop, hx('#2a2628'), outline=OUT, hl=.12)        # coffee machine
    c.rect(1006, ctop - 24, 1022, ctop - 18, hx('#141012'))
    mug(c, 1040, ctop, hx('#6a5a50'))
    plant_small(c, 1150, ctop)
    rng = random.Random(7)
    for x0, x1, seed in ((110, 440, 1), (464, 770, 2)):
        cxs = business_desk(c, x0, x1, TOP, seed=seed)
        for i, cx in enumerate(cxs):
            laptop(c, cx - 24, TOP, 30, 'off', seed=seed * 10 + i, stand=True)
            monitor(c, cx + 20, TOP, 50, 30, 'off', seed=seed * 10 + i + 5, notes=rng.choice([0, 1]))
            keyboard(c, cx - 2, TOP, 32)
            desk_phone9(c, cx + 62, TOP, msg=(seed == 2 and i == 0))
            contract_stack(c, cx - 76, cx - 50, TOP, rng.randint(6, 14), seed=seed + i)
            if i == 0:
                seal_and_pad(c, cx - 46, TOP)
            else:
                calculator(c, cx - 46, TOP)
            tabbed_folders(c, cx + 46, TOP - 1, 3, seed=seed + i) if rng.random() < 0.0 else None
            if rng.random() < 0.6:
                card_holder(c, cx + 40, TOP)
            leather_chair(c, cx + 2)
        cable_to_floor(c, x0 + 80, TOP + 4, dx=-10)
    planter_box(c, 1150, 1290, 50, seed=2)


# ------------------------------------------------------------------ sales & customer management
def sales():
    TOP = FY - 69
    korea_map(c, 1262, 318, 1392, 458)
    customer_board(c, 1410, 320, 1690, 440, seed=4)
    brochure_rack(c, 1708, 350)
    phone_system(c, 2236, 330)
    for x0, x1, cxs, seed in ((1256, 1640, (1320, 1448, 1576), 1), (1764, 2010, (1830, 1950), 2)):
        c.box(x0 + 6, TOP - 30, x1 - 6, TOP, hx('#3e2028'), outline=OUT, hl=.12, sh=.3)      # wine fabric screen
        for xx in np.arange(x0 + 8, x1 - 6, 3):
            tline(c, [(xx, TOP - 28), (xx, TOP - 1)], hx('#2c161c'), 60, 0.4)
        desk(c, x0, x1, TOP, peds=('L', 'R'), seed=seed, col=hx('#5d5452'))
        for i, cx in enumerate(cxs):
            sales_station(c, cx, TOP, seed=seed * 10 + i, msg=(seed == 1 and i == 1))
            if not (seed == 2 and i == 1):
                leather_chair(c, cx + 2, col=hx('#241c1e'))
        if seed == 2:
            chair_side(c, cxs[1] + 40, facing=1, col=hx('#241c1e'))
        cable_to_floor(c, x0 + 60, TOP + 4, dx=-8)
    mfp(c, 1660, 84)
    t1 = veneer_files(c, 2026, 86, 132, seed=1)
    t2 = veneer_files(c, 2114, 86, 132, seed=2, ledger=True)
    t3 = veneer_files(c, 2202, 86, 132, seed=3)
    fax_on_cabinet(c, 2036, t1)
    binders(c, 2210, t3, 7, seed=33, h=26, lean_last=True)


# ------------------------------------------------------------------ project room
def glass_partition():
    x0, x1 = GP
    c.box(x0 - 4, TS1, x1 + 4, 300, hx('#2a2224'), outline=OUT, hl=.08)            # header
    tdraw(c, (x0, 300, x1, FY), lambda od, ox, oy: od.rectangle([P(x0) + ox, P(300) + oy, P(x1) + ox, P(FY) + oy], fill=(150, 165, 170, 46)))
    c.box(x0 - 2, 300, x0 + 2, FY, WALNUT_L, outline=None, hl=.2)                   # wood mullions
    c.box(x1 - 2, 300, x1 + 2, FY, WALNUT_L, outline=None, hl=.2)
    tdraw(c, (x0, 420, x1, 452), lambda od, ox, oy: od.rectangle([P(x0) + ox, P(420) + oy, P(x1) + ox, P(452) + oy], fill=(210, 210, 214, 60)))
    reflection(c, x0, 300, x1, FY, 40, 0.1, 0.6)
    c.box(x0 - 5, FY - 5, x1 + 5, FY, WALNUT_L, outline=OUT)
    c.box(x1 + 3, FY - 212, x1 + 8, FY - 4, hx('#8a9aa0'), outline=OUT)             # glass door, open, edge-on
    c.box(x1 + 8, FY - 120, x1 + 11, FY - 84, BRASS9, outline=OUT)
    booking_panel(c, x1 + 16, 416)
    ex = x0 - 54
    c.box(ex, 306, ex + 44, 322, hx('#1a2a1f'), outline=OUT)
    c.rect(ex + 2, 308, ex + 42, 320, hx('#2f6a45'))
    c.ell(ex + 27, 309.5, ex + 30, 312.5, hx('#cfe8d6'))
    c.line([(ex + 28, 313), (ex + 25, 317), (ex + 21, 319)], hx('#cfe8d6'), 0.9)
    c.line([(ex + 27, 314), (ex + 32, 316)], hx('#cfe8d6'), 0.8)
    c.line([(ex + 16, 314), (ex + 6, 314), (ex + 10, 311)], hx('#cfe8d6'), 0.8)
    c.glow_rect(ex, 306, ex + 44, 322, hx('#4fb57a'), 0.5, blur=14)


def project_room():
    TOP = FY - 69
    track_light(c, PR[0] + 10, PR[1] - 10, 290, [(2400, -1), (2500, -1), (2600, 1), (2700, 1), (2860, 1), (3000, -1)], top=TS1)
    gantt_board(c, 2342, 320, 2640, 450, seed=6)
    proposal_wall(c, 2656, 326, 2762, 440, seed=7)
    c.occlude(2782, 336, 2964, 434, 100, blur=4); c.apply_shade_now()
    c.rrect(2780, 332, 2962, 430, 1.5, hx('#0e0c0d'), OUT, 1)
    screen_content(c, 2783, 335, 2959, 427, 'off', seed=8)
    led(c, 2958, 428, RED, 0.45, 0.4)
    ptz_camera(c, 2870, 296)
    # walnut project table, leather chairs
    desk(c, 2400, 2980, TOP, peds=(), seed=5, col=hx('#5a4436'))
    c.box(2684, TOP + 4, 2696, FY, DESK_LEG, outline=OUT)
    c.box(2560, TOP + 4, 2830, TOP + 12, hx('#1d181a'), outline=OUT)
    rng = random.Random(12)
    for x, n in ((2460, 9), (2570, 14), (2780, 7), (2900, 11)):
        y = papers(c, x - 16, x + 16, TOP, n, seed=x)
    binders(c, 2620, TOP, 3, seed=61, h=24)
    laptop(c, 2700, TOP, 30, 'off', seed=62)
    laptop(c, 2850, TOP, 28, 'off', seed=63)
    conf_phone(c, 2740, TOP) if False else None
    c.rrect(2510, TOP - 2, 2532, TOP, 1, hx('#141214'), OUT, 0.4)                # tablet face down
    c.rect(2948, TOP - 2, 2958, TOP, hx('#2a2628'))                                # presentation clicker
    for x in (2520, 2760, 2950):
        mug(c, x, TOP, rng.choice([hx('#56606a'), hx('#6f5048')]))
    for x in (2460, 2580, 2800, 2910):
        leather_chair(c, x, col=hx('#211a1c'))
    chair_side(c, 2690, facing=1, col=hx('#211a1c'))
    tripod_cam(c, 3070, facing=-1)                                                # aimed at the seats, not the screen


def finalize():
    arr = np.asarray(c.img, np.float32)
    h, w = arr.shape[:2]
    ys = np.linspace(0, 1, h)[:, None]
    xs = np.linspace(0, 1, w)[None, :]
    yy = (ys * H - TS1) / (FY - TS1)
    v = 1.0 - 0.28 * np.clip(1 - yy * 1.5, 0, 1) ** 1.5
    v *= 1.0 - 0.10 * np.clip((yy - 0.75) * 4, 0, 1)
    edge = np.minimum(xs, 1 - xs) * W
    v = v * (0.74 + 0.26 * np.clip(edge / 420.0, 0, 1))
    arr[:, :, :3] *= v[:, :, None]
    sh = np.asarray(c.shade, np.float32)[:, :, None] / 255.0
    arr[:, :, :3] *= (1 - sh * 0.85)
    L = np.asarray(c.light, np.float32) / 255.0
    base = arr[:, :, :3] / 255.0
    out = 1 - (1 - base) * (1 - L)
    lum = (out * np.array([0.299, 0.587, 0.114])).sum(axis=2, keepdims=True)
    out = out * 0.80 + lum * 0.20
    out = out * np.array([1.0, 0.99, 1.0])
    out = np.clip(out, 0, 1) ** 0.92
    out = np.clip((out - 0.5) * 1.10 + 0.5, 0, 1)
    arr[:, :, :3] = out * 255
    img = Image.fromarray(np.rint(arr).clip(0, 255).astype(np.uint8), 'RGBA').resize((W, H), Image.LANCZOS)
    a = np.asarray(img, np.float32)
    rng = np.random.default_rng(9)
    g = (rng.random((H, W)) - 0.5) * 7
    low = Image.fromarray((rng.random((H // 6, W // 6)) * 255).astype(np.uint8), 'L').resize((W, H), Image.BICUBIC)
    low = (np.asarray(low, np.float32) / 255 - 0.5) * 0.07
    a[:, :, :3] = a[:, :, :3] * (1 + low[:, :, None]) + g[:, :, None]
    alpha = np.where(a[:, :, 3] > 127, 255, 0)
    a[:, :, 3] = alpha
    a[:, :, :3] *= (alpha[:, :, None] > 0)
    img = Image.fromarray(np.rint(a).clip(0, 255).astype(np.uint8), 'RGBA')
    m = img.getchannel('A')
    inner = m.filter(ImageFilter.MinFilter(5))
    img.paste(Image.new('RGBA', img.size, (10, 8, 9, 255)), (0, 0), ImageChops.subtract(m, inner))
    inner2 = m.filter(ImageFilter.MinFilter(9))
    img.paste(Image.new('RGBA', img.size, (92, 80, 86, 255)), (0, 0), ImageChops.subtract(inner, inner2).point(lambda v: 150 if v else 0))
    bb = img.getchannel('A').getbbox()
    M = 48
    img = img.crop((bb[0] - M, bb[1] - M, bb[2] + M, bb[3] + M))
    print('bbox', bb, 'floor line y in output =', FY - (bb[1] - M), 'size', img.size)
    return img


def build():
    shell()
    c.noise_tex(OF[0], OCL, SA[1], FY, 0.06, 28, seed=1, streaks=True)
    c.noise_tex(PR[0], TS1, PR[1], FY, 0.06, 26, seed=2, streaks=True)
    c.noise_tex(X0, TS0, X1, TS1, 0.08, 16, seed=4)
    c.noise_tex(X0, FY, X1, FB, 0.08, 16, seed=5)
    c.noise_tex(IX0, TS1, SA[1], 300, 0.08, 20, seed=6)
    for i, (x, y, w_, h_) in enumerate([(900, 330, 100, 120), (1700, 470, 140, 80), (2500, 470, 140, 80)]):
        c.stain(x, y, w_, h_, hx('#120e10'), alpha=36, blur=10, seed=i + 90)
    ceilings()
    c.occlude(IX0, TS1, IX1, TS1 + 10, 150, blur=10)
    c.occlude(IX0, FY - 6, IX1, FY, 120, blur=6)
    c.occlude(IX0, TS1, IX0 + 10, FY, 140, blur=14)
    c.occlude(IX1 - 10, TS1, IX1, FY, 140, blur=14)
    for (x0, x1) in (COL, GP):
        c.occlude(x0 - 14, TS1, x0, FY, 110, blur=10)
        c.occlude(x1, TS1, x1 + 14, FY, 110, blur=10)
    c.apply_shade_now()
    office()
    sales()
    glass_partition()
    project_room()
    for x, y in ((1180, OCL), (2280, SCL)):
        c.box(x - 9, y, x + 9, y + 3, hx('#4a4446'), outline=OUT)
        c.ell(x - 7, y - 2, x + 7, y + 11, hx('#1c1a1c'), OUT, 0.8)
        led(c, x + 2, y + 6, RED, 0.6, 0.6)
    return finalize()


if __name__ == '__main__':
    img = build()
    out = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/f9/floor09.png'
    img.save(out)
    print('saved', out)
