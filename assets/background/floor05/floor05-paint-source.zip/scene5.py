import random, math, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageChops
from lib import *
from objects import *
from objects5 import *

X0, X1 = 48, 3152
IX0, IX1 = 78, 3122
TS0, TS1 = 180, 212
FB = 626
CL = 312            # suspended ceiling underside (R1, R2)
CL3 = 318           # gypsum ceiling underside (R3)
R1 = (IX0, 1290); P1 = (1290, 1314)
R2 = (1314, 2236); P2 = (2236, 2260)
R3 = (2260, IX1)

WALL1 = hx('#3a3f44')
WALL3 = hx('#2f2a26')

c = Canvas()
import objects5, objects
exec(open('reuse.py').read().split('\n', 4)[4], globals())   # city(), blinds() bound to this canvas


def hatch(x0, y0, x1, y1, col=hx('#3a3f44'), step=9):
    def f(od, ox, oy):
        for k in range(int(-(y1 - y0)), int(x1 - x0), step):
            od.line([(P(x0 + k) + ox, P(y1) + oy), (P(x0 + k + (y1 - y0)) + ox, P(y0) + oy)], fill=wa(col, 70), width=P(0.8))
    tdraw(c, (x0, y0, x1, y1), f)


# ------------------------------------------------------------------ shell
def shell():
    # plenum (above suspended ceilings)
    c.vgrad(IX0, TS1, IX1, CL3, hx('#121416'), hx('#191c1f'))
    # rear walls
    c.vgrad(R1[0], CL, R1[1], FY, dk(WALL1, .25), WALL1)
    c.vgrad(R2[0], CL, R2[1], FY, hx('#24282c'), hx('#2c3035'))
    c.vgrad(R3[0], CL3, R3[1], FY, dk(WALL3, .2), WALL3)
    # R1 slate panels + brass chair rail + wainscot
    for x in range(int(R1[0]) + 150, int(R1[1]), 196):
        c.vline(x, CL, FY, dk(WALL1, .2), 0.8)
        c.vline(x + 0.8, CL, FY, lit(WALL1, .05), 0.5)
    c.vgrad(R1[0], 480, R1[1], FY, dk(WALL1, .3), dk(WALL1, .42))
    c.box(R1[0], 476, R1[1], 480, BRASS, outline=None, hl=.2)
    c.hline(R1[0], R1[1], 480, OUT, 0.6)
    # R2 perforated acoustic panels
    perforated(c, R2[0], CL, R2[1], FY)
    c.box(R2[0], 470, R2[1], 476, hx('#5a4a2a'), outline=OUT, hl=.15)      # ochre zone stripe
    # R3 wood louvers
    wood_louver_wall(c, R3[0], CL3, R3[1], FY - 9)
    # skirting
    for (a0, a1), col in ((R1, dk(WALL1, .55)), (R2, hx('#1a1d20')), (R3, hx('#1d1915'))):
        c.box(a0, FY - 9, a1, FY, col, outline=None)
        c.hline(a0, a1, FY - 9, lit(col, .15), 0.6)

    # floor finishes (section band)
    c.rect(R1[0], FY, R1[1], FY + 5, hx('#22252a'))
    for x in range(int(R1[0]), int(R1[1]), 96):
        c.vline(x, FY, FY + 5, hx('#16181b'), 0.8)
    c.rect(R2[0], FY, R2[1], FY + 5, hx('#2e3337'))
    c.rect(R3[0], FY, R3[1], FY + 5, hx('#2a2522'))
    c.rect(P1[0] - 6, FY, P1[1] + 6, FY + 5, hx('#3b4146'))
    c.rect(P2[0] - 6, FY, P2[1] + 6, FY + 5, hx('#3b4146'))
    c.hline(IX0, IX1, FY, hx('#6a5a3a'), 0.8)                 # ochre nosing (archive theme)
    # slab section
    c.vgrad(X0, FY + 5, X1, FB, hx('#23272a'), hx('#191b1e'))
    # under-floor services hanging below slab (section silhouette interest)
    c.box(400, FB, 1100, FB + 8, hx('#2a2f33'), outline=OUT, hl=.1)
    for x in (430, 760, 1070):
        c.vline(x, FB, FB + 8, hx('#3a4045'), 1)
    for x in (P1[0] - 18, P2[0] - 18):
        c.vgrad(x, FB - 2, x + 60, FB + 14, hx('#1f2225'), hx('#16181a'))
        c.rect(x, FB - 2, x + 60, FB + 14, None, OUT, 1)
    # ceiling slab + end walls
    c.vgrad(X0, TS0, X1, TS1, hx('#272b30'), hx('#1b1e22'))
    c.vgrad(X0, TS0, IX0, FB, hx('#262a2e'), hx('#1b1e21'))
    c.vgrad(IX1, TS0, X1, FB, hx('#262a2e'), hx('#1b1e21'))
    for a in ((X0, TS0, X1, TS1), (X0, FY + 5, X1, FB), (X0, TS0, IX0, FB), (IX1, TS0, X1, FB)):
        hatch(*a)
    c.hline(X0, X1, TS0, hx('#4b5258'), 1)
    c.hline(IX0, IX1, TS1, hx('#0d0f11'), 1)
    c.vline(IX0 - 1, TS1, FY, hx('#2c3237'), 1)
    c.vline(IX1, TS1, FY, hx('#0e1012'), 1)
    c.hline(X0, X1, FB - 1, hx('#2b2f33'), 1)


# ------------------------------------------------------------------ plenum & ceilings
def plenum():
    for x in range(int(IX0) + 50, int(IX1), 170):
        c.vline(x, TS1, 224, hx('#2a2f33'), 0.8)
    c.box(IX0, 222, IX1, 242, hx('#353b40'), outline=OUT, hl=.12, sh=.35)
    for x in range(int(IX0) + 80, int(IX1), 120):
        c.box(x, 221, x + 3, 243, hx('#41484e'), outline=None, hl=.1)
    # flex duct drops to diffusers
    for x in (330, 760, 1560, 2050, 2700):
        cl = CL3 if x > R3[0] else CL
        c.box(x - 6, 242, x + 6, cl - 8, hx('#4a5055'), outline=OUT, hl=.1)
        for yy in range(246, int(cl) - 9, 4):
            c.hline(x - 6, x + 6, yy, hx('#3a4045'), 0.5)
    # sprinkler main + drops
    c.box(IX0, 250, IX1, 253.5, hx('#5a3a36'), outline=OUT, hl=.15)
    for x in range(int(IX0) + 110, int(IX1), 240):
        cl = CL3 if x > R3[0] else CL
        c.rect(x - 0.8, 253.5, x + 0.8, cl + 3, hx('#5a3a36'))
        c.rect(x - 3, cl + 3, x + 3, cl + 4.5, hx('#8b8f91'))
    # cable tray
    c.rect(IX0 + 10, 262, IX1 - 10, 264, hx('#4f575d'))
    c.rect(IX0 + 10, 268, IX1 - 10, 269.5, hx('#3b4247'))
    for x in np.arange(IX0 + 10, IX1 - 10, 14):
        c.vline(x, 262, 269.5, hx('#41484e'), 0.6)
    rng = random.Random(3)
    for k in range(16):
        xx = rng.uniform(IX0 + 30, IX1 - 90)
        c.cable((xx, 267), (xx + rng.uniform(30, 80), 267), rng.uniform(2, 8), hx('#15181b'), 1)
    # ceiling grid hanger wires
    for x in range(int(IX0) + 30, int(R2[1]), 112):
        c.vline(x, TS1, CL - 5, hx('#2a2f33'), 0.4)


def ceiling_tiles(x0, x1, missing=()):
    """suspended ceiling cut in section: thin tile band, T-bar ticks, troffers"""
    for tx in np.arange(x0, x1, 56):
        idx = int((tx - x0) // 56)
        if idx in missing:
            continue
        c.box(tx, CL - 4, min(tx + 56, x1), CL, hx('#4d5359'), outline=None, hl=.06)
    for tx in np.arange(x0, x1 + 1, 56):
        idx = int((tx - x0) // 56)
        c.rect(tx - 1, CL - 5, tx + 1, CL + 0.8, hx('#6d7378'))
    c.hline(x0, x1, CL, OUT, 0.6)


def troffer(x, state='off'):
    c.box(x + 2, CL - 18, x + 54, CL - 4, hx('#2f3539'), outline=OUT)    # housing in plenum
    if state == 'off':
        c.rect(x + 2, CL - 4, x + 54, CL, hx('#5b6268'))
        for k in range(6):
            c.vline(x + 6 + k * 8, CL - 4, CL, hx('#474d52'), 0.5)
    else:
        c.rect(x + 2, CL - 4, x + 54, CL, hx('#c9d6dc'))
        c.cone(x + 28, CL, FY, 50, 120, hx('#7c98aa'), 0.18, blur=16)


def ceiling_r3():
    # gypsum ceiling + bulkhead edge
    c.box(R3[0], CL3 - 8, R3[1], CL3, hx('#3f3a35'), outline=OUT, hl=.08)
    for x in (2400, 2560, 2720, 2880, 3040):
        c.rect(x - 7, CL3 - 1, x + 7, CL3 + 1.2, hx('#1d1b19'))
        c.rect(x - 5, CL3 + 1.2, x + 5, CL3 + 2, hx('#55504a'))
    # projector on drop rod
    c.box(2637, CL3, 2641, CL3 + 16, hx('#3a4045'), outline=None)
    c.box(2618, CL3 + 16, 2660, CL3 + 28, hx('#5a6065'), outline=OUT, hl=.12)
    c.ell(2650, CL3 + 18, 2658, CL3 + 26, hx('#141618'), OUT, 0.5)


# ------------------------------------------------------------------ R1 研究開発室
def window_r1(x0, y0, x1, y1):
    city(x0, y0, x1, y1, seed=51)
    tdraw(c, (x0, y0, x1, y1), lambda od, ox, oy: od.rectangle([P(x0) + ox, P(y0) + oy, P(x1) + ox, P(y1) + oy], fill=(40, 60, 80, 34)))
    mulls = list(np.arange(x0, x1 + 1, 194))
    for i in range(len(mulls) - 1):
        reflection(c, mulls[i], y0, mulls[i + 1], y1, 8, 0.3 + 0.1 * i, 0.1)
    # louvers: mostly closed, a few turned edge-on, two missing
    vlouvers(c, x0 + 2, y0 + 4, x1 - 2, y1 - 2, seed=5, slat=10,
             missing=(23, 24, 52), turned=(8, 9, 10, 11, 31, 32, 33, 44, 45, 46, 47, 48, 60, 61, 62))
    c.blend_rect(x0, y0, x1, y1, hx('#5a7898'), 26)
    c.glow_rect(x0, y0, x1, y1, hx('#4a6a8e'), 0.20, blur=24)
    for m in mulls[1:-1]:
        c.box(m - 3, y0, m + 3, y1, hx('#2a3035'), outline=None, hl=.15)
    c.rect(x0 - 4, y0 - 4, x1 + 4, y0, hx('#262b30'))
    c.rect(x0 - 4, y0 - 4, x0, y1, hx('#262b30')); c.rect(x1, y0 - 4, x1 + 4, y1, hx('#262b30'))
    c.box(x0 - 8, y1, x1 + 8, y1 + 6, hx('#4e565c'), outline=OUT)
    fallen_slat(c, x0 + 238, y1 + 0.5, 104, 0.22)


def emergency_light(x, y):
    c.box(x - 16, y, x + 16, y + 10, hx('#6c7276'), outline=OUT, hl=.1)
    led(c, x + 10, y + 5, GREEN, 0.6, 0.5)
    for s in (-1, 1):
        hx0 = x + s * 13
        c.ell(hx0 - 5, y + 8, hx0 + 5, y + 18, hx('#4a5055'), OUT, 0.6)
        c.ell(hx0 - 3, y + 11, hx0 + 3, y + 17, hx('#e6ecef'))
        tip = (hx0 + s * 150, FY)
        pts = [(hx0 - 3, y + 14), (hx0 + 3, y + 14), (tip[0] + 60, tip[1]), (tip[0] - 60, tip[1])]
        c.glow_poly(pts, hx('#9fb4c0'), 0.16, blur=14)
        c.glow_ell(hx0, y + 14, 10, 8, hx('#dfe8ee'), 0.7, blur=5)
    # dust motes in the beams
    rng = random.Random(8)
    for k in range(40):
        s = rng.choice((-1, 1))
        t = rng.uniform(0.1, 0.9)
        bx = x + s * 13 + s * 150 * t + rng.uniform(-40, 40) * t
        by = y + 14 + (FY - y - 14) * t
        c.rect(bx, by, bx + 0.8, by + 0.8, hx('#a6b4bc'))


def furniture_r1():
    TOP = FY - 69
    window_r1(104, 340, 880, 470)
    # bench 1
    desk(c, 100, 470, TOP, peds=('L', 'R'))
    tower(c, 168, 42, 19, led=hx('#2c3a4a'))
    tower(c, 392, 42, 19, led=hx('#2c3a4a'))
    monitor(c, 178, TOP, 52, 31, 'off', seed=1, notes=2)
    monitor(c, 232, TOP, 52, 31, 'off', seed=2)
    keyboard(c, 205, TOP, 36); mouse(c, 232, TOP)
    y = books_lying(c, 116, TOP, 4, seed=3)
    papers(c, 118, 140, y, 5, seed=4)
    laptop(c, 330, TOP, 30, 'code_dim', seed=5, stand=True)           # on battery
    monitor(c, 392, TOP, 54, 32, 'off', seed=6, notes=3)
    papers(c, 270, 300, TOP, 16, seed=7)
    c.ell(278, TOP - 18, 300, TOP - 15, None, hx('#7b3a33'), 0.6)     # red pen loops on top sheet
    mug(c, 436, TOP, hx('#5e6870')); can(c, 446, TOP, hx('#4a5a6a'))
    # desk fan
    c.box(452, TOP - 3, 464, TOP, hx('#2b3034'), outline=OUT)
    c.box(457, TOP - 14, 459, TOP - 3, hx('#3a4045'), outline=None)
    c.ell(448, TOP - 30, 468, TOP - 10, hx('#262b2f'), OUT, 0.8)
    c.ell(455, TOP - 23, 461, TOP - 17, hx('#3a4045'))
    chair_back(c, 206)
    chair_back(c, 372, blanket=hx('#3a3a36'))
    cable_to_floor(c, 200, TOP + 4, dx=-10)
    # bench 2
    desk(c, 500, 870, TOP, peds=('L', 'R'), seed=2)
    tower(c, 570, 42, 19, led=hx('#2c3a4a'))
    monitor(c, 600, TOP, 78, 30, 'off', seed=8, notes=1)                 # ultrawide
    keyboard(c, 600, TOP, 36)
    binders(c, 650, TOP, 6, seed=9, lean_last=True)
    y = books_lying(c, 700, TOP, 5, seed=10)
    books_lying(c, 704, y, 2, seed=11)
    monitor(c, 790, TOP, 52, 31, 'off', seed=12, stand='arm', lift=16)
    c.box(788, TOP - 30, 792, TOP, hx('#2a2f33'), outline=OUT)
    papers(c, 520, 548, TOP, 22, seed=13)
    papers(c, 820, 846, TOP, 8, seed=14)
    # headphones on desk
    c.ell(752, TOP - 12, 770, TOP + 4, None, hx('#16191c'), 1.6)
    c.rrect(750, TOP - 6, 755, TOP, 2, hx('#16191c')); c.rrect(767, TOP - 6, 772, TOP, 2, hx('#16191c'))
    chair_back(c, 600)
    chair_side(c, 800, facing=-1)
    backpack(c, 520 + 70, hx('#2f3530')) if False else None
    recycle_bin(c, 478)
    c.glow_rect(100, TOP - 1, 870, TOP + 1, hx('#56789c'), 0.22, blur=2)
    floor_spill(c, 290, 370, CYAN, 0.18)
    # document cart + bookcases
    doc_cart(c, 882, 46, seed=3)

    def notebook_on_top(top):
        c.box(1200, top - 4, 1228, top, hx('#2b2f3a'), outline=OUT)
        c.rect(1202, top - 4.5, 1226, top - 3.6, hx('#6a6c66'))
        c.rect(1222, top - 4, 1224, top, hx('#7b3a33'))          # ribbon
        c.box(1160, top - 14, 1186, top, hx('#4e463a'), outline=OUT)   # dusty box
    bookcase(c, 934, 106, 171, seed=21)
    bookcase(c, 1044, 106, 171, seed=22, sparse=True)
    bookcase(c, 1154, 106, 186, seed=23, top_items=notebook_on_top)
    kick_step(c, 1070)
    emergency_light(1100, CL + 6)
    # badge reader for the security room, on R1 side of the steel partition
    c.box(1268, 468, 1280, 494, hx('#24292d'), outline=OUT)
    c.rect(1270, 473, 1278, 481, hx('#15191c'))
    led(c, 1274, 488, RED, 0.8, 0.9)


# ------------------------------------------------------------------ R2 技術研究室 (security research)
def furniture_r2():
    TOP = FY - 69
    ceiling_tiles(R2[0], R2[1], missing=(10, 11))
    # cables dropping through the missing tiles
    rng = random.Random(12)
    for k in range(7):
        x = 1880 + rng.uniform(4, 100)
        col = rng.choice([hx('#3e6aa0'), hx('#b39a4a'), hx('#15181b'), hx('#7a8a92')])
        end = (x + rng.uniform(-30, 30), CL + rng.uniform(40, 90))
        c.bezier((x, 266), (x + rng.uniform(-10, 10), end[1] + 20), end, dk(col, .25), 0.9)
    # wall: log monitor on UPS + suppression panel + pictogram plate
    c.occlude(1520, 352, 1644, 418, 100, blur=4); c.apply_shade_now()
    c.rrect(1518, 348, 1642, 414, 1.5, hx('#0f1113'), OUT, 1)
    screen_content(c, 1521, 351, 1639, 411, 'term', seed=31)
    c.box(1668, 380, 1700, 424, hx('#5a5f62'), outline=OUT, hl=.08)
    c.rect(1672, 386, 1696, 396, hx('#1a1c1e'))
    led(c, 1678, 404, GREEN, 0.6, 0.5); led(c, 1690, 404, RED, 0.6, 0.5)
    c.box(1440, 352, 1480, 380, hx('#8a7a3a'), outline=OUT)            # badge pictogram plate
    c.rrect(1452, 357, 1468, 375, 1.5, hx('#2a2a22'))
    c.ell(1457, 360, 1463, 366, hx('#8a7a3a'))
    c.rect(1455, 368, 1465, 371, hx('#8a7a3a'))
    # security cabinet next to the door
    security_cabinet(c, 1334, 64, 170)
    # air-gapped researcher workstation
    desk(c, 1416, 1744, TOP, peds=('R',), seed=4, col=hx('#656c71'))
    tower(c, 1432, 46, 21, led=hx('#5f3a3a'), mesh=True)
    c.rect(1435, FY - 30, 1450, FY - 24, hx('#8a3a33'))                 # red air-gap tag
    monitor(c, 1500, TOP, 54, 32, 'off', seed=32, notes=6)              # covered in post-its
    monitor(c, 1556, TOP, 54, 32, 'off', seed=33, notes=1)
    keyboard(c, 1528, TOP, 36); mouse(c, 1556, TOP)
    c.box(1600, TOP - 8, 1660, TOP, hx('#22272b'), outline=OUT)          # HSM appliance
    c.rect(1604, TOP - 6, 1630, TOP - 2, hx('#151a1d'))
    c.ell(1640, TOP - 6, 1645, TOP - 1.5, hx('#8a9196'), OUT, 0.4)       # key
    led(c, 1652, TOP - 4, AMBER, 0.5, 0.5)
    for k in range(5):                                                   # token tray
        c.box(1668 + k * 7, TOP - 4, 1673 + k * 7, TOP, hx('#2b3034') if k % 2 else hx('#3e4a52'), outline=OUT)
    papers(c, 1690, 1724, TOP, 7, seed=34)
    mug(c, 1736, TOP)
    chair_back(c, 1530)
    # audit log printer with spilled printout
    printer_tall(c, 1756)
    # network / console bench
    bx0, bx1, btop = 1890, 2104, FY - 83
    c.occlude(bx0, btop, bx1, FY, 110, blur=6); c.apply_shade_now()
    for lx in (bx0 + 2, bx1 - 9):
        c.box(lx, btop + 5, lx + 7, FY, hx('#3a4145'), outline=OUT)
    c.box(bx0 + 4, FY - 34, bx1 - 4, FY - 30, hx('#3a4145'), outline=OUT)
    xx = bx0 + 12
    for k in range(4):
        col = rng.choice([hx('#3e5a6e'), hx('#5e4e3c'), hx('#4a4f53')])
        c.box(xx, FY - 50, xx + 40, FY - 34, col, outline=OUT)
        xx += 46
    cardboard(c, bx0 + 16, FY, 52, 24, seed=5)
    c.ell(bx1 - 52, FY - 26, bx1 - 26, FY, hx('#2e4c6c'), OUT, 0.8)
    c.ell(bx1 - 45, FY - 19, bx1 - 33, FY - 7, hx('#1a1d20'), OUT, 0.6)
    c.box(bx0, btop, bx1, btop + 5, hx('#4b5358'), outline=OUT)
    c.rect(bx0 + 2, btop - 1.6, bx1 - 2, btop, hx('#2f3a44'))
    # stacked test switches with patch loops (on battery)
    for k in range(3):
        sy = btop - 1.6 - (k + 1) * 6
        c.box(bx0 + 14, sy, bx0 + 96, sy + 6, hx('#22272b'), outline=OUT, hl=.1)
        for j in range(10):
            px = bx0 + 18 + j * 7
            c.rect(px, sy + 2, px + 3, sy + 4, hx('#0b0d0f'))
            if rng.random() < .5:
                led(c, px + 1.5, sy + 1.2, GREEN if rng.random() < .8 else AMBER, 0.35, 0.35)
        for j in range(4):
            px = bx0 + 20 + rng.uniform(0, 64)
            col = rng.choice([hx('#3e6aa0'), hx('#b39a4a'), hx('#7a8a92')])
            c.bezier((px, sy + 4), (px + rng.uniform(-12, 12), sy + 14), (px + rng.uniform(-20, 20), btop - 1), dk(col, .2), 0.7)
    laptop(c, 2010, btop - 1.6, 30, 'term', seed=35)
    c.bezier((1996, btop - 4), (1960, btop + 2), (bx0 + 96, btop - 8), hx('#4a6a8a'), 0.8)   # console cable
    c.box(2050, btop - 10, 2064, btop - 1.6, hx('#9a8a3e'), outline=OUT)                   # cable tester
    c.rect(2052, btop - 8, 2062, btop - 5, hx('#1f2a22'))
    c.line([(2072, btop - 2), (2090, btop - 8)], hx('#7a3b33'), 1.6)                         # crimper
    c.line([(2072, btop - 5), (2090, btop - 3)], hx('#7a3b33'), 1.6)
    stool(c, 1990)
    # racks against the meeting-room partition, a fallen ceiling tile on top
    rack(c, 2114, 58, 186, 'servers', seed=41, door_glass=True)
    rack(c, 2176, 58, 186, 'patch', seed=42)
    c.box(2118, FY - 191, 2172, FY - 186, hx('#4d5359'), outline=OUT)
    for k in range(10):
        x = 2120 + rng.uniform(0, 110)
        col = rng.choice([hx('#3e6aa0'), hx('#b39a4a'), hx('#7a8a92'), hx('#15181b')])
        c.bezier((x, FY - 186), (x + rng.uniform(-8, 8), CL + 30), (x + rng.uniform(-20, 20), 268), dk(col, .25), 0.8)
    # floor cable cover across the room
    c.box(1760, FY - 3, 1890, FY, hx('#3a3f30'), outline=OUT)


# ------------------------------------------------------------------ R3 会議室
def result_board(x0, y0, x1, y1):
    c.occlude(x0 + 2, y0 + 3, x1 + 3, y1 + 5, 90, blur=4); c.apply_shade_now()
    c.rect(x0, y0, x1, y1, hx('#4f575e'))
    c.vgrad(x0 + 3, y0 + 3, x1 - 3, y1 - 3, hx('#6c7378'), hx('#585f64'))
    ink = hx('#2b3034'); red = hx('#7b3a33'); blue = hx('#2f4766')
    # axes
    gx0, gy1 = x0 + 18, y1 - 14
    c.vline(gx0, y0 + 12, gy1, ink, 0.8); c.hline(gx0, x1 - 12, gy1, ink, 0.8)
    # four quarter columns: first wiped clean, others low
    colw = (x1 - 12 - gx0) / 4
    for k, hfrac in enumerate([None, 0.16, 0.14, 0.12]):
        cx = gx0 + colw * k + colw / 2
        if hfrac is None:
            c.stain(cx - colw * 0.4, y0 + 14, colw * 0.8, gy1 - y0 - 18, hx('#848b8f'), alpha=60, blur=4, seed=9)
            for j in range(4):   # leftover smears
                c.line([(cx - 14 + j * 5, gy1 - 50 + j * 7), (cx + 10 + j * 3, gy1 - 58 + j * 6)], hx('#7d8488'), 1.4)
            continue
        bh = (gy1 - y0 - 20) * hfrac
        c.rect(cx - 10, gy1 - bh, cx + 10, gy1, dk(blue, -0.1))
        c.rect(cx - 10, gy1 - bh, cx + 10, gy1, None, dk(blue, .3), 1)
    # two threshold lines (dashed): low tier & high tier
    for frac, col in ((0.33, ink), (0.80, red)):
        yy = gy1 - (gy1 - y0 - 20) * frac
        for xx in np.arange(gx0 + 2, x1 - 14, 7):
            c.hline(xx, xx + 4, yy, col, 1.2)
    c.ell(gx0 + colw * 0.1, y0 + 10, gx0 + colw * 0.95, gy1 - 4, None, red, 1.2)      # circle around wiped column
    c.line([(gx0 + colw * 0.95, y0 + 22), (gx0 + colw * 1.4, y0 + 14)], red, 1)
    # trend line that stops at the wiped column
    c.line([(gx0 + colw * 1.5, gy1 - 15), (gx0 + colw * 2.5, gy1 - 13), (gx0 + colw * 3.5, gy1 - 11)], ink, 0.8)
    for k in range(3):
        sticky(c, x1 - 22, y0 + 8 + k * 9, [hx('#a69a58'), hx('#9b7177'), hx('#a69a58')][k])
    c.rect(x0, y0, x1, y1, None, hx('#7a8186'), 1); c.rect(x0, y0, x1, y1, None, OUT, 0.5)
    c.box(x0 + 6, y1, x1 - 6, y1 + 4, hx('#5e666c'), outline=OUT)
    c.rect(x0 + 24, y1 - 1.6, x0 + 34, y1, red); c.rect(x0 + 38, y1 - 1.6, x0 + 48, y1, ink)
    # eraser left on tray
    c.box(x0 + 60, y1 - 4, x0 + 76, y1, hx('#3a4248'), outline=OUT)


def clock_stopped(cx, cy, r=13):
    c.ell(cx - r - 1, cy - r - 1, cx + r + 1, cy + r + 1, OUT)
    c.ell(cx - r, cy - r, cx + r, cy + r, BRASS)
    c.ell(cx - r + 2, cy - r + 2, cx + r - 2, cy + r - 2, hx('#7b7f7d'))
    for k in range(12):
        a = k / 12 * 2 * math.pi
        c.line([(cx + math.cos(a) * (r - 3), cy + math.sin(a) * (r - 3)), (cx + math.cos(a) * (r - 4.5), cy + math.sin(a) * (r - 4.5))], hx('#2b3034'), 0.6)
    ah = (3 + 12 / 60) / 12 * 2 * math.pi - math.pi / 2       # 03:12
    am = 12 / 60 * 2 * math.pi - math.pi / 2
    c.line([(cx, cy), (cx + math.cos(ah) * (r - 7), cy + math.sin(ah) * (r - 7))], hx('#1b1e21'), 1.3)
    c.line([(cx, cy), (cx + math.cos(am) * (r - 4), cy + math.sin(am) * (r - 4))], hx('#1b1e21'), 0.8)
    c.ell(cx - 1, cy - 1, cx + 1, cy + 1, hx('#7b3a33'))


def furniture_r3():
    TOP = FY - 69
    ceiling_r3()
    result_board(2292, 354, 2504, 452)
    # big wall display, off, standby LED
    c.occlude(2542, 350, 2786, 452, 110, blur=5); c.apply_shade_now()
    c.rrect(2540, 346, 2784, 448, 1.5, hx('#0e1012'), OUT, 1)
    screen_content(c, 2543, 349, 2781, 445, 'off', seed=51)
    reflection(c, 2543, 349, 2781, 445, 12, 0.55, 0.12)
    led(c, 2778, 446, RED, 0.5, 0.5)
    clock_stopped(2826, 368)
    # exit sign hanging near the doorway
    c.vline(2296, CL3, CL3 + 10, hx('#3a4045'), 0.6); c.vline(2330, CL3, CL3 + 10, hx('#3a4045'), 0.6)
    c.box(2290, CL3 + 10, 2336, CL3 + 26, hx('#1a2a1f'), outline=OUT)
    c.rect(2292, CL3 + 12, 2334, CL3 + 24, hx('#2f6a45'))
    c.ell(2319, CL3 + 13.5, 2322, CL3 + 16.5, hx('#cfe8d6'))
    c.line([(2320, CL3 + 17), (2317, CL3 + 21), (2313, CL3 + 23)], hx('#cfe8d6'), 0.9)
    c.line([(2319, CL3 + 18), (2324, CL3 + 20)], hx('#cfe8d6'), 0.8)
    c.line([(2317, CL3 + 21), (2320, CL3 + 23.5)], hx('#cfe8d6'), 0.8)
    c.line([(2296, CL3 + 18), (2306, CL3 + 18), (2302, CL3 + 15)], hx('#cfe8d6'), 0.8)
    c.glow_rect(2290, CL3 + 10, 2336, CL3 + 26, hx('#4fb57a'), 0.55, blur=14)
    # records credenza at the far end
    credenza(c, 2984, 126, seed=2)
    binders(c, 2992, FY - 75, 8, seed=61, h=30, lean_last=True)
    c.rect(3006, FY - 103, 3012, FY - 98, hx('#8a3a33'))                 # red tab on one binder
    c.box(3060, FY - 82, 3100, FY - 75, hx('#5e5242'), outline=OUT)
    # meeting table + items
    meeting_table(c, 2336, 2960, TOP)
    laptop(c, 2648, TOP, 32, 'blue', seed=52)                            # auto-minutes laptop on battery
    led(c, 2648, TOP - 21.5, RED, 0.45, 0.6)                             # recording dot at the camera
    c.glow_ell(2648, TOP, 70, 14, hx('#6f8fc6'), 0.25, blur=16)
    conf_phone(c, 2560, TOP)
    for x, n, sd in ((2392, 7, 1), (2482, 9, 2), (2740, 6, 3), (2834, 11, 4), (2906, 5, 5)):
        papers(c, x - 14, x + 14, TOP, n, seed=sd + 70)
    for x in (2420, 2512, 2770, 2862):
        bottle(c, x, TOP)
    mug(c, 2700, TOP, hx('#5e5a54'))
    binders(c, 2600, TOP, 2, seed=81, h=24)
    c.line([(2716, TOP - 0.6), (2734, TOP - 1.6)], hx('#2f4766'), 0.8)    # pen
    # chairs
    for x in (2392, 2482, 2740, 2834):
        chair_back(c, x, col=hx('#221d1a'))
    chair_side(c, 2918, facing=-1, col=hx('#221d1a'))


# ------------------------------------------------------------------ partitions, lights, finalize
def partitions():
    partition(c, P1[0], P1[1], TS1, style='steel', door_side='R')
    partition(c, P2[0], P2[1], TS1, style='wood', door_side='L')


def cctv(x, y, facing=1, dome=False):
    if dome:
        c.box(x - 9, y, x + 9, y + 3, hx('#4a5258'), outline=OUT)
        c.ell(x - 7, y - 2, x + 7, y + 11, hx('#1c2024'), OUT, 0.8)
        led(c, x + 2, y + 6, RED, 0.6, 0.6)
        return
    c.rect(x - 1, y, x + 1, y + 8, hx('#4a5258'))
    a, b = (x, x + 28) if facing > 0 else (x - 28, x)
    c.box(a, y + 6, b, y + 14, hx('#5a6267'), outline=OUT)
    hx0 = b - 6 if facing > 0 else a
    c.box(hx0, y + 7, hx0 + 6, y + 13, hx('#202427'), outline=OUT)
    led(c, x + 4 * facing, y + 8, RED, 0.6, 0.7)


def lights():
    ceiling_tiles(R1[0], R1[1])
    for x in (160, 440, 720, 1000):
        troffer(x, 'off')
    for x in (1400, 1680, 2000):
        troffer(x, 'off')
    cctv(1250, CL, dome=True)
    cctv(2228, CL + 2, facing=-1)


def finalize():
    arr = np.asarray(c.img, np.float32)
    h, w = arr.shape[:2]
    ys = np.linspace(0, 1, h)[:, None]
    xs = np.linspace(0, 1, w)[None, :]
    yy = (ys * H - TS1) / (FY - TS1)
    v = 1.0 - 0.30 * np.clip(1 - yy * 1.5, 0, 1) ** 1.5
    v *= 1.0 - 0.10 * np.clip((yy - 0.75) * 4, 0, 1)
    edge = np.minimum(xs, 1 - xs) * W
    v = v * (0.74 + 0.26 * np.clip(edge / 420.0, 0, 1))
    arr[:, :, :3] *= v[:, :, None]
    sh = np.asarray(c.shade, np.float32)[:, :, None] / 255.0
    arr[:, :, :3] *= (1 - sh * 0.85)
    L = np.asarray(c.light, np.float32) / 255.0
    base = arr[:, :, :3] / 255.0
    out = 1 - (1 - base) * (1 - L)
    lum = (out * np.array([0.299, 0.587, 0.114])).sum(axis=2, keepdims=True)
    out = out * 0.80 + lum * 0.20
    out = out * np.array([0.985, 1.0, 1.035])
    out = np.clip(out, 0, 1) ** 0.92
    out = np.clip((out - 0.5) * 1.10 + 0.5, 0, 1)
    arr[:, :, :3] = out * 255
    img = Image.fromarray(arr.clip(0, 255).astype(np.uint8), 'RGBA').resize((W, H), Image.LANCZOS)
    a = np.asarray(img, np.float32)
    rng = np.random.default_rng(5)
    g = (rng.random((H, W)) - 0.5) * 7
    low = Image.fromarray((rng.random((H // 6, W // 6)) * 255).astype(np.uint8), 'L').resize((W, H), Image.BICUBIC)
    low = (np.asarray(low, np.float32) / 255 - 0.5) * 0.07
    a[:, :, :3] = a[:, :, :3] * (1 + low[:, :, None]) + g[:, :, None]
    alpha = np.where(a[:, :, 3] > 127, 255, 0)
    a[:, :, 3] = alpha
    a[:, :, :3] *= (alpha[:, :, None] > 0)
    img = Image.fromarray(a.clip(0, 255).astype(np.uint8), 'RGBA')
    m = img.getchannel('A')
    inner = m.filter(ImageFilter.MinFilter(5))
    img.paste(Image.new('RGBA', img.size, (9, 10, 12, 255)), (0, 0), ImageChops.subtract(m, inner))
    inner2 = m.filter(ImageFilter.MinFilter(9))
    img.paste(Image.new('RGBA', img.size, (78, 88, 98, 255)), (0, 0), ImageChops.subtract(inner, inner2).point(lambda v: 150 if v else 0))
    bb = img.getchannel('A').getbbox()
    M = 48
    img = img.crop((bb[0] - M, bb[1] - M, bb[2] + M, bb[3] + M))
    print('bbox', bb, 'floor line y in output =', FY - (bb[1] - M), 'size', img.size)
    return img


def build():
    shell()
    c.noise_tex(R1[0], CL, R1[1], FY, 0.07, 30, seed=1, streaks=True)
    c.noise_tex(R2[0], CL, R2[1], FY, 0.06, 24, seed=2, streaks=True)
    c.noise_tex(R3[0], CL3, R3[1], FY, 0.06, 30, seed=3, streaks=True)
    c.noise_tex(X0, TS0, X1, TS1, 0.08, 16, seed=4)
    c.noise_tex(X0, FY, X1, FB, 0.08, 16, seed=5)
    c.noise_tex(IX0, TS1, IX1, CL3, 0.08, 20, seed=6)
    for i, (x, y, w_, h_) in enumerate([(240, 480, 140, 80), (980, 330, 120, 60), (1500, 440, 160, 120),
                                        (1960, 330, 100, 200), (2400, 470, 200, 90), (3000, 330, 90, 120)]):
        c.stain(x, y, w_, h_, hx('#14171a'), alpha=40, blur=10, seed=i + 10)
    # water stain under the missing ceiling tiles
    c.stain(1890, CL, 110, 160, hx('#101315'), alpha=60, blur=9, seed=77)
    plenum()
    c.occlude(IX0, CL, IX1, CL + 10, 150, blur=10)
    c.occlude(IX0, FY - 6, IX1, FY, 120, blur=6)
    c.occlude(IX0, TS1, IX0 + 10, FY, 140, blur=14)
    c.occlude(IX1 - 10, TS1, IX1, FY, 140, blur=14)
    for p in (P1, P2):
        c.occlude(p[0] - 14, TS1, p[0], FY, 120, blur=10)
        c.occlude(p[1], TS1, p[1] + 14, FY, 120, blur=10)
    c.apply_shade_now()
    furniture_r1()
    furniture_r2()
    furniture_r3()
    lights()
    partitions()
    return finalize()


if __name__ == '__main__':
    img = build()
    out = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/f5/floor05.png'
    img.save(out)
    print('saved', out)
