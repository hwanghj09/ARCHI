import random, math, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageChops
from lib import *
from objects import *
from objects5 import partition, bookcase
from objects4 import *

X0, X1 = 48, 3152
IX0, IX1 = 78, 3122
TS0, TS1 = 180, 212
FB = 626
A = (IX0, 1000); COL1 = (1000, 1040)
B = (1040, 2462); GP = (2462, 2474)
C = (2474, IX1)
CLC = 304            # meeting room ceiling underside

WALL_A = hx('#35424a')
WALL_C = hx('#38434a')

c = Canvas()
exec(open('reuse.py').read().split('\n', 4)[4], globals())


def hatch(x0, y0, x1, y1, col=hx('#3a3f44'), step=9):
    def f(od, ox, oy):
        for k in range(int(-(y1 - y0)), int(x1 - x0), step):
            od.line([(P(x0 + k) + ox, P(y1) + oy), (P(x0 + k + (y1 - y0)) + ox, P(y0) + oy)], fill=wa(col, 70), width=P(0.8))
    tdraw(c, (x0, y0, x1, y1), f)


def layer(fn, dark=0.55, tint=hx('#0f1a20'), tint_a=0.45):
    """draw fn() on its own layer, push it back with depth haze, composite under later drawing"""
    c.apply_shade_now()
    base = c.img
    c.img = Image.new('RGBA', base.size, (0, 0, 0, 0)); c.d = ImageDraw.Draw(c.img)
    fn()
    c.apply_shade_now()
    arr = np.asarray(c.img, np.float32)
    rgb = arr[:, :, :3] * (1 - dark)
    rgb = rgb * (1 - tint_a) + np.array(tint[:3], np.float32) * tint_a
    arr[:, :, :3] = np.where(arr[:, :, 3:4] > 0, rgb, arr[:, :, :3])
    lay = Image.fromarray(arr.clip(0, 255).astype(np.uint8), 'RGBA')
    base.alpha_composite(lay)
    c.img = base; c.d = ImageDraw.Draw(c.img)


# ------------------------------------------------------------------ shell
def shell():
    c.vgrad(IX0, TS1, IX1, 300, hx('#111517'), hx('#181d20'))
    # A: blue-gray wall, mint stripe
    c.vgrad(A[0], 250, A[1], FY, dk(WALL_A, .3), WALL_A)
    c.vgrad(A[0], TS1, A[1], 250, hx('#181d20'), dk(WALL_A, .3))
    for x in range(int(A[0]) + 140, int(A[1]), 184):
        c.vline(x, 260, FY, dk(WALL_A, .2), 0.8)
    c.vgrad(A[0], 480, A[1], FY, dk(WALL_A, .3), dk(WALL_A, .42))
    c.box(A[0], 476, A[1], 480, MINT, outline=None, hl=.15)
    # B: back wall base (behind window frame, partition) + spandrel above the curtain wall
    c.vgrad(B[0], TS1, GP[1], FY, hx('#161c1f'), hx('#20272b'))
    c.vgrad(B[0], TS1, B[1], 290, hx('#141a1d'), hx('#1e2529'))
    # C: fabric acoustic panels
    c.vgrad(C[0], CLC, C[1], FY, dk(WALL_C, .25), WALL_C)
    for x in range(int(C[0]) + 20, int(C[1]), 92):
        c.vline(x, CLC, FY, dk(WALL_C, .35), 1)
    c.box(C[0], 470, C[1], 474, MINT, outline=None, hl=.15)
    # column between A and B (mint corner guards)
    cc = hx('#434c52')
    c.box(COL1[0], TS1, COL1[1], FY, cc, outline=OUT, hl=.06, sh=.35)
    c.vline(COL1[0] + 3, TS1, FY, lit(cc, .15), 0.8)
    c.rect(COL1[0] + 1, FY - 140, COL1[0] + 5, FY - 10, MINT)
    c.rect(COL1[1] - 5, FY - 140, COL1[1] - 1, FY - 10, dk(MINT, .2))
    c.box(COL1[0] - 2, FY - 12, COL1[1] + 2, FY, dk(cc, .45), outline=OUT)
    # skirting
    for (a0, a1), col in ((A, dk(WALL_A, .55)), (C, dk(WALL_C, .55))):
        c.box(a0, FY - 9, a1, FY, col, outline=None)
        c.hline(a0, a1, FY - 9, lit(col, .15), 0.6)
    # white epoxy floor (section band) with gloss
    c.vgrad(IX0, FY, IX1, FY + 7, hx('#545b5f'), hx('#3a4044'))
    c.hline(IX0, IX1, FY, hx('#7d8a88'), 0.8)
    c.rect(C[0], FY, C[1], FY + 5, hx('#2a3236'))                 # meeting room carpet
    for x in range(int(IX0), int(C[0]), 200):
        c.vline(x, FY, FY + 7, hx('#30363a'), 0.6)
    # slab section
    c.vgrad(X0, FY + 7, X1, FB, hx('#23272a'), hx('#191b1e'))
    for x in (COL1[0] - 10, 1740 - 10):
        c.vgrad(x, FB - 2, x + 62, FB + 14, hx('#1f2225'), hx('#16181a'))
        c.rect(x, FB - 2, x + 62, FB + 14, None, OUT, 1)
    c.vgrad(X0, TS0, X1, TS1, hx('#272b30'), hx('#1b1e22'))
    c.vgrad(X0, TS0, IX0, FB, hx('#262a2e'), hx('#1b1e21'))
    c.vgrad(IX1, TS0, X1, FB, hx('#262a2e'), hx('#1b1e21'))
    for a in ((X0, TS0, X1, TS1), (X0, FY + 7, X1, FB), (X0, TS0, IX0, FB), (IX1, TS0, X1, FB)):
        hatch(*a)
    c.hline(X0, X1, TS0, hx('#4b5258'), 1)
    c.hline(IX0, IX1, TS1, hx('#0d0f11'), 1)
    c.vline(IX0 - 1, TS1, FY, hx('#2c3237'), 1)
    c.vline(IX1, TS1, FY, hx('#0e1012'), 1)
    c.hline(X0, X1, FB - 1, hx('#2b2f33'), 1)


def curtain_wall():
    x0, y0, x1, y1 = 1060, 292, 2446, 548
    street_view(c, x0, y0, x1, y1, seed=4)
    tdraw(c, (x0, y0, x1, y1), lambda od, ox, oy: od.rectangle([P(x0) + ox, P(y0) + oy, P(x1) + ox, P(y1) + oy], fill=(30, 46, 56, 40)))
    mulls = list(np.arange(x0, x1 + 1, 173.25))
    drops = [0, 40, 110, 254, 0, 254, 70, 0]
    for i in range(len(mulls) - 1):
        a, b = mulls[i], mulls[i + 1]
        reflection(c, a, y0, b, y1, 8, 0.25 + 0.07 * i, 0.1)
        roller_shade(c, a + 4, y0 + 8, b - 4, drops[i], seed=i, torn=(i == 5))
    paint_glow(c, (x0, y0, x1, y1), ('rect', x0, y0 + 140, x1, y1), SODIUM, 0.12, blur=30)
    # frame, mullions, transom
    c.rect(x0 - 4, y0 - 4, x1 + 4, y0, hx('#262b30'))
    c.rect(x0 - 4, y0 - 4, x0, y1, hx('#262b30')); c.rect(x1, y0 - 4, x1 + 4, y1, hx('#262b30'))
    for m in mulls[1:-1]:
        c.box(m - 3, y0, m + 3, y1, hx('#2a3035'), outline=None, hl=.15)
        c.vline(m - 3, y0, y1, hx('#3c444a'), 0.6)
    c.rect(x0, y0 + 40, x1, y0 + 43, hx('#262b30'))
    # low sill / convector cover
    c.box(x0 - 10, y1, x1 + 10, FY - 1, hx('#2b3236'), outline=OUT, hl=.15)
    for x in np.arange(x0, x1, 6):
        c.vline(x, y1 + 6, FY - 6, hx('#1d2226'), 0.8)
    # structural column standing in front of a mullion
    cc = hx('#434c52')
    c.occlude(1736, TS1, 1776, FY, 100, blur=6); c.apply_shade_now()
    c.box(1740, TS1, 1772, FY, cc, outline=OUT, hl=.06, sh=.35)
    c.vline(1743, TS1, FY, lit(cc, .15), 0.8)
    c.rect(1741, FY - 140, 1745, FY - 10, MINT)
    c.box(1738, FY - 12, 1774, FY, dk(cc, .45), outline=OUT)


# ------------------------------------------------------------------ ceilings
def ceilings():
    # main duct + sprinkler over everything
    for x in range(int(IX0) + 50, int(IX1), 170):
        c.vline(x, TS1, 224, hx('#2a2f33'), 0.8)
    c.box(IX0, 222, IX1, 240, hx('#353b40'), outline=OUT, hl=.12, sh=.35)
    for x in range(int(IX0) + 80, int(IX1), 120):
        c.box(x, 221, x + 3, 241, hx('#41484e'), outline=None, hl=.1)
    c.box(IX0, 246, IX1, 249.5, hx('#5a3a36'), outline=OUT, hl=.15)
    # A: exposed ceiling, cable ladder + strip lights (off)
    c.rect(A[0] + 10, 258, A[1] - 6, 260, hx('#4f575d'))
    c.rect(A[0] + 10, 265, A[1] - 6, 266.5, hx('#3b4247'))
    for x in np.arange(A[0] + 10, A[1] - 6, 14):
        c.vline(x, 258, 266.5, hx('#41484e'), 0.6)
    rng = random.Random(9)
    for k in range(9):
        xx = rng.uniform(A[0] + 30, A[1] - 80)
        col = rng.choice([hx('#15181b'), hx('#3e6aa0'), hx('#7a8a92')])
        c.cable((xx, 264), (xx + rng.uniform(30, 70), 264), rng.uniform(2, 8), dk(col, .3), 1)
    for x0 in (180, 520, 820):
        c.vline(x0 + 10, 249.5, 286, hx('#3a4045'), 0.5); c.vline(x0 + 130, 249.5, 286, hx('#3a4045'), 0.5)
        c.box(x0, 286, x0 + 140, 291, hx('#2b3136'), outline=OUT, hl=.1)
        c.rect(x0 + 2, 290, x0 + 138, 291.5, hx('#4c555b'))
    # cables from the ladder down into the rack
    for k in range(6):
        xx = 100 + k * 8
        c.bezier((xx + 30, 264), (xx, 330), (xx + 4, 420), dk(rng.choice([hx('#3e6aa0'), hx('#b39a4a'), hx('#15181b')]), .3), 0.8)
    # B: acoustic baffles, lit faintly from below by the street
    baffles(c, B[0], B[1], 262, 34)
    c.glow_rect(B[0], 290, B[1], 298, SODIUM, 0.10, blur=12)
    # C: gypsum ceiling with recessed downlights + mic array
    c.box(C[0], CLC - 8, C[1], CLC, hx('#3d4448'), outline=OUT, hl=.08)
    for x in (2560, 2720, 2880, 3040):
        c.rect(x - 7, CLC - 1, x + 7, CLC + 1.2, hx('#1d1f21'))
        c.rect(x - 5, CLC + 1.2, x + 5, CLC + 2, hx('#55595b'))
    mic_array(c, 2700, CLC)
    # glass partition header (solid) above the meeting-room glazing
    c.box(GP[0] - 6, TS1, GP[1] + 6, CLC, hx('#2a2f33'), outline=OUT, hl=.08)


# ------------------------------------------------------------------ A: R&D workspace
def mint_screen(x0, y0, x1, y1, seed=0):
    rng = random.Random(seed)
    c.vgrad(x0, y0, x1, y1, hx('#0d1a18'), hx('#091210'))
    y = y0 + 2
    k = 0
    while y < y1 - 2:
        c.rect(x0 + 2, y, x0 + 6, y + 1, wa(dk(MINT_L, .3), 255))                    # block hash
        c.rect(x0 + 8, y, x0 + 8 + rng.uniform(6, (x1 - x0) * 0.55), y + 0.8, wa(MINT_L if k != 7 else RED, 255))
        y += 2.3; k += 1
    c.glow_rect(x0, y0, x1, y1, MINT, 0.55, blur=10)


def furniture_A():
    TOP = FY - 69
    rack(c, 92, 58, 150, 'dev', seed=1)
    # wall shelf above desk A1 with binders and dev kits
    c.box(172, 404, 516, 408, hx('#59616a'), outline=OUT)
    for x in (190, 496):
        c.poly([(x, 408), (x + 4, 408), (x + 4, 420), (x, 414)], hx('#3a4045'))
    xx = binders(c, 180, 404, 9, seed=11, h=30, lean_last=True)
    cardboard(c, xx + 8, 404, 36, 22, seed=2)
    c.box(xx + 50, 390, xx + 86, 404, hx('#2b3136'), outline=OUT)
    books_lying(c, xx + 96, 404, 4, seed=4)
    # abstract DB architecture print on the wall
    c.occlude(318, 316, 430, 394, 70, blur=3); c.apply_shade_now()
    c.box(316, 314, 428, 392, hx('#7d807c'), outline=OUT, hl=.02)
    for r in range(3):
        for k in range(3 - (r == 0)):
            bx = 324 + k * 34 + (17 if r == 0 else 0); by = 322 + r * 22
            c.rect(bx, by, bx + 28, by + 14, None, hx('#2f4766'), 0.8)
            if r < 2:
                c.vline(bx + 14, by + 14, by + 22, hx('#2b3034'), 0.6)
    # desk A1: test servers, tri-monitor, laptops
    desk(c, 164, 520, TOP, peds=('L',), col=hx('#666d72'))
    tower(c, 236, 46, 21, led=hx('#2c3a4a'), mesh=True)
    tower(c, 262, 46, 21, led=hx('#2c3a4a'), mesh=True)
    server_1u(c, 190, TOP, 66)
    server_1u(c, 190, TOP - 7, 66, open_lid=True)
    monitor(c, 300, TOP, 50, 30, 'off', seed=1, stand='arm', lift=16)
    monitor(c, 352, TOP, 50, 30, 'off', seed=2, stand='arm', lift=16, notes=2)
    monitor(c, 404, TOP, 50, 30, 'off', seed=3, stand='arm', lift=16)
    c.box(350, TOP - 30, 354, TOP, hx('#2a2f33'), outline=OUT)
    keyboard(c, 352, TOP, 36); mouse(c, 380, TOP)
    laptop(c, 456, TOP, 30, 'off', seed=4, stand=True)
    laptop(c, 494, TOP, 28, 'blue', seed=5)                       # battery
    c.box(426, TOP - 9, 444, TOP, hx('#2b3034'), outline=OUT)    # tape box
    for k in range(3):
        c.rect(428 + k * 5, TOP - 8, 431 + k * 5, TOP - 6, MINT)
    chair_back(c, 352)
    cable_to_floor(c, 300, TOP + 4, dx=-12); cable_to_floor(c, 420, TOP + 4, dx=8)
    # UPS distributor on the wall: output on the log reader (third lamp)
    ups_distributor(c, 604, 360, active=2)
    tape_cart(c, 528, 66, seed=2)
    c.bezier((616, 422), (640, 470), (656, FY - 50), hx('#1b1f22'), 1.2)     # to UPS tower
    c.bezier((634, 422), (650, 300), (660, 252), hx('#1b1f22'), 1.2)        # up to the vault door lock
    c.bezier((652, 422), (690, 470), (700, TOP - 14), hx('#2a3a38'), 1.2)   # to the reader
    # desk A2: log reader + UPS-powered monitor
    desk(c, 626, 870, TOP, peds=('R',), seed=2, col=hx('#666d72'))
    ups_tower(c, 644, on=True)
    box_fan(c, 760)                                                    # cooling fan, unpowered
    tape_drive(c, 686, TOP, on=True)
    r = monitor(c, 784, TOP, 60, 36, 'off', seed=7, notes=3)
    mint_screen(r[0] + 1.6, r[1] + 1.6, r[2] - 1.6, r[3] - 2.8, seed=8)
    keyboard(c, 784, TOP, 34, lit_keys=hx('#3f7f74'))
    c.bezier((732, TOP - 8), (748, TOP + 2), (756, TOP - 4), hx('#2a3a38'), 0.8)
    papers(c, 640, 676, TOP, 6, seed=9)
    mug(c, 850, TOP)
    chair_back(c, 846, blanket=hx('#2f3a3c'))
    c.occlude(681, 373, 719, 413, 60, blur=2); c.apply_shade_now()
    c.box(680, 372, 716, 410, hx('#7f827d'), outline=OUT, hl=.02)
    c.rect(682, 374, 714, 380, MINT)
    for k in range(5):
        c.hline(684, 684 + (24 if k % 2 else 18), 385 + k * 5, hx('#4f5458'), 0.6)
    floor_spill(c, 730, 840, MINT, 0.3)
    # tape shelf: open shelving, the original tape on the bottom shelf
    sx0, sx1, stop = 878, 994, FY - 150
    c.occlude(sx0, stop, sx1, FY, 110, blur=5); c.apply_shade_now()
    for lx in (sx0, sx1 - 4):
        c.box(lx, stop, lx + 4, FY, hx('#4b5358'), outline=OUT)
    rng = random.Random(14)
    for k in range(4):
        yy = stop + 4 + k * 37
        c.box(sx0, yy + 33, sx1, yy + 36, hx('#4b5358'), outline=OUT)
        for j in range(10):
            tx = sx0 + 7 + j * 10.5
            if rng.random() < (0.15 if k < 3 else 0.6):
                continue
            c.box(tx, yy + 18, tx + 9, yy + 33, hx('#1c2024'), outline=OUT)
            c.rect(tx + 1, yy + 19, tx + 8, yy + 22, dk(rng.choice([MINT, hx('#8a7a3a'), hx('#5f6a72')]), .15))
    # the one tape that matters: bottom shelf, catching light
    c.box(sx0 + 50, FY - 34, sx0 + 59, FY - 19, hx('#1c2024'), outline=OUT)
    c.rect(sx0 + 51, FY - 33, sx0 + 58, FY - 30, MINT_L)
    c.glow_rect(sx0 + 50, FY - 34, sx0 + 59, FY - 19, MINT, 0.3, blur=4)
    tape_cart(c, 160 - 70 - 4, 0) if False else None


# ------------------------------------------------------------------ B: developer work area
def back_row():
    TOP = FY - 69
    desk(c, 1080, 2440, TOP, peds=(), col=hx('#5f666b'))
    rng = random.Random(21)
    for x in np.arange(1110, 2420, 96):
        monitor(c, x, TOP, 46, 28, 'off', seed=int(x), stand='base', notes=rng.choice([0, 0, 1, 2]))
        monitor(c, x + 46, TOP, 46, 28, 'off', seed=int(x) + 1, stand='base')
        if rng.random() < 0.5:
            papers(c, x - 20, x - 6, TOP, rng.randint(3, 12), seed=int(x))
    for x in (1290, 1690, 2090):
        power_pole(c, x, 296, TOP, seed=x)
    for x in (1160, 1352, 1544, 1928, 2120, 2312):
        chair_back(c, x, lowered=-2)


def front_benches():
    TOP = FY - 69
    rng = random.Random(31)
    for bx0, bx1, seed in ((1124, 1640, 1), (1796, 2312, 2)):
        desk(c, bx0, bx1, TOP, peds=('L', 'R'), seed=seed, col=hx('#6c7378'))
        c.box(bx0 + 248, TOP + 4, bx0 + 256, FY, DESK_LEG, outline=OUT)
        pedestal(c, bx0 + 204, TOP + 5, 42)
        pedestal(c, bx0 + 262, TOP + 5, 42)
        cxs = [bx0 + 70 + k * 126 for k in range(4)]
        power_pole(c, (bx0 + bx1) / 2, 296, TOP, cables=5, seed=seed)
        for i, cx in enumerate(cxs):
            senior = (seed == 1 and i == 2)
            monitor(c, cx - 26, TOP, 50, 30, 'off', seed=seed * 10 + i, notes=(7 if senior else rng.choice([0, 1, 2])))
            monitor(c, cx + 26, TOP, 50, 30, 'off', seed=seed * 10 + i + 5, notes=(3 if senior else 0))
            keyboard(c, cx, TOP, 34); mouse(c, cx + 26, TOP)
            if rng.random() < 0.6:
                papers(c, cx - 56, cx - 32, TOP, rng.randint(4, 16), seed=seed * 7 + i)
            if rng.random() < 0.5:
                mug(c, cx + 46, TOP, rng.choice([hx('#56606a'), hx('#6f5048'), hx('#5e5a54')]))
            if rng.random() < 0.4:
                can(c, cx + 52, TOP, rng.choice([hx('#3e6e64'), hx('#4a5a6a')]))
            if senior:
                for k in range(6):                                     # sticky-note cluster on the desk
                    sticky(c, cx - 50 + k * 6.5, TOP - 5 - (k % 2) * 4, [hx('#a69a58'), hx('#9b7177'), hx('#6f959a')][k % 3])
            cable_to_floor(c, cx - 20, TOP + 4, dx=rng.uniform(-12, 12))
        # a laptop still on battery on bench 2
        if seed == 2:
            laptop(c, cxs[1] + 70, TOP, 28, 'code_dim', seed=41)
            floor_spill(c, cxs[1] + 40, cxs[1] + 100, CYAN, 0.18)
        # chairs: one with a jacket, one rolled away, one missing
        for i, cx in enumerate(cxs):
            if seed == 1 and i == 1:
                continue
            if seed == 2 and i == 3:
                chair_side(c, cx + 30, facing=-1)
                continue
            chair_back(c, cx, blanket=(hx('#33383a') if (seed == 2 and i == 0) else None))
    backpack(c, 1254, hx('#2f3530'))
    recycle_bin(c, 2318)
    chair_fallen(c, 1706, col=hx('#30373c'))                           # tipped over in the aisle
    c.hline(1673, 1719, FY - 12, hx('#5a666b'), 0.8)                     # rim light on the toppled backrest
    c.vline(1716, FY - 52, FY - 7, hx('#5a666b'), 0.8)
    # mobile pinboard with the request cards, next to the column
    c.occlude(1044, FY - 4, 1120, FY + 1, 90, blur=3, ellipse=True)
    for lx in (1050, 1110):
        c.box(lx, FY - 70, lx + 3, FY - 4, hx('#4f575d'), outline=OUT)
        c.box(lx - 8, FY - 4, lx + 11, FY - 1, hx('#3a4045'), outline=OUT)
    request_board(c, 1044, FY - 168, 72, 98, seed=3)
    # withered plant and copier near the meeting room
    c.box(2342, FY - 40, 2382, FY, hx('#4a4842'), outline=OUT)
    for k in range(9):
        a = -math.pi / 2 + (k - 4) * 0.28
        L = 50 + (k % 3) * 18
        ex = 2362 + math.cos(a) * L * 0.6; ey = FY - 40 + math.sin(a) * L
        c.line([(2362, FY - 40), (ex, ey), (ex + (k - 4) * 3, ey + 16)], hx('#4f4b38'), 1.2)
    c.box(2392, FY - 92, 2452, FY - 2, hx('#4b5257'), outline=OUT, hl=.1)  # copier
    c.box(2388, FY - 98, 2456, FY - 92, hx('#5e666b'), outline=OUT)
    c.rect(2398, FY - 84, 2446, FY - 80, hx('#2a2f33'))
    for k in range(3):
        c.rect(2398, FY - 70 + k * 20, 2446, FY - 56 + k * 20, None, hx('#353c41'), 0.6)
    c.rect(2404, FY - 99.5, 2440, FY - 98, hx('#7f827d'))


# ------------------------------------------------------------------ C: meeting room
def glass_partition():
    x0, x1 = GP
    tdraw(c, (x0, CLC, x1, FY), lambda od, ox, oy: od.rectangle([P(x0) + ox, P(CLC) + oy, P(x1) + ox, P(FY) + oy], fill=(150, 185, 190, 46)))
    c.vline(x0, CLC, FY, hx('#5e676c'), 1.2); c.vline(x1 - 1.2, CLC, FY, hx('#5e676c'), 1.2)
    c.box(x0 - 4, FY - 6, x1 + 4, FY, hx('#5e676c'), outline=OUT)
    c.box(x0 - 2, CLC, x1 + 2, CLC + 6, hx('#5e676c'), outline=OUT)
    reflection(c, x0, CLC, x1, FY, 40, 0.1, 0.6)
    # frosted film band, seen edge-on as a slightly denser strip
    tdraw(c, (x0, 410, x1, 450), lambda od, ox, oy: od.rectangle([P(x0) + ox, P(410) + oy, P(x1) + ox, P(450) + oy], fill=(200, 215, 215, 60)))
    # glass door standing open, edge-on, with a pull handle
    c.box(x1 + 2, FY - 210, x1 + 6, FY - 4, hx('#8aa0a4'), outline=OUT)
    c.box(x1 + 6, FY - 118, x1 + 9, FY - 82, hx('#9aa3a7'), outline=OUT)
    # card reader + exit pictogram
    c.box(x1 + 14, 462, x1 + 26, 486, hx('#24292d'), outline=OUT)
    led(c, x1 + 20, 480, GREEN, 0.7, 0.6)
    c.box(x1 + 12, CLC + 12, x1 + 56, CLC + 28, hx('#1a2a1f'), outline=OUT)
    c.rect(x1 + 14, CLC + 14, x1 + 54, CLC + 26, hx('#2f6a45'))
    c.ell(x1 + 41, CLC + 15.5, x1 + 44, CLC + 18.5, hx('#cfe8d6'))
    c.line([(x1 + 42, CLC + 19), (x1 + 39, CLC + 23), (x1 + 35, CLC + 25)], hx('#cfe8d6'), 0.9)
    c.line([(x1 + 41, CLC + 20), (x1 + 46, CLC + 22)], hx('#cfe8d6'), 0.8)
    c.line([(x1 + 39, CLC + 23), (x1 + 42, CLC + 25.5)], hx('#cfe8d6'), 0.8)
    c.line([(x1 + 30, CLC + 20), (x1 + 18, CLC + 20), (x1 + 22, CLC + 17)], hx('#cfe8d6'), 0.8)
    c.glow_rect(x1 + 12, CLC + 12, x1 + 56, CLC + 28, hx('#4fb57a'), 0.55, blur=14)


def furniture_C():
    TOP = FY - 69
    hash_chain_board(c, 2500, 332, 2756, 438)
    # pinned technical printouts on the fabric wall
    rng = random.Random(51)
    for k in range(4):
        px = 2776 + (k % 2) * 40; py = 336 + (k // 2) * 52
        c.occlude(px + 1, py + 2, px + 36, py + 48, 60, blur=2)
        c.apply_shade_now()
        c.box(px, py, px + 34, py + 46, hx('#7f827f'), outline=OUT, hl=.02)
        for r in range(3):
            c.rect(px + 4 + (r % 2) * 12, py + 5 + r * 13, px + 16 + (r % 2) * 12, py + 13 + r * 13, None, hx('#2f4766'), 0.6)
        c.ell(px + 15, py - 1, px + 18, py + 2, MINT)
    c.ell(2818, 384, 2848, 408, None, hx('#7b3a33'), 0.8)
    # meeting table (white laminate on trestles)
    tx0, tx1 = 2536, 2884
    c.occlude(tx0 + 6, TOP + 5, tx1 - 6, FY, 100, blur=6); c.apply_shade_now()
    for lx in (tx0 + 40, tx1 - 56):
        c.box(lx, TOP + 5, lx + 6, FY - 4, hx('#5a6267'), outline=OUT)
        c.box(lx + 10, TOP + 5, lx + 16, FY - 4, hx('#5a6267'), outline=OUT)
        c.box(lx - 6, FY - 4, lx + 22, FY, hx('#3a4045'), outline=OUT)
    c.box(tx0 + 60, TOP + 5, tx1 - 60, TOP + 12, hx('#22272b'), outline=OUT)        # cable tray
    c.box(tx0, TOP, tx1, TOP + 5, hx('#7a8084'), outline=OUT, hl=.12, sh=.35)
    # discussion materials
    for x, n, sd in ((2572, 9, 1), (2660, 14, 2), (2760, 6, 3), (2846, 11, 4)):
        y = papers(c, x - 16, x + 16, TOP, n, seed=sd + 60)
        if sd in (2, 4):
            c.ell(x - 8, y - 0.6, x + 8, y + 0.8, None, hx('#7b3a33'), 0.5)
    laptop(c, 2710, TOP, 30, 'code_dim', seed=61)
    laptop(c, 2610, TOP, 28, 'off', seed=62)
    for x in (2632, 2800):
        mug(c, x, TOP, hx('#5e6870'))
    c.box(2734, TOP - 5, 2752, TOP, hx('#2f4766'), outline=OUT)                    # marker box
    for k in range(4):
        sticky(c, 2780 + k * 6, TOP - 1.5, [hx('#a69a58'), hx('#9b7177'), hx('#6f959a'), hx('#a69a58')][k])
    for x in (2590, 2690, 2790):
        chair_back(c, x, col=hx('#1f2427'))
    chair_side(c, 2872, facing=-1, col=hx('#1f2427'))
    display_stand(c, 2962, 146, 84, 'off', seed=63)
    flip_chart(c, 3054)


def lights():
    cctv_dome(976, 266)
    cctv_dome(2300, 296)
    for x in (600, 1400, 2200, 2900):
        c.ell(x - 5, TS1 - 1, x + 5, TS1 + 5, hx('#7a8084'), OUT, 0.5)


def cctv_dome(x, y):
    c.vline(x, TS1, y, hx('#3a4045'), 0.8)
    c.box(x - 9, y, x + 9, y + 3, hx('#4a5258'), outline=OUT)
    c.ell(x - 7, y - 2, x + 7, y + 11, hx('#1c2024'), OUT, 0.8)
    led(c, x + 2, y + 6, RED, 0.6, 0.6)


# ------------------------------------------------------------------ finalize
def finalize():
    arr = np.asarray(c.img, np.float32)
    h, w = arr.shape[:2]
    ys = np.linspace(0, 1, h)[:, None]
    xs = np.linspace(0, 1, w)[None, :]
    yy = (ys * H - TS1) / (FY - TS1)
    v = 1.0 - 0.30 * np.clip(1 - yy * 1.5, 0, 1) ** 1.5
    v *= 1.0 - 0.10 * np.clip((yy - 0.75) * 4, 0, 1)
    edge = np.minimum(xs, 1 - xs) * W
    v = v * (0.74 + 0.26 * np.clip(edge / 420.0, 0, 1))
    arr[:, :, :3] *= v[:, :, None]
    sh = np.asarray(c.shade, np.float32)[:, :, None] / 255.0
    arr[:, :, :3] *= (1 - sh * 0.85)
    L = np.asarray(c.light, np.float32) / 255.0
    base = arr[:, :, :3] / 255.0
    out = 1 - (1 - base) * (1 - L)
    lum = (out * np.array([0.299, 0.587, 0.114])).sum(axis=2, keepdims=True)
    out = out * 0.80 + lum * 0.20
    out = out * np.array([0.97, 1.0, 1.02])
    out = np.clip(out, 0, 1) ** 0.92
    out = np.clip((out - 0.5) * 1.10 + 0.5, 0, 1)
    arr[:, :, :3] = out * 255
    img = Image.fromarray(arr.clip(0, 255).astype(np.uint8), 'RGBA').resize((W, H), Image.LANCZOS)
    a = np.asarray(img, np.float32)
    rng = np.random.default_rng(4)
    g = (rng.random((H, W)) - 0.5) * 7
    low = Image.fromarray((rng.random((H // 6, W // 6)) * 255).astype(np.uint8), 'L').resize((W, H), Image.BICUBIC)
    low = (np.asarray(low, np.float32) / 255 - 0.5) * 0.07
    a[:, :, :3] = a[:, :, :3] * (1 + low[:, :, None]) + g[:, :, None]
    alpha = np.where(a[:, :, 3] > 127, 255, 0)
    a[:, :, 3] = alpha
    a[:, :, :3] *= (alpha[:, :, None] > 0)
    img = Image.fromarray(a.clip(0, 255).astype(np.uint8), 'RGBA')
    m = img.getchannel('A')
    inner = m.filter(ImageFilter.MinFilter(5))
    img.paste(Image.new('RGBA', img.size, (9, 10, 12, 255)), (0, 0), ImageChops.subtract(m, inner))
    inner2 = m.filter(ImageFilter.MinFilter(9))
    img.paste(Image.new('RGBA', img.size, (78, 88, 98, 255)), (0, 0), ImageChops.subtract(inner, inner2).point(lambda v: 150 if v else 0))
    bb = img.getchannel('A').getbbox()
    M = 48
    img = img.crop((bb[0] - M, bb[1] - M, bb[2] + M, bb[3] + M))
    print('bbox', bb, 'floor line y in output =', FY - (bb[1] - M), 'size', img.size)
    return img


def build():
    shell()
    c.noise_tex(A[0], 250, A[1], FY, 0.07, 30, seed=1, streaks=True)
    c.noise_tex(C[0], CLC, C[1], FY, 0.06, 24, seed=3, streaks=True)
    c.noise_tex(X0, TS0, X1, TS1, 0.08, 16, seed=4)
    c.noise_tex(X0, FY, X1, FB, 0.08, 16, seed=5)
    c.noise_tex(IX0, TS1, IX1, 300, 0.08, 20, seed=6)
    for i, (x, y, w_, h_) in enumerate([(240, 470, 140, 90), (700, 300, 120, 80), (2600, 470, 160, 90), (3000, 320, 90, 120)]):
        c.stain(x, y, w_, h_, hx('#14171a'), alpha=40, blur=10, seed=i + 20)
    curtain_wall()
    ceilings()
    c.occlude(IX0, TS1, IX1, TS1 + 10, 150, blur=10)
    c.occlude(IX0, FY - 6, IX1, FY, 120, blur=6)
    c.occlude(IX0, TS1, IX0 + 10, FY, 140, blur=14)
    c.occlude(IX1 - 10, TS1, IX1, FY, 140, blur=14)
    c.occlude(GP[1], CLC, GP[1] + 16, FY, 100, blur=10)
    c.apply_shade_now()
    furniture_A()
    tape_cart(c, 166 - 82, 0) if False else None
    layer(back_row)
    front_benches()
    glass_partition()
    furniture_C()
    lights()
    return finalize()


if __name__ == '__main__':
    img = build()
    out = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/f4/floor04.png'
    img.save(out)
    print('saved', out)
