import random, math
import numpy as np
from PIL import Image, ImageDraw
from lib import *
from objects import *

MINT = hx('#5f8f86')
MINT_L = hx('#8fc4b8')
SODIUM = hx('#c88a52')


# ------------------------------------------------------------ street view
def street_view(c, x0, y0, x1, y1, seed=0):
    """4th-floor view: lit office facade across the street, tree crowns, sodium street light from below"""
    rng = random.Random(seed)
    c.vgrad(x0, y0, x1, y1, hx('#18222e'), hx('#2a2a2a'))
    fx = x0 - rng.uniform(0, 40)
    while fx < x1:
        bw = rng.uniform(280, 440)
        top = y0 + rng.uniform(-6, 46)
        col = rng.choice([hx('#262d34'), hx('#232a31'), hx('#2a3036')])
        bx0, bx1 = max(fx, x0), min(fx + bw, x1)
        c.vgrad(bx0, max(top, y0), bx1, y1, col, mix(col, hx('#4e463c'), .45))   # facade warmed from below
        c.vline(bx0, max(top, y0), y1, lit(col, .1), 1)
        fh = 34
        lit_floors = set(rng.sample(range(0, 8), 2))
        for k, fy in enumerate(np.arange(top + 10, y1, fh)):
            c.hline(bx0, bx1, fy - 5, dk(col, .25), 1.4)
            for wx in np.arange(fx + 8, fx + bw - 16, 22):
                if wx < x0 + 1 or wx + 15 > x1 - 1 or fy < y0:
                    continue
                on = rng.random() < (0.65 if k in lit_floors else 0.12)
                if on:
                    wc = dk(rng.choice([hx('#c9d4d6'), hx('#d4bd88'), hx('#aec2cc')]), 0.30 + rng.uniform(0, .15))
                else:
                    wc = dk(col, .45)
                c.rect(wx, fy, wx + 15, min(fy + 20, y1), wc)
                if on:
                    c.vline(wx + 7, fy, min(fy + 20, y1), dk(wc, .25), 0.8)
                    if rng.random() < 0.3:
                        c.rect(wx + 2, fy + 12, wx + 9, fy + 20, dk(wc, .5))   # silhouette of a monitor/desk
                    paint_glow(c, (x0, y0, x1, y1), ('rect', wx, fy, wx + 15, min(fy + 20, y1)), wc, 0.22, blur=5)
        if rng.random() < 0.6:
            sx = fx + bw * rng.uniform(.2, .6)
            if x0 < sx < x1 - 60 and top + 30 > y0:
                c.box(sx, top + 22, sx + 54, top + 38, hx('#262c31'), outline=OUT)
        fx += bw + rng.uniform(18, 40)
    # sodium street lights from below
    for k in range(int((x1 - x0) / 300) + 1):
        gx = x0 + 120 + k * 300 + rng.uniform(-30, 30)
        if gx < x1:
            paint_glow(c, (x0, y0, x1, y1), ('ell', gx, y1 + 30, 200, 160), hx('#a88866'), 0.32, blur=60)
    # tree crowns along the street
    tx = x0 - 20
    while tx < x1:
        r = rng.uniform(26, 42)
        cy = y1 - rng.uniform(2, 16)
        col = rng.choice([hx('#0c120f'), hx('#0e1411'), hx('#101612')])
        for j in range(7):
            ex = tx + rng.uniform(-r, r); ey = cy + rng.uniform(-r * .5, r * .3)
            er = r * rng.uniform(.45, .75)
            c.ell(max(x0, ex - er), max(y0, ey - er * .8), min(x1, ex + er), min(y1, ey + er * .8), col)
        paint_glow(c, (x0, y0, x1, y1), ('ell', tx, y1 - 4, r * 1.1, 8), hx('#a88866'), 0.25, blur=6)
        tx += r * rng.uniform(1.1, 1.6)


def roller_shade(c, x0, y0, x1, drop, seed=0, torn=False):
    rng = random.Random(seed)
    c.box(x0 - 2, y0 - 7, x1 + 2, y0, hx('#2c3236'), outline=OUT, hl=.15)
    if drop <= 2:
        return
    col = hx('#3e464a')
    by = y0 + drop
    if torn:
        pts = [(x0, y0), (x1, y0), (x1, by - 18)]
        n = 9
        for i in range(n + 1):
            xx = x1 - (x1 - x0) * i / n
            pts.append((xx, by - rng.uniform(0, 26)))
        pts.append((x0, by))
        tpoly(c, pts, col, 215)
    else:
        tdraw(c, (x0, y0, x1, by), lambda od, ox, oy: od.rectangle([P(x0) + ox, P(y0) + oy, P(x1) + ox, P(by) + oy], fill=wa(col, 215)))
        c.box(x0, by - 3, x1, by, hx('#22282c'), outline=OUT)                  # bottom bar
        c.rect((x0 + x1) / 2 - 2, by, (x0 + x1) / 2 + 2, by + 5, hx('#22282c'))
    # weave texture
    for xx in np.arange(x0 + 2, x1 - 1, 3):
        tline(c, [(xx, y0 + 1), (xx, by - 4)], hx('#2c3337'), 40, 0.4)
    # chain
    c.vline(x1 - 6, y0, y0 + drop + 70, hx('#6a7076'), 0.5)


def baffles(c, x0, x1, top, h, step=24, col=hx('#454c50')):
    for x in np.arange(x0 + 8, x1 - 4, step):
        c.vline(x + 2, top - 22, top, hx('#2a2f33'), 0.4)
        c.vline(x + 7, top - 22, top, hx('#2a2f33'), 0.4)
        c.box(x, top, x + 9, top + h, col, outline=OUT, hl=.1, sh=.35)
    # dark linear light slots between baffles (off)
    for x in np.arange(x0 + 8 + step * 2.5, x1 - 20, step * 6):
        c.box(x - 1, top + h - 4, x + step + 1, top + h - 1, hx('#2b3034'), outline=None)


def power_pole(c, x, top, desk_y, cables=3, seed=0):
    rng = random.Random(seed)
    c.box(x - 4, top, x + 4, desk_y, hx('#5a6166'), outline=OUT, hl=.2, sh=.3)
    c.vline(x - 1, top, desk_y, hx('#3a4045'), 0.6)
    for k in range(cables):
        cx = x + rng.uniform(-30, 30)
        c.bezier((x + rng.choice([-4, 4]), desk_y - rng.uniform(8, 30)), (cx, desk_y + 6), (cx + rng.uniform(-6, 6), desk_y - 1), hx('#121417'), 0.8)
    for oy in (desk_y - 16, desk_y - 30):
        c.rect(x - 3, oy, x + 3, oy + 3, hx('#2a2f33'))


def chair_fallen(c, cx, col=hx('#1d2125')):
    """office chair tipped over onto its back in the aisle"""
    c.occlude(cx - 40, FY - 6, cx + 40, FY + 1, 120, blur=3, ellipse=True)
    # backrest lying on the floor
    c.rrect(cx - 34, FY - 12, cx + 14, FY - 1, 5, col, OUT, 1)
    for xx in range(int(cx - 30), int(cx + 10), 3):
        c.vline(xx, FY - 10, FY - 3, dk(col, .25), 0.4)
    # seat standing up, base pointing sideways
    c.rrect(cx + 10, FY - 52, cx + 20, FY - 6, 3, col, OUT, 1)
    c.box(cx + 20, FY - 32, cx + 38, FY - 28, hx('#3a4045'), outline=OUT)        # gas lift
    c.poly([(cx + 38, FY - 48), (cx + 42, FY - 48), (cx + 44, FY - 10), (cx + 40, FY - 10)], hx('#24282c'), OUT)
    for dy in (-48, -30, -12):
        c.ell(cx + 42, FY + dy - 3, cx + 48, FY + dy + 3, hx('#121417'), OUT, 0.5)
    c.rect(cx + 2, FY - 40, cx + 12, FY - 36, hx('#1a1d20'))                       # armrest


def tape_cart(c, x, w=70, seed=0, gap_slot=(2, 5)):
    rng = random.Random(seed)
    c.occlude(x - 2, FY - 100, x + w + 2, FY, 100, blur=4)
    for lx in (x, x + w - 3):
        c.box(lx, FY - 100, lx + 3, FY - 5, hx('#4f575d'), outline=OUT)
    for r, yy in enumerate((FY - 98, FY - 66, FY - 34)):
        c.box(x, yy + 22, x + w, yy + 25, hx('#59616a'), outline=OUT)
        for k in range(7):
            tx = x + 4 + k * 9
            if (r, k) == gap_slot:
                continue
            c.box(tx, yy + 8, tx + 8, yy + 22, hx('#1c2024'), outline=OUT)
            lab = rng.choice([MINT, hx('#8a7a3a'), hx('#5f6a72'), hx('#7a4a44')])
            c.rect(tx + 1, yy + 9, tx + 7, yy + 12, dk(lab, .15))
    for wx in (x + 2, x + w - 7):
        c.ell(wx, FY - 5, wx + 5, FY, hx('#15181b'), OUT, 0.4)
    # clipboard ledger hanging from the handle
    c.box(x + w, FY - 96, x + w + 4, FY - 60, hx('#4f575d'), outline=OUT)
    c.box(x + w + 3, FY - 92, x + w + 21, FY - 68, hx('#5e5242'), outline=OUT)
    c.rect(x + w + 5, FY - 89, x + w + 19, FY - 70, hx('#7f827d'))
    for k in range(6):
        c.hline(x + w + 7, x + w + 17, FY - 86 + k * 3, hx('#4f5458'), 0.5)
    c.rect(x + w + 9, FY - 94, x + w + 15, FY - 90, hx('#8a9196'))


def tape_drive(c, x, desk_y, on=True):
    c.box(x, desk_y - 14, x + 46, desk_y, hx('#24292d'), outline=OUT, hl=.1)
    c.rect(x + 6, desk_y - 9, x + 28, desk_y - 6, hx('#0b0d0f'))
    c.box(x + 10, desk_y - 13, x + 24, desk_y - 9, hx('#1c2024'), outline=OUT)      # tape half inserted
    c.rect(x + 11, desk_y - 12.5, x + 17, desk_y - 11, MINT)
    if on:
        led(c, x + 38, desk_y - 9, MINT_L, 0.6, 0.7)
        led(c, x + 42, desk_y - 9, AMBER, 0.5, 0.5)


def ups_tower(c, x, on=True):
    c.occlude(x - 2, FY - 52, x + 26, FY, 90, blur=3)
    c.box(x, FY - 50, x + 24, FY - 1.5, hx('#2a2f33'), outline=OUT, hl=.1)
    c.rect(x + 4, FY - 44, x + 20, FY - 36, hx('#0e1614'))
    if on:
        for k in range(2):
            c.rect(x + 6 + k * 5, FY - 42, x + 9.5 + k * 5, FY - 38, MINT_L)
        c.rect(x + 16, FY - 42, x + 18.5, FY - 38, dk(MINT, .6))
        c.glow_rect(x + 4, FY - 44, x + 20, FY - 36, MINT, 0.45, blur=4)
    for k in range(6):
        c.hline(x + 4, x + 20, FY - 30 + k * 4, hx('#1d2125'), 0.8)


def ups_distributor(c, x0, y0, active=2):
    """wall panel with three outputs; only one lit"""
    c.occlude(x0 + 1, y0 + 2, x0 + 62, y0 + 58, 80, blur=3)
    c.apply_shade_now()
    c.box(x0, y0, x0 + 60, y0 + 56, hx('#4a5257'), outline=OUT, hl=.08)
    c.rect(x0 + 4, y0 + 4, x0 + 56, y0 + 52, None, hx('#353c41'), 0.6)
    for k in range(3):
        lx = x0 + 12 + k * 18
        c.ell(lx - 5, y0 + 12, lx + 5, y0 + 22, hx('#1a1e21'), OUT, 0.6)
        if k == active:
            c.ell(lx - 3.5, y0 + 13.5, lx + 3.5, y0 + 20.5, MINT_L)
            c.glow_ell(lx, y0 + 17, 9, 9, MINT, 0.7, blur=5)
        else:
            c.ell(lx - 3.5, y0 + 13.5, lx + 3.5, y0 + 20.5, hx('#2c3236'))
        c.rect(lx - 4, y0 + 28, lx + 4, y0 + 32, hx('#7f827d'))            # blank label plates
        c.box(lx - 2, y0 + 56, lx + 2, y0 + 62, hx('#2a2f33'), outline=None)
    c.box(x0 + 22, y0 + 38, x0 + 38, y0 + 46, hx('#2a2f33'), outline=OUT)    # selector knob
    c.line([(x0 + 30, y0 + 42), (x0 + 36, y0 + 39)], hx('#8a9196'), 1)


def hash_chain_board(c, x0, y0, x1, y1, seed=0):
    rng = random.Random(seed)
    c.occlude(x0 + 2, y0 + 3, x1 + 3, y1 + 5, 90, blur=4); c.apply_shade_now()
    c.rect(x0, y0, x1, y1, hx('#4f575e'))
    c.vgrad(x0 + 3, y0 + 3, x1 - 3, y1 - 3, hx('#6d7579'), hx('#596165'))
    ink = hx('#2b3034'); red = hx('#7b3a33'); teal = hx('#2f5a55')
    n = 6
    bw = (x1 - x0 - 40) / n - 10
    by0 = y0 + 18; by1 = by0 + 26
    for i in range(n):
        bx = x0 + 18 + i * (bw + 10)
        if i == 3:
            # erased block: smudge + red circle
            c.stain(bx, by0, bw, by1 - by0, hx('#848b8f'), alpha=70, blur=3, seed=3)
            c.ell(bx - 6, by0 - 8, bx + bw + 6, by1 + 8, None, red, 1.2)
            continue
        col = ink if i < 3 else red
        c.rect(bx, by0, bx + bw, by1, None, col, 1)
        c.hline(bx + 3, bx + bw * 0.7, by0 + 7, col, 0.7)
        c.hline(bx + 3, bx + bw * 0.5, by0 + 14, col, 0.7)
        c.rect(bx + bw - 9, by0 + 4, bx + bw - 3, by0 + 10, col)            # hash cell
        if i < n - 1:
            ax0, ax1 = bx + bw, bx + bw + 10
            ay = (by0 + by1) / 2
            if i >= 2:
                for xx in np.arange(ax0, ax1, 3):
                    c.hline(xx, xx + 1.5, ay, red, 0.8)
            else:
                c.hline(ax0, ax1 - 2, ay, ink, 0.8)
                c.poly([(ax1 - 3, ay - 2), (ax1, ay + 0.4), (ax1 - 3, ay + 2.8)], ink)
    # 24h timeline with a blank hour
    ty = by1 + 26
    c.hline(x0 + 18, x1 - 18, ty, ink, 1)
    for k in range(25):
        xx = x0 + 18 + (x1 - x0 - 36) * k / 24
        c.vline(xx, ty - 2, ty + 2, ink, 0.6)
    gx0 = x0 + 18 + (x1 - x0 - 36) * 3 / 24; gx1 = x0 + 18 + (x1 - x0 - 36) * 4 / 24
    c.rect(gx0, ty - 5, gx1, ty + 5, None, red, 1)
    for xx in np.arange(gx0 + 1, gx1 - 1, 2.5):
        c.line([(xx, ty + 4), (xx + 2, ty - 4)], red, 0.5)
    c.line([(gx1 + 2, ty - 6), (gx1 + 20, ty - 16)], red, 0.8)
    c.ell(gx1 + 20, ty - 22, gx1 + 34, ty - 12, None, red, 0.8)
    # tray + frame
    c.rect(x0, y0, x1, y1, None, hx('#7a8186'), 1); c.rect(x0, y0, x1, y1, None, OUT, 0.5)
    c.box(x0 + 6, y1, x1 - 6, y1 + 4, hx('#5e666c'), outline=OUT)
    c.rect(x0 + 20, y1 - 1.6, x0 + 30, y1, red); c.rect(x0 + 34, y1 - 1.6, x0 + 44, y1, teal)


def request_board(c, x0, y0, w=70, h=96, seed=0):
    rng = random.Random(seed)
    c.occlude(x0 + 1, y0 + 2, x0 + w + 2, y0 + h + 3, 80, blur=3); c.apply_shade_now()
    c.box(x0, y0, x0 + w, y0 + h, hx('#4a3e31'), outline=OUT, hl=.03)
    cards = [(x0 + 5, y0 + 6), (x0 + 37, y0 + 8), (x0 + 6, y0 + 38), (x0 + 38, y0 + 40), (x0 + 8, y0 + 68), (x0 + 38, y0 + 70)]
    for i, (px, py) in enumerate(cards):
        c.box(px, py, px + 26, py + 24, hx('#7f827f') if i != 2 else hx('#8a8c86'), outline=OUT, hl=.02)
        for ln in range(4):
            c.hline(px + 3, px + 3 + rng.uniform(8, 18), py + 4 + ln * 4.5, hx('#4f5458'), 0.5)
        c.ell(px + 11, py - 1, px + 14, py + 2, MINT)
    # card #88: red rejection stamp, then a teal approval tick over it
    px, py = cards[2]
    c.ell(px + 6, py + 6, px + 22, py + 22, None, hx('#8a3a33'), 1.2)
    c.line([(px + 9, py + 9), (px + 19, py + 19)], hx('#8a3a33'), 1)
    c.line([(px + 10, py + 15), (px + 14, py + 20), (px + 24, py + 6)], hx('#3f7f74'), 1.6)


def display_stand(c, cx, w=146, h=84, mode='off', seed=0):
    sy1 = FY - 96; sy0 = sy1 - h
    c.occlude(cx - 50, FY - 6, cx + 50, FY + 1, 100, blur=3, ellipse=True)
    c.box(cx - 46, FY - 8, cx + 46, FY - 4, hx('#2a2f33'), outline=OUT)
    for wx in (cx - 44, cx + 38):
        c.ell(wx, FY - 6, wx + 6, FY, hx('#15181b'), OUT, 0.4)
    for px in (cx - 22, cx + 18):
        c.box(px, sy1 - 30, px + 4, FY - 8, hx('#4a5258'), outline=OUT, hl=.2)
    c.box(cx - 30, FY - 40, cx + 30, FY - 34, hx('#3a4045'), outline=OUT)       # shelf
    laptop(c, cx, FY - 40, 26, 'off', seed=seed)
    c.rrect(cx - w / 2, sy0, cx + w / 2, sy1, 1.5, hx('#0e1012'), OUT, 1)
    screen_content(c, cx - w / 2 + 3, sy0 + 3, cx + w / 2 - 3, sy1 - 3, mode, seed)
    led(c, cx + w / 2 - 5, sy1 - 1.5, RED, 0.5, 0.5)


def flip_chart(c, x, seed=0):
    c.occlude(x - 6, FY - 4, x + 54, FY + 1, 90, blur=3, ellipse=True)
    c.line([(x + 24, FY - 176), (x + 2, FY)], hx('#4a5056'), 1.6)
    c.line([(x + 24, FY - 176), (x + 46, FY)], hx('#4a5056'), 1.6)
    c.line([(x + 24, FY - 160), (x + 30, FY)], hx('#3a4045'), 1.2)
    c.box(x, FY - 176, x + 48, FY - 112, hx('#7b7e7a'), outline=OUT, hl=.04)
    for k in range(4):
        c.line([(x + 6, FY - 168 + k * 13), (x + 20, FY - 170 + k * 13), (x + 36, FY - 166 + k * 13)], hx('#2f4766') if k % 2 else hx('#2b3034'), 0.8)
    c.rect(x + 8, FY - 128, x + 40, FY - 126, hx('#7b3a33'))
    c.box(x - 2, FY - 112, x + 50, FY - 108, hx('#4a5056'), outline=OUT)
    # torn sheet on the floor
    c.poly([(x + 54, FY), (x + 84, FY), (x + 80, FY - 3), (x + 58, FY - 2)], hx('#6e716d'), OUT)


def mic_array(c, cx, ceil_y):
    c.vline(cx, ceil_y, ceil_y + 14, hx('#3a4045'), 0.6)
    c.rrect(cx - 18, ceil_y + 14, cx + 18, ceil_y + 19, 2, hx('#4a5258'), OUT, 0.8)
    led(c, cx + 12, ceil_y + 18, RED, 0.4, 0.5)


def box_fan(c, x):
    c.occlude(x - 2, FY - 46, x + 46, FY, 80, blur=3)
    c.box(x, FY - 44, x + 44, FY - 4, hx('#3d4449'), outline=OUT, hl=.1)
    c.ell(x + 4, FY - 40, x + 40, FY - 8, hx('#1a1d20'), OUT, 0.6)
    for k in range(5):
        a = k / 5 * 2 * math.pi
        c.line([(x + 22, FY - 24), (x + 22 + math.cos(a) * 15, FY - 24 + math.sin(a) * 15)], hx('#4a5056'), 2)
    c.rect(x + 4, FY - 4, x + 10, FY, OUT); c.rect(x + 34, FY - 4, x + 40, FY, OUT)


def server_1u(c, x, y_bottom, w=64, open_lid=False):
    c.box(x, y_bottom - 7, x + w, y_bottom, hx('#3a4248'), outline=OUT, hl=.1)
    c.rect(x + 3, y_bottom - 5, x + 20, y_bottom - 2, hx('#1c2024'))
    for k in range(4):
        c.rect(x + 24 + k * 6, y_bottom - 5.5, x + 28 + k * 6, y_bottom - 1.5, hx('#22272b'))
    if open_lid:
        c.poly([(x + 2, y_bottom - 7), (x + w - 4, y_bottom - 7), (x + w - 10, y_bottom - 22), (x + 8, y_bottom - 20)], hx('#4b5359'), OUT)
